package net.optifine.model;

import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;

public class ModelSprite {
  private ModelRenderer modelRenderer = null;
  
  private int textureOffsetX = 0;
  
  private int textureOffsetY = 0;
  
  private float posX = 0.0F;
  
  private float posY = 0.0F;
  
  private float posZ = 0.0F;
  
  private int sizeX = 0;
  
  private int sizeY = 0;
  
  private int sizeZ = 0;
  
  private float sizeAdd = 0.0F;
  
  private float minU = 0.0F;
  
  private float minV = 0.0F;
  
  private float maxU = 0.0F;
  
  private float maxV = 0.0F;
  
  public ModelSprite(ModelRenderer modelRenderer, int textureOffsetX, int textureOffsetY, float posX, float posY, float posZ, int sizeX, int sizeY, int sizeZ, float sizeAdd) {
    this.modelRenderer = modelRenderer;
    this.textureOffsetX = textureOffsetX;
    this.textureOffsetY = textureOffsetY;
    this.posX = posX;
    this.posY = posY;
    this.posZ = posZ;
    this.sizeX = sizeX;
    this.sizeY = sizeY;
    this.sizeZ = sizeZ;
    this.sizeAdd = sizeAdd;
    this.minU = textureOffsetX / modelRenderer.textureWidth;
    this.minV = textureOffsetY / modelRenderer.textureHeight;
    this.maxU = (textureOffsetX + sizeX) / modelRenderer.textureWidth;
    this.maxV = (textureOffsetY + sizeY) / modelRenderer.textureHeight;
  }
  
  public void render(Tessellator tessellator, float scale) {
    GlStateManager.translate(this.posX * scale, this.posY * scale, this.posZ * scale);
    float rMinU = this.minU;
    float rMaxU = this.maxU;
    float rMinV = this.minV;
    float rMaxV = this.maxV;
    if (this.modelRenderer.mirror) {
      rMinU = this.maxU;
      rMaxU = this.minU;
    } 
    if (this.modelRenderer.mirrorV) {
      rMinV = this.maxV;
      rMaxV = this.minV;
    } 
    renderItemIn2D(tessellator, rMinU, rMinV, rMaxU, rMaxV, this.sizeX, this.sizeY, scale * this.sizeZ, this.modelRenderer.textureWidth, this.modelRenderer.textureHeight);
    GlStateManager.translate(-this.posX * scale, -this.posY * scale, -this.posZ * scale);
  }
  
  public static void renderItemIn2D(Tessellator tess, float minU, float minV, float maxU, float maxV, int sizeX, int sizeY, float width, float texWidth, float texHeight) {
    if (width < 6.25E-4F)
      width = 6.25E-4F; 
    float dU = maxU - minU;
    float dV = maxV - minV;
    double dimX = (MathHelper.abs(dU) * texWidth / 16.0F);
    double dimY = (MathHelper.abs(dV) * texHeight / 16.0F);
    BufferBuilder tessellator = tess.getBuffer();
    GL11.glNormal3f(0.0F, 0.0F, -1.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    tessellator.pos(0.0D, dimY, 0.0D).tex(minU, maxV).endVertex();
    tessellator.pos(dimX, dimY, 0.0D).tex(maxU, maxV).endVertex();
    tessellator.pos(dimX, 0.0D, 0.0D).tex(maxU, minV).endVertex();
    tessellator.pos(0.0D, 0.0D, 0.0D).tex(minU, minV).endVertex();
    tess.draw();
    GL11.glNormal3f(0.0F, 0.0F, 1.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    tessellator.pos(0.0D, 0.0D, width).tex(minU, minV).endVertex();
    tessellator.pos(dimX, 0.0D, width).tex(maxU, minV).endVertex();
    tessellator.pos(dimX, dimY, width).tex(maxU, maxV).endVertex();
    tessellator.pos(0.0D, dimY, width).tex(minU, maxV).endVertex();
    tess.draw();
    float var8 = 0.5F * dU / sizeX;
    float var9 = 0.5F * dV / sizeY;
    GL11.glNormal3f(-1.0F, 0.0F, 0.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    int var10;
    for (var10 = 0; var10 < sizeX; var10++) {
      float var11 = var10 / sizeX;
      float var12 = minU + dU * var11 + var8;
      tessellator.pos(var11 * dimX, dimY, width).tex(var12, maxV).endVertex();
      tessellator.pos(var11 * dimX, dimY, 0.0D).tex(var12, maxV).endVertex();
      tessellator.pos(var11 * dimX, 0.0D, 0.0D).tex(var12, minV).endVertex();
      tessellator.pos(var11 * dimX, 0.0D, width).tex(var12, minV).endVertex();
    } 
    tess.draw();
    GL11.glNormal3f(1.0F, 0.0F, 0.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    for (var10 = 0; var10 < sizeX; var10++) {
      float var11 = var10 / sizeX;
      float var12 = minU + dU * var11 + var8;
      float var13 = var11 + 1.0F / sizeX;
      tessellator.pos(var13 * dimX, 0.0D, width).tex(var12, minV).endVertex();
      tessellator.pos(var13 * dimX, 0.0D, 0.0D).tex(var12, minV).endVertex();
      tessellator.pos(var13 * dimX, dimY, 0.0D).tex(var12, maxV).endVertex();
      tessellator.pos(var13 * dimX, dimY, width).tex(var12, maxV).endVertex();
    } 
    tess.draw();
    GL11.glNormal3f(0.0F, 1.0F, 0.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    for (var10 = 0; var10 < sizeY; var10++) {
      float var11 = var10 / sizeY;
      float var12 = minV + dV * var11 + var9;
      float var13 = var11 + 1.0F / sizeY;
      tessellator.pos(0.0D, var13 * dimY, width).tex(minU, var12).endVertex();
      tessellator.pos(dimX, var13 * dimY, width).tex(maxU, var12).endVertex();
      tessellator.pos(dimX, var13 * dimY, 0.0D).tex(maxU, var12).endVertex();
      tessellator.pos(0.0D, var13 * dimY, 0.0D).tex(minU, var12).endVertex();
    } 
    tess.draw();
    GL11.glNormal3f(0.0F, -1.0F, 0.0F);
    tessellator.begin(7, DefaultVertexFormats.POSITION_TEX);
    for (var10 = 0; var10 < sizeY; var10++) {
      float var11 = var10 / sizeY;
      float var12 = minV + dV * var11 + var9;
      tessellator.pos(dimX, var11 * dimY, width).tex(maxU, var12).endVertex();
      tessellator.pos(0.0D, var11 * dimY, width).tex(minU, var12).endVertex();
      tessellator.pos(0.0D, var11 * dimY, 0.0D).tex(minU, var12).endVertex();
      tessellator.pos(dimX, var11 * dimY, 0.0D).tex(maxU, var12).endVertex();
    } 
    tess.draw();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\model\ModelSprite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */