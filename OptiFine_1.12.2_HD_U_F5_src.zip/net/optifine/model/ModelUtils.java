package net.optifine.model;

import Config;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.SimpleBakedModel;
import net.minecraft.util.EnumFacing;

public class ModelUtils {
  public static void dbgModel(IBakedModel model) {
    if (model == null)
      return; 
    Config.dbg("Model: " + model + ", ao: " + model.isAmbientOcclusion() + ", gui3d: " + model.isGui3d() + ", builtIn: " + model.isBuiltInRenderer() + ", particle: " + model.getParticleTexture());
    EnumFacing[] faces = EnumFacing.VALUES;
    for (int i = 0; i < faces.length; i++) {
      EnumFacing face = faces[i];
      List faceQuads = model.getQuads(null, face, 0L);
      dbgQuads(face.getName(), faceQuads, "  ");
    } 
    List generalQuads = model.getQuads(null, null, 0L);
    dbgQuads("General", generalQuads, "  ");
  }
  
  private static void dbgQuads(String name, List quads, String prefix) {
    for (Iterator<BakedQuad> it = quads.iterator(); it.hasNext(); ) {
      BakedQuad quad = it.next();
      dbgQuad(name, quad, prefix);
    } 
  }
  
  public static void dbgQuad(String name, BakedQuad quad, String prefix) {
    Config.dbg(prefix + "Quad: " + quad.getClass().getName() + ", type: " + name + ", face: " + quad.getFace() + ", tint: " + quad.getTintIndex() + ", sprite: " + quad.getSprite());
    dbgVertexData(quad.getVertexData(), "  " + prefix);
  }
  
  public static void dbgVertexData(int[] vd, String prefix) {
    int step = vd.length / 4;
    Config.dbg(prefix + "Length: " + vd.length + ", step: " + step);
    for (int i = 0; i < 4; i++) {
      int pos = i * step;
      float x = Float.intBitsToFloat(vd[pos + 0]);
      float y = Float.intBitsToFloat(vd[pos + 1]);
      float z = Float.intBitsToFloat(vd[pos + 2]);
      int col = vd[pos + 3];
      float u = Float.intBitsToFloat(vd[pos + 4]);
      float v = Float.intBitsToFloat(vd[pos + 5]);
      Config.dbg(prefix + i + " xyz: " + x + "," + y + "," + z + " col: " + col + " u,v: " + u + "," + v);
    } 
  }
  
  public static IBakedModel duplicateModel(IBakedModel model) {
    List generalQuads2 = duplicateQuadList(model.getQuads(null, null, 0L));
    EnumFacing[] faces = EnumFacing.VALUES;
    Map<EnumFacing, List<BakedQuad>> faceQuads2 = new HashMap<>();
    for (int i = 0; i < faces.length; i++) {
      EnumFacing face = faces[i];
      List quads = model.getQuads(null, face, 0L);
      List<BakedQuad> quads2 = duplicateQuadList(quads);
      faceQuads2.put(face, quads2);
    } 
    SimpleBakedModel model2 = new SimpleBakedModel(generalQuads2, faceQuads2, model.isAmbientOcclusion(), model.isGui3d(), model.getParticleTexture(), model.getItemCameraTransforms(), model.getOverrides());
    return (IBakedModel)model2;
  }
  
  public static List duplicateQuadList(List list) {
    List<BakedQuad> list2 = new ArrayList();
    for (Iterator<BakedQuad> it = list.iterator(); it.hasNext(); ) {
      BakedQuad quad = it.next();
      BakedQuad quad2 = duplicateQuad(quad);
      list2.add(quad2);
    } 
    return list2;
  }
  
  public static BakedQuad duplicateQuad(BakedQuad quad) {
    BakedQuad quad2 = new BakedQuad((int[])quad.getVertexData().clone(), quad.getTintIndex(), quad.getFace(), quad.getSprite());
    return quad2;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\model\ModelUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */