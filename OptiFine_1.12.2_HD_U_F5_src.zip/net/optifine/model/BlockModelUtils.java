package net.optifine.model;

import Config;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BakedQuadRetextured;
import net.minecraft.client.renderer.block.model.BlockFaceUV;
import net.minecraft.client.renderer.block.model.BlockPartFace;
import net.minecraft.client.renderer.block.model.BlockPartRotation;
import net.minecraft.client.renderer.block.model.FaceBakery;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.block.model.ItemOverrideList;
import net.minecraft.client.renderer.block.model.ModelManager;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.renderer.block.model.ModelRotation;
import net.minecraft.client.renderer.block.model.SimpleBakedModel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.util.vector.Vector3f;

public class BlockModelUtils {
  private static final float VERTEX_COORD_ACCURACY = 1.0E-6F;
  
  public static IBakedModel makeModelCube(String spriteName, int tintIndex) {
    TextureAtlasSprite sprite = Config.getMinecraft().getTextureMapBlocks().getAtlasSprite(spriteName);
    return makeModelCube(sprite, tintIndex);
  }
  
  public static IBakedModel makeModelCube(TextureAtlasSprite sprite, int tintIndex) {
    List generalQuads = new ArrayList();
    EnumFacing[] facings = EnumFacing.VALUES;
    Map<EnumFacing, List<BakedQuad>> faceQuads = new HashMap<>();
    for (int i = 0; i < facings.length; i++) {
      EnumFacing facing = facings[i];
      List<BakedQuad> quads = new ArrayList();
      quads.add(makeBakedQuad(facing, sprite, tintIndex));
      faceQuads.put(facing, quads);
    } 
    ItemOverrideList itemOverrideList = new ItemOverrideList(new ArrayList());
    return (IBakedModel)new SimpleBakedModel(generalQuads, faceQuads, true, true, sprite, ItemCameraTransforms.DEFAULT, itemOverrideList);
  }
  
  public static IBakedModel joinModelsCube(IBakedModel modelBase, IBakedModel modelAdd) {
    List<BakedQuad> generalQuads = new ArrayList<>();
    generalQuads.addAll(modelBase.getQuads(null, null, 0L));
    generalQuads.addAll(modelAdd.getQuads(null, null, 0L));
    EnumFacing[] facings = EnumFacing.VALUES;
    Map<EnumFacing, List<BakedQuad>> faceQuads = new HashMap<>();
    for (int i = 0; i < facings.length; i++) {
      EnumFacing facing = facings[i];
      List<BakedQuad> quads = new ArrayList();
      quads.addAll(modelBase.getQuads(null, facing, 0L));
      quads.addAll(modelAdd.getQuads(null, facing, 0L));
      faceQuads.put(facing, quads);
    } 
    boolean ao = modelBase.isAmbientOcclusion();
    boolean builtIn = modelBase.isBuiltInRenderer();
    TextureAtlasSprite sprite = modelBase.getParticleTexture();
    ItemCameraTransforms transforms = modelBase.getItemCameraTransforms();
    ItemOverrideList itemOverrideList = modelBase.getOverrides();
    return (IBakedModel)new SimpleBakedModel(generalQuads, faceQuads, ao, builtIn, sprite, transforms, itemOverrideList);
  }
  
  public static BakedQuad makeBakedQuad(EnumFacing facing, TextureAtlasSprite sprite, int tintIndex) {
    Vector3f posFrom = new Vector3f(0.0F, 0.0F, 0.0F);
    Vector3f posTo = new Vector3f(16.0F, 16.0F, 16.0F);
    BlockFaceUV uv = new BlockFaceUV(new float[] { 0.0F, 0.0F, 16.0F, 16.0F }, 0);
    BlockPartFace face = new BlockPartFace(facing, tintIndex, "#" + facing.getName(), uv);
    ModelRotation modelRotation = ModelRotation.X0_Y0;
    BlockPartRotation partRotation = null;
    boolean uvLocked = false;
    boolean shade = true;
    FaceBakery faceBakery = new FaceBakery();
    BakedQuad quad = faceBakery.makeBakedQuad(posFrom, posTo, face, sprite, facing, modelRotation, partRotation, uvLocked, shade);
    return quad;
  }
  
  public static IBakedModel makeModel(String modelName, String spriteOldName, String spriteNewName) {
    TextureMap textureMap = Config.getMinecraft().getTextureMapBlocks();
    TextureAtlasSprite spriteOld = textureMap.getSpriteSafe(spriteOldName);
    TextureAtlasSprite spriteNew = textureMap.getSpriteSafe(spriteNewName);
    return makeModel(modelName, spriteOld, spriteNew);
  }
  
  public static IBakedModel makeModel(String modelName, TextureAtlasSprite spriteOld, TextureAtlasSprite spriteNew) {
    if (spriteOld == null || spriteNew == null)
      return null; 
    ModelManager modelManager = Config.getModelManager();
    if (modelManager == null)
      return null; 
    ModelResourceLocation mrl = new ModelResourceLocation(modelName, "normal");
    IBakedModel model = modelManager.getModel(mrl);
    if (model == null || model == modelManager.getMissingModel())
      return null; 
    IBakedModel modelNew = ModelUtils.duplicateModel(model);
    EnumFacing[] faces = EnumFacing.VALUES;
    for (int i = 0; i < faces.length; i++) {
      EnumFacing face = faces[i];
      List<BakedQuad> quads = modelNew.getQuads(null, face, 0L);
      replaceTexture(quads, spriteOld, spriteNew);
    } 
    List<BakedQuad> quadsGeneral = modelNew.getQuads(null, null, 0L);
    replaceTexture(quadsGeneral, spriteOld, spriteNew);
    return modelNew;
  }
  
  private static void replaceTexture(List<BakedQuad> quads, TextureAtlasSprite spriteOld, TextureAtlasSprite spriteNew) {
    List<BakedQuad> quadsNew = new ArrayList<>();
    for (Iterator<BakedQuad> it = quads.iterator(); it.hasNext(); ) {
      BakedQuadRetextured bakedQuadRetextured;
      BakedQuad quad = it.next();
      if (quad.getSprite() == spriteOld)
        bakedQuadRetextured = new BakedQuadRetextured(quad, spriteNew); 
      quadsNew.add(bakedQuadRetextured);
    } 
    quads.clear();
    quads.addAll(quadsNew);
  }
  
  public static void snapVertexPosition(Vector3f pos) {
    pos.setX(snapVertexCoord(pos.getX()));
    pos.setY(snapVertexCoord(pos.getY()));
    pos.setZ(snapVertexCoord(pos.getZ()));
  }
  
  private static float snapVertexCoord(float x) {
    if (x > -1.0E-6F && x < 1.0E-6F)
      return 0.0F; 
    if (x > 0.999999F && x < 1.000001F)
      return 1.0F; 
    return x;
  }
  
  public static AxisAlignedBB getOffsetBoundingBox(AxisAlignedBB aabb, Block.EnumOffsetType offsetType, BlockPos pos) {
    int x = pos.getX();
    int z = pos.getZ();
    long k = (x * 3129871) ^ z * 116129781L;
    k = k * k * 42317861L + k * 11L;
    double dx = (((float)(k >> 16L & 0xFL) / 15.0F) - 0.5D) * 0.5D;
    double dz = (((float)(k >> 24L & 0xFL) / 15.0F) - 0.5D) * 0.5D;
    double dy = 0.0D;
    if (offsetType == Block.EnumOffsetType.XYZ)
      dy = (((float)(k >> 20L & 0xFL) / 15.0F) - 1.0D) * 0.2D; 
    return aabb.offset(dx, dy, dz);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\model\BlockModelUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */