package net.optifine.shaders;

import java.nio.IntBuffer;
import java.util.Arrays;

public class FlipTextures {
  private IntBuffer textures;
  
  private int indexFlipped;
  
  private boolean[] flips;
  
  private boolean[] changed;
  
  public FlipTextures(IntBuffer textures, int indexFlipped) {
    this.textures = textures;
    this.indexFlipped = indexFlipped;
    this.flips = new boolean[textures.capacity()];
    this.changed = new boolean[textures.capacity()];
  }
  
  public int getA(int index) {
    return get(index, this.flips[index]);
  }
  
  public int getB(int index) {
    return get(index, !this.flips[index]);
  }
  
  private int get(int index, boolean flipped) {
    int indexBase = flipped ? this.indexFlipped : 0;
    return this.textures.get(indexBase + index);
  }
  
  public void flip(int index) {
    this.flips[index] = !this.flips[index];
    this.changed[index] = true;
  }
  
  public boolean isChanged(int index) {
    return this.changed[index];
  }
  
  public void reset() {
    Arrays.fill(this.flips, false);
    Arrays.fill(this.changed, false);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\FlipTextures.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */