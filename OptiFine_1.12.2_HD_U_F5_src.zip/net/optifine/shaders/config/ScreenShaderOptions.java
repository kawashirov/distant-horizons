package net.optifine.shaders.config;

public class ScreenShaderOptions {
  private String name;
  
  private ShaderOption[] shaderOptions;
  
  private int columns;
  
  public ScreenShaderOptions(String name, ShaderOption[] shaderOptions, int columns) {
    this.name = name;
    this.shaderOptions = shaderOptions;
    this.columns = columns;
  }
  
  public String getName() {
    return this.name;
  }
  
  public ShaderOption[] getShaderOptions() {
    return this.shaderOptions;
  }
  
  public int getColumns() {
    return this.columns;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\config\ScreenShaderOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */