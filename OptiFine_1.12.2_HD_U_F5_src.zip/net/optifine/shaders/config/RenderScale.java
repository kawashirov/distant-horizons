package net.optifine.shaders.config;

public class RenderScale {
  private float scale = 1.0F;
  
  private float offsetX = 0.0F;
  
  private float offsetY = 0.0F;
  
  public RenderScale(float scale, float offsetX, float offsetY) {
    this.scale = scale;
    this.offsetX = offsetX;
    this.offsetY = offsetY;
  }
  
  public float getScale() {
    return this.scale;
  }
  
  public float getOffsetX() {
    return this.offsetX;
  }
  
  public float getOffsetY() {
    return this.offsetY;
  }
  
  public String toString() {
    return "" + this.scale + ", " + this.offsetX + ", " + this.offsetY;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\config\RenderScale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */