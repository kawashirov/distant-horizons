package net.optifine.shaders;

public class MultiTexID {
  public int base;
  
  public int norm;
  
  public int spec;
  
  public MultiTexID(int baseTex, int normTex, int specTex) {
    this.base = baseTex;
    this.norm = normTex;
    this.spec = specTex;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\MultiTexID.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */