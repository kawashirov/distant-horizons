package net.optifine.shaders;

import Config;
import com.google.common.base.Joiner;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import net.optifine.util.StrUtils;

public class ShaderPackZip implements IShaderPack {
  protected File packFile;
  
  protected ZipFile packZipFile;
  
  protected String baseFolder;
  
  public ShaderPackZip(String name, File file) {
    this.packFile = file;
    this.packZipFile = null;
    this.baseFolder = "";
  }
  
  public void close() {
    if (this.packZipFile == null)
      return; 
    try {
      this.packZipFile.close();
    } catch (Exception exception) {}
    this.packZipFile = null;
  }
  
  public InputStream getResourceAsStream(String resName) {
    try {
      if (this.packZipFile == null) {
        this.packZipFile = new ZipFile(this.packFile);
        this.baseFolder = detectBaseFolder(this.packZipFile);
      } 
      String name = StrUtils.removePrefix(resName, "/");
      if (name.contains(".."))
        name = resolveRelative(name); 
      ZipEntry entry = this.packZipFile.getEntry(this.baseFolder + name);
      if (entry == null)
        return null; 
      return this.packZipFile.getInputStream(entry);
    } catch (Exception excp) {
      return null;
    } 
  }
  
  private String resolveRelative(String name) {
    Deque<String> stack = new ArrayDeque<>();
    String[] parts = Config.tokenize(name, "/");
    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      if (part.equals("..")) {
        if (stack.isEmpty())
          return ""; 
        stack.removeLast();
      } else {
        stack.add(part);
      } 
    } 
    String path = Joiner.on('/').join(stack);
    return path;
  }
  
  private String detectBaseFolder(ZipFile zip) {
    ZipEntry entryShaders = zip.getEntry("shaders/");
    if (entryShaders != null)
      if (entryShaders.isDirectory())
        return "";  
    Pattern patternFolderShaders = Pattern.compile("([^/]+/)shaders/");
    Enumeration<? extends ZipEntry> entries = zip.entries();
    while (entries.hasMoreElements()) {
      ZipEntry entry = entries.nextElement();
      String name = entry.getName();
      Matcher matcher = patternFolderShaders.matcher(name);
      if (matcher.matches()) {
        String base = matcher.group(1);
        if (base == null)
          continue; 
        if (base.equals("shaders/"))
          return ""; 
        return base;
      } 
    } 
    return "";
  }
  
  public boolean hasDirectory(String resName) {
    try {
      if (this.packZipFile == null) {
        this.packZipFile = new ZipFile(this.packFile);
        this.baseFolder = detectBaseFolder(this.packZipFile);
      } 
      String name = StrUtils.removePrefix(resName, "/");
      ZipEntry entry = this.packZipFile.getEntry(this.baseFolder + name);
      if (entry == null)
        return false; 
      return true;
    } catch (IOException e) {
      return false;
    } 
  }
  
  public String getName() {
    return this.packFile.getName();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ShaderPackZip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */