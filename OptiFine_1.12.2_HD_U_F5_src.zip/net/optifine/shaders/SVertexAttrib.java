package net.optifine.shaders;

import net.minecraft.client.renderer.vertex.VertexFormatElement;

public class SVertexAttrib {
  public int index;
  
  public int count;
  
  public VertexFormatElement.EnumType type;
  
  public int offset;
  
  public SVertexAttrib(int index, int count, VertexFormatElement.EnumType type) {
    this.index = index;
    this.count = count;
    this.type = type;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\SVertexAttrib.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */