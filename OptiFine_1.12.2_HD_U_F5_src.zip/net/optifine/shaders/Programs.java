package net.optifine.shaders;

import java.util.ArrayList;
import java.util.List;

public class Programs {
  private List<Program> programs = new ArrayList<>();
  
  private Program programNone = make("", ProgramStage.NONE, true);
  
  public Program make(String name, ProgramStage programStage, Program backupProgram) {
    int index = this.programs.size();
    Program prog = new Program(index, name, programStage, backupProgram);
    this.programs.add(prog);
    return prog;
  }
  
  private Program make(String name, ProgramStage programStage, boolean ownBackup) {
    int index = this.programs.size();
    Program prog = new Program(index, name, programStage, ownBackup);
    this.programs.add(prog);
    return prog;
  }
  
  public Program makeGbuffers(String name, Program backupProgram) {
    return make(name, ProgramStage.GBUFFERS, backupProgram);
  }
  
  public Program makeComposite(String name) {
    return make(name, ProgramStage.COMPOSITE, this.programNone);
  }
  
  public Program makeDeferred(String name) {
    return make(name, ProgramStage.DEFERRED, this.programNone);
  }
  
  public Program makeShadow(String name, Program backupProgram) {
    return make(name, ProgramStage.SHADOW, backupProgram);
  }
  
  public Program makeVirtual(String name) {
    return make(name, ProgramStage.NONE, true);
  }
  
  public Program[] makeComposites(String prefix, int count) {
    Program[] ps = new Program[count];
    for (int i = 0; i < count; i++) {
      String name = (i == 0) ? prefix : (prefix + i);
      ps[i] = makeComposite(name);
    } 
    return ps;
  }
  
  public Program[] makeDeferreds(String prefix, int count) {
    Program[] ps = new Program[count];
    for (int i = 0; i < count; i++) {
      String name = (i == 0) ? prefix : (prefix + i);
      ps[i] = makeDeferred(name);
    } 
    return ps;
  }
  
  public Program getProgramNone() {
    return this.programNone;
  }
  
  public int getCount() {
    return this.programs.size();
  }
  
  public Program getProgram(String name) {
    if (name == null)
      return null; 
    for (int i = 0; i < this.programs.size(); i++) {
      Program p = this.programs.get(i);
      String progName = p.getName();
      if (progName.equals(name))
        return p; 
    } 
    return null;
  }
  
  public String[] getProgramNames() {
    String[] names = new String[this.programs.size()];
    for (int i = 0; i < names.length; i++)
      names[i] = ((Program)this.programs.get(i)).getName(); 
    return names;
  }
  
  public Program[] getPrograms() {
    Program[] arr = this.programs.<Program>toArray(new Program[this.programs.size()]);
    return arr;
  }
  
  public Program[] getPrograms(Program programFrom, Program programTo) {
    int iFrom = programFrom.getIndex();
    int iTo = programTo.getIndex();
    if (iFrom > iTo) {
      int j = iFrom;
      iFrom = iTo;
      iTo = j;
    } 
    Program[] progs = new Program[iTo - iFrom + 1];
    for (int i = 0; i < progs.length; i++)
      progs[i] = this.programs.get(iFrom + i); 
    return progs;
  }
  
  public String toString() {
    return this.programs.toString();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\Programs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */