package net.optifine.shaders;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import net.optifine.util.StrUtils;

public class ShaderPackFolder implements IShaderPack {
  protected File packFile;
  
  public ShaderPackFolder(String name, File file) {
    this.packFile = file;
  }
  
  public void close() {}
  
  public InputStream getResourceAsStream(String resName) {
    try {
      String name = StrUtils.removePrefixSuffix(resName, "/", "/");
      File resFile = new File(this.packFile, name);
      if (!resFile.exists())
        return null; 
      return new BufferedInputStream(new FileInputStream(resFile));
    } catch (Exception excp) {
      return null;
    } 
  }
  
  public boolean hasDirectory(String name) {
    File resFile = new File(this.packFile, name.substring(1));
    if (!resFile.exists())
      return false; 
    if (!resFile.isDirectory())
      return false; 
    return true;
  }
  
  public String getName() {
    return this.packFile.getName();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ShaderPackFolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */