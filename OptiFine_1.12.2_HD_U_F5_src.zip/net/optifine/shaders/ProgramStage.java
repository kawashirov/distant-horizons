package net.optifine.shaders;

public enum ProgramStage {
  NONE(""),
  SHADOW("shadow"),
  GBUFFERS("gbuffers"),
  DEFERRED("deferred"),
  COMPOSITE("composite");
  
  private String name;
  
  ProgramStage(String name) {
    this.name = name;
  }
  
  public String getName() {
    return this.name;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ProgramStage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */