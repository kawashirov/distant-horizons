package net.optifine.shaders.uniform;

import java.util.HashMap;
import java.util.Map;
import net.optifine.util.CounterInt;
import net.optifine.util.SmoothFloat;

public class Smoother {
  private static Map<Integer, SmoothFloat> mapSmoothValues = new HashMap<>();
  
  private static CounterInt counterIds = new CounterInt(1);
  
  public static float getSmoothValue(int id, float value, float timeFadeUpSec, float timeFadeDownSec) {
    synchronized (mapSmoothValues) {
      Integer key = Integer.valueOf(id);
      SmoothFloat sf = mapSmoothValues.get(key);
      if (sf == null) {
        sf = new SmoothFloat(value, timeFadeUpSec, timeFadeDownSec);
        mapSmoothValues.put(key, sf);
      } 
      float valueSmooth = sf.getSmoothValue(value, timeFadeUpSec, timeFadeDownSec);
      return valueSmooth;
    } 
  }
  
  public static int getNextId() {
    synchronized (counterIds) {
      return counterIds.nextValue();
    } 
  }
  
  public static void resetValues() {
    synchronized (mapSmoothValues) {
      mapSmoothValues.clear();
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shader\\uniform\Smoother.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */