package net.optifine.shaders.uniform;

import net.optifine.expr.IExpression;
import net.optifine.shaders.SMCLog;

public class CustomUniform {
  private String name;
  
  private UniformType type;
  
  private IExpression expression;
  
  private ShaderUniformBase shaderUniform;
  
  public CustomUniform(String name, UniformType type, IExpression expression) {
    this.name = name;
    this.type = type;
    this.expression = expression;
    this.shaderUniform = type.makeShaderUniform(name);
  }
  
  public void setProgram(int program) {
    this.shaderUniform.setProgram(program);
  }
  
  public void update() {
    if (!this.shaderUniform.isDefined())
      return; 
    try {
      this.type.updateUniform(this.expression, this.shaderUniform);
    } catch (RuntimeException e) {
      SMCLog.severe("Error updating custom uniform: " + this.shaderUniform.getName());
      SMCLog.severe(e.getClass().getName() + ": " + e.getMessage());
      this.shaderUniform.disable();
      SMCLog.severe("Custom uniform disabled: " + this.shaderUniform.getName());
    } 
  }
  
  public void reset() {
    this.shaderUniform.reset();
  }
  
  public String getName() {
    return this.name;
  }
  
  public UniformType getType() {
    return this.type;
  }
  
  public IExpression getExpression() {
    return this.expression;
  }
  
  public ShaderUniformBase getShaderUniform() {
    return this.shaderUniform;
  }
  
  public String toString() {
    return this.type.name().toLowerCase() + " " + this.name;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shader\\uniform\CustomUniform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */