package net.optifine.shaders.uniform;

import net.optifine.expr.ExpressionType;
import net.optifine.expr.IExpression;
import net.optifine.expr.IExpressionBool;
import net.optifine.expr.IExpressionFloat;
import net.optifine.expr.IExpressionFloatArray;

public enum UniformType {
  BOOL, INT, FLOAT, VEC2, VEC3, VEC4;
  
  public ShaderUniformBase makeShaderUniform(String name) {
    switch (this) {
      case BOOL:
        return new ShaderUniform1i(name);
      case INT:
        return new ShaderUniform1i(name);
      case FLOAT:
        return new ShaderUniform1f(name);
      case VEC2:
        return new ShaderUniform2f(name);
      case VEC3:
        return new ShaderUniform3f(name);
      case VEC4:
        return new ShaderUniform4f(name);
    } 
    throw new RuntimeException("Unknown uniform type: " + this);
  }
  
  public void updateUniform(IExpression expression, ShaderUniformBase uniform) {
    switch (this) {
      case BOOL:
        updateUniformBool((IExpressionBool)expression, (ShaderUniform1i)uniform);
        return;
      case INT:
        updateUniformInt((IExpressionFloat)expression, (ShaderUniform1i)uniform);
        return;
      case FLOAT:
        updateUniformFloat((IExpressionFloat)expression, (ShaderUniform1f)uniform);
        return;
      case VEC2:
        updateUniformFloat2((IExpressionFloatArray)expression, (ShaderUniform2f)uniform);
        return;
      case VEC3:
        updateUniformFloat3((IExpressionFloatArray)expression, (ShaderUniform3f)uniform);
        return;
      case VEC4:
        updateUniformFloat4((IExpressionFloatArray)expression, (ShaderUniform4f)uniform);
        return;
    } 
    throw new RuntimeException("Unknown uniform type: " + this);
  }
  
  private void updateUniformBool(IExpressionBool expression, ShaderUniform1i uniform) {
    boolean val = expression.eval();
    int valInt = val ? 1 : 0;
    uniform.setValue(valInt);
  }
  
  private void updateUniformInt(IExpressionFloat expression, ShaderUniform1i uniform) {
    int val = (int)expression.eval();
    uniform.setValue(val);
  }
  
  private void updateUniformFloat(IExpressionFloat expression, ShaderUniform1f uniform) {
    float val = expression.eval();
    uniform.setValue(val);
  }
  
  private void updateUniformFloat2(IExpressionFloatArray expression, ShaderUniform2f uniform) {
    float[] val = expression.eval();
    if (val.length != 2)
      throw new RuntimeException("Value length is not 2, length: " + val.length); 
    uniform.setValue(val[0], val[1]);
  }
  
  private void updateUniformFloat3(IExpressionFloatArray expression, ShaderUniform3f uniform) {
    float[] val = expression.eval();
    if (val.length != 3)
      throw new RuntimeException("Value length is not 3, length: " + val.length); 
    uniform.setValue(val[0], val[1], val[2]);
  }
  
  private void updateUniformFloat4(IExpressionFloatArray expression, ShaderUniform4f uniform) {
    float[] val = expression.eval();
    if (val.length != 4)
      throw new RuntimeException("Value length is not 4, length: " + val.length); 
    uniform.setValue(val[0], val[1], val[2], val[3]);
  }
  
  public boolean matchesExpressionType(ExpressionType expressionType) {
    switch (this) {
      case BOOL:
        return (expressionType == ExpressionType.BOOL);
      case INT:
        return (expressionType == ExpressionType.FLOAT);
      case FLOAT:
        return (expressionType == ExpressionType.FLOAT);
      case VEC2:
      case VEC3:
      case VEC4:
        return (expressionType == ExpressionType.FLOAT_ARRAY);
    } 
    throw new RuntimeException("Unknown uniform type: " + this);
  }
  
  public static UniformType parse(String type) {
    UniformType[] values = values();
    for (int i = 0; i < values.length; i++) {
      UniformType uniformType = values[i];
      if (uniformType.name().toLowerCase().equals(type))
        return uniformType; 
    } 
    return null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shader\\uniform\UniformType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */