package net.optifine.shaders.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

public class GuiButtonDownloadShaders extends GuiButton {
  public GuiButtonDownloadShaders(int buttonID, int xPos, int yPos) {
    super(buttonID, xPos, yPos, 22, 20, "");
  }
  
  public void drawButton(Minecraft mc, int mouseX, int mouseY, float partialTicks) {
    if (!this.visible)
      return; 
    super.drawButton(mc, mouseX, mouseY, partialTicks);
    ResourceLocation locTexture = new ResourceLocation("optifine/textures/icons.png");
    mc.getTextureManager().bindTexture(locTexture);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    drawTexturedModalRect(this.x + 3, this.y + 2, 0, 0, 16, 16);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\gui\GuiButtonDownloadShaders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */