package net.optifine.shaders.gui;

import net.minecraft.client.gui.GuiButton;
import net.optifine.shaders.config.ShaderOption;

public class GuiButtonShaderOption extends GuiButton {
  private ShaderOption shaderOption = null;
  
  public GuiButtonShaderOption(int buttonId, int x, int y, int widthIn, int heightIn, ShaderOption shaderOption, String text) {
    super(buttonId, x, y, widthIn, heightIn, text);
    this.shaderOption = shaderOption;
  }
  
  public ShaderOption getShaderOption() {
    return this.shaderOption;
  }
  
  public void valueChanged() {}
  
  public boolean isSwitchable() {
    return true;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\gui\GuiButtonShaderOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */