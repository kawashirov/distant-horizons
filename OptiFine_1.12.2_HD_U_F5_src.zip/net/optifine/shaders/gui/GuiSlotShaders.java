package net.optifine.shaders.gui;

import Config;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.resources.I18n;
import net.optifine.Lang;
import net.optifine.shaders.IShaderPack;
import net.optifine.shaders.Shaders;
import net.optifine.util.ResUtils;

class GuiSlotShaders extends GuiSlot {
  private ArrayList shaderslist;
  
  private int selectedIndex;
  
  private long lastClickedCached = 0L;
  
  final GuiShaders shadersGui;
  
  public GuiSlotShaders(GuiShaders par1GuiShaders, int width, int height, int top, int bottom, int slotHeight) {
    super(par1GuiShaders.getMc(), width, height, top, bottom, slotHeight);
    this.shadersGui = par1GuiShaders;
    updateList();
    this.amountScrolled = 0.0F;
    int posYSelected = this.selectedIndex * slotHeight;
    int wMid = (bottom - top) / 2;
    if (posYSelected > wMid)
      scrollBy(posYSelected - wMid); 
  }
  
  public int getListWidth() {
    return this.width - 20;
  }
  
  public void updateList() {
    this.shaderslist = Shaders.listOfShaders();
    this.selectedIndex = 0;
    for (int i = 0, n = this.shaderslist.size(); i < n; i++) {
      if (((String)this.shaderslist.get(i)).equals(Shaders.currentShaderName)) {
        this.selectedIndex = i;
        break;
      } 
    } 
  }
  
  protected int getSize() {
    return this.shaderslist.size();
  }
  
  protected void elementClicked(int index, boolean doubleClicked, int mouseX, int mouseY) {
    if (index == this.selectedIndex && this.lastClicked == this.lastClickedCached)
      return; 
    String name = this.shaderslist.get(index);
    IShaderPack sp = Shaders.getShaderPack(name);
    if (!checkCompatible(sp, index))
      return; 
    selectIndex(index);
  }
  
  private void selectIndex(int index) {
    this.selectedIndex = index;
    this.lastClickedCached = this.lastClicked;
    Shaders.setShaderPack(this.shaderslist.get(index));
    Shaders.uninit();
    this.shadersGui.updateButtons();
  }
  
  private boolean checkCompatible(IShaderPack sp, int index) {
    if (sp == null)
      return true; 
    InputStream in = sp.getResourceAsStream("/shaders/shaders.properties");
    Properties props = ResUtils.readProperties(in, "Shaders");
    if (props == null)
      return true; 
    String keyVer = "version.1.12.2";
    String relMin = props.getProperty(keyVer);
    if (relMin == null)
      return true; 
    relMin = relMin.trim();
    String rel = "F5";
    int res = Config.compareRelease(rel, relMin);
    if (res >= 0)
      return true; 
    String verMin = ("HD_U_" + relMin).replace('_', ' ');
    String msg1 = I18n.format("of.message.shaders.nv1", new Object[] { verMin });
    String msg2 = I18n.format("of.message.shaders.nv2", new Object[0]);
    final int theIndex = index;
    GuiYesNoCallback callback = new GuiYesNoCallback() {
        public void confirmClicked(boolean result, int id) {
          if (result)
            GuiSlotShaders.this.selectIndex(theIndex); 
          GuiSlotShaders.this.mc.displayGuiScreen(GuiSlotShaders.this.shadersGui);
        }
      };
    GuiYesNo guiYesNo = new GuiYesNo(callback, msg1, msg2, 0);
    this.mc.displayGuiScreen((GuiScreen)guiYesNo);
    return false;
  }
  
  protected boolean isSelected(int index) {
    return (index == this.selectedIndex);
  }
  
  protected int getScrollBarX() {
    return this.width - 6;
  }
  
  protected int getContentHeight() {
    return getSize() * 18;
  }
  
  protected void drawBackground() {}
  
  protected void drawSlot(int index, int posX, int posY, int contentY, int mouseX, int mouseY, float partialTicks) {
    String label = this.shaderslist.get(index);
    if (label.equals("OFF")) {
      label = Lang.get("of.options.shaders.packNone");
    } else if (label.equals("(internal)")) {
      label = Lang.get("of.options.shaders.packDefault");
    } 
    this.shadersGui.drawCenteredString(label, this.width / 2, posY + 1, 14737632);
  }
  
  public int getSelectedIndex() {
    return this.selectedIndex;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\gui\GuiSlotShaders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */