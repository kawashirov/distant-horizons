package net.optifine.shaders.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import net.optifine.shaders.config.ShaderOption;

public class GuiSliderShaderOption extends GuiButtonShaderOption {
  private float sliderValue;
  
  public boolean dragging;
  
  private ShaderOption shaderOption = null;
  
  public GuiSliderShaderOption(int buttonId, int x, int y, int w, int h, ShaderOption shaderOption, String text) {
    super(buttonId, x, y, w, h, shaderOption, text);
    this.sliderValue = 1.0F;
    this.shaderOption = shaderOption;
    this.sliderValue = shaderOption.getIndexNormalized();
    this.displayString = GuiShaderOptions.getButtonText(shaderOption, this.width);
  }
  
  protected int getHoverState(boolean mouseOver) {
    return 0;
  }
  
  protected void mouseDragged(Minecraft mc, int mouseX, int mouseY) {
    if (this.visible) {
      if (this.dragging && !GuiScreen.isShiftKeyDown()) {
        this.sliderValue = (mouseX - this.x + 4) / (this.width - 8);
        this.sliderValue = MathHelper.clamp(this.sliderValue, 0.0F, 1.0F);
        this.shaderOption.setIndexNormalized(this.sliderValue);
        this.sliderValue = this.shaderOption.getIndexNormalized();
        this.displayString = GuiShaderOptions.getButtonText(this.shaderOption, this.width);
      } 
      mc.getTextureManager().bindTexture(BUTTON_TEXTURES);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      drawTexturedModalRect(this.x + (int)(this.sliderValue * (this.width - 8)), this.y, 0, 66, 4, 20);
      drawTexturedModalRect(this.x + (int)(this.sliderValue * (this.width - 8)) + 4, this.y, 196, 66, 4, 20);
    } 
  }
  
  public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
    if (super.mousePressed(mc, mouseX, mouseY)) {
      this.sliderValue = (mouseX - this.x + 4) / (this.width - 8);
      this.sliderValue = MathHelper.clamp(this.sliderValue, 0.0F, 1.0F);
      this.shaderOption.setIndexNormalized(this.sliderValue);
      this.displayString = GuiShaderOptions.getButtonText(this.shaderOption, this.width);
      this.dragging = true;
      return true;
    } 
    return false;
  }
  
  public void mouseReleased(int mouseX, int mouseY) {
    this.dragging = false;
  }
  
  public void valueChanged() {
    this.sliderValue = this.shaderOption.getIndexNormalized();
  }
  
  public boolean isSwitchable() {
    return false;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\gui\GuiSliderShaderOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */