package net.optifine.shaders;

import java.util.ArrayDeque;
import java.util.Deque;

public class ProgramStack {
  private Deque<Program> stack = new ArrayDeque<>();
  
  public void push(Program p) {
    this.stack.addLast(p);
  }
  
  public Program pop() {
    if (this.stack.isEmpty())
      return Shaders.ProgramNone; 
    Program p = this.stack.pollLast();
    return p;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ProgramStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */