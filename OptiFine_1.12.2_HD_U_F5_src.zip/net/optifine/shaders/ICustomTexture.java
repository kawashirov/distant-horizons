package net.optifine.shaders;

public interface ICustomTexture {
  int getTextureId();
  
  int getTextureUnit();
  
  void deleteTexture();
  
  default int getTarget() {
    return 3553;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ICustomTexture.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */