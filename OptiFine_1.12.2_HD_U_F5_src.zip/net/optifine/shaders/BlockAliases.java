package net.optifine.shaders;

import Config;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.optifine.config.ConnectedParser;
import net.optifine.config.MatchBlock;
import net.optifine.reflect.Reflector;
import net.optifine.reflect.ReflectorForge;
import net.optifine.shaders.config.MacroProcessor;
import net.optifine.util.PropertiesOrdered;
import net.optifine.util.StrUtils;

public class BlockAliases {
  private static BlockAlias[][] blockAliases = (BlockAlias[][])null;
  
  private static PropertiesOrdered blockLayerPropertes = null;
  
  private static boolean updateOnResourcesReloaded;
  
  public static int getBlockAliasId(int blockId, int metadata) {
    if (blockAliases == null)
      return blockId; 
    if (blockId < 0 || blockId >= blockAliases.length)
      return blockId; 
    BlockAlias[] aliases = blockAliases[blockId];
    if (aliases == null)
      return blockId; 
    for (int i = 0; i < aliases.length; i++) {
      BlockAlias ba = aliases[i];
      if (ba.matches(blockId, metadata))
        return ba.getBlockAliasId(); 
    } 
    return blockId;
  }
  
  public static void resourcesReloaded() {
    if (!updateOnResourcesReloaded)
      return; 
    updateOnResourcesReloaded = false;
    update(Shaders.getShaderPack());
  }
  
  public static void update(IShaderPack shaderPack) {
    reset();
    if (shaderPack == null)
      return; 
    if (Reflector.Loader_getActiveModList.exists() && Minecraft.getMinecraft().getResourcePackRepository() == null) {
      Config.dbg("[Shaders] Delayed loading of block mappings after resources are loaded");
      updateOnResourcesReloaded = true;
      return;
    } 
    List<List<BlockAlias>> listBlockAliases = new ArrayList<>();
    String path = "/shaders/block.properties";
    InputStream in = shaderPack.getResourceAsStream(path);
    if (in != null)
      loadBlockAliases(in, path, listBlockAliases); 
    loadModBlockAliases(listBlockAliases);
    if (listBlockAliases.size() <= 0)
      return; 
    blockAliases = toArrays(listBlockAliases);
  }
  
  private static void loadModBlockAliases(List<List<BlockAlias>> listBlockAliases) {
    String[] modIds = ReflectorForge.getForgeModIds();
    for (int i = 0; i < modIds.length; i++) {
      String modId = modIds[i];
      try {
        ResourceLocation loc = new ResourceLocation(modId, "shaders/block.properties");
        InputStream in = Config.getResourceStream(loc);
        loadBlockAliases(in, loc.toString(), listBlockAliases);
      } catch (IOException iOException) {}
    } 
  }
  
  private static void loadBlockAliases(InputStream in, String path, List<List<BlockAlias>> listBlockAliases) {
    if (in == null)
      return; 
    try {
      in = MacroProcessor.process(in, path);
      PropertiesOrdered propertiesOrdered = new PropertiesOrdered();
      propertiesOrdered.load(in);
      in.close();
      Config.dbg("[Shaders] Parsing block mappings: " + path);
      ConnectedParser cp = new ConnectedParser("Shaders");
      Set<Object> keys = propertiesOrdered.keySet();
      for (Iterator<String> it = keys.iterator(); it.hasNext(); ) {
        String key = it.next();
        String val = propertiesOrdered.getProperty(key);
        if (key.startsWith("layer.")) {
          if (blockLayerPropertes == null)
            blockLayerPropertes = new PropertiesOrdered(); 
          blockLayerPropertes.put(key, val);
          continue;
        } 
        String prefix = "block.";
        if (!key.startsWith(prefix)) {
          Config.warn("[Shaders] Invalid block ID: " + key);
          continue;
        } 
        String blockIdStr = StrUtils.removePrefix(key, prefix);
        int blockId = Config.parseInt(blockIdStr, -1);
        if (blockId < 0) {
          Config.warn("[Shaders] Invalid block ID: " + key);
          continue;
        } 
        MatchBlock[] matchBlocks = cp.parseMatchBlocks(val);
        if (matchBlocks == null || matchBlocks.length < 1) {
          Config.warn("[Shaders] Invalid block ID mapping: " + key + "=" + val);
          continue;
        } 
        BlockAlias ba = new BlockAlias(blockId, matchBlocks);
        addToList(listBlockAliases, ba);
      } 
    } catch (IOException e) {
      Config.warn("[Shaders] Error reading: " + path);
    } 
  }
  
  private static void addToList(List<List<BlockAlias>> blocksAliases, BlockAlias ba) {
    int[] blockIds = ba.getMatchBlockIds();
    for (int i = 0; i < blockIds.length; i++) {
      int blockId = blockIds[i];
      while (blockId >= blocksAliases.size())
        blocksAliases.add(null); 
      List<BlockAlias> blockAliases = blocksAliases.get(blockId);
      if (blockAliases == null) {
        blockAliases = new ArrayList<>();
        blocksAliases.set(blockId, blockAliases);
      } 
      BlockAlias baBlock = new BlockAlias(ba.getBlockAliasId(), ba.getMatchBlocks(blockId));
      blockAliases.add(baBlock);
    } 
  }
  
  private static BlockAlias[][] toArrays(List<List<BlockAlias>> listBlocksAliases) {
    BlockAlias[][] bas = new BlockAlias[listBlocksAliases.size()][];
    for (int i = 0; i < bas.length; i++) {
      List<BlockAlias> listBlockAliases = listBlocksAliases.get(i);
      if (listBlockAliases != null)
        bas[i] = listBlockAliases.<BlockAlias>toArray(new BlockAlias[listBlockAliases.size()]); 
    } 
    return bas;
  }
  
  public static PropertiesOrdered getBlockLayerPropertes() {
    return blockLayerPropertes;
  }
  
  public static void reset() {
    blockAliases = (BlockAlias[][])null;
    blockLayerPropertes = null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\BlockAliases.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */