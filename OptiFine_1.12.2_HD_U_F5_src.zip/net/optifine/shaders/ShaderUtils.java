package net.optifine.shaders;

import Config;
import net.optifine.shaders.config.ShaderOption;
import net.optifine.shaders.config.ShaderProfile;

public class ShaderUtils {
  public static ShaderOption getShaderOption(String name, ShaderOption[] opts) {
    if (opts == null)
      return null; 
    for (int i = 0; i < opts.length; i++) {
      ShaderOption so = opts[i];
      if (so.getName().equals(name))
        return so; 
    } 
    return null;
  }
  
  public static ShaderProfile detectProfile(ShaderProfile[] profs, ShaderOption[] opts, boolean def) {
    if (profs == null)
      return null; 
    for (int i = 0; i < profs.length; i++) {
      ShaderProfile prof = profs[i];
      if (matchProfile(prof, opts, def))
        return prof; 
    } 
    return null;
  }
  
  public static boolean matchProfile(ShaderProfile prof, ShaderOption[] opts, boolean def) {
    if (prof == null)
      return false; 
    if (opts == null)
      return false; 
    String[] optsProf = prof.getOptions();
    for (int p = 0; p < optsProf.length; p++) {
      String opt = optsProf[p];
      ShaderOption so = getShaderOption(opt, opts);
      if (so != null) {
        String optVal = def ? so.getValueDefault() : so.getValue();
        String profVal = prof.getValue(opt);
        if (!Config.equals(optVal, profVal))
          return false; 
      } 
    } 
    return true;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ShaderUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */