package net.optifine.shaders;

import java.io.InputStream;

public class ShaderPackNone implements IShaderPack {
  public void close() {}
  
  public InputStream getResourceAsStream(String resName) {
    return null;
  }
  
  public boolean hasDirectory(String name) {
    return false;
  }
  
  public String getName() {
    return "OFF";
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ShaderPackNone.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */