package net.optifine.shaders;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public abstract class SMCLog {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private static final String PREFIX = "[Shaders] ";
  
  public static void severe(String message) {
    LOGGER.error("[Shaders] " + message);
  }
  
  public static void warning(String message) {
    LOGGER.warn("[Shaders] " + message);
  }
  
  public static void info(String message) {
    LOGGER.info("[Shaders] " + message);
  }
  
  public static void fine(String message) {
    LOGGER.debug("[Shaders] " + message);
  }
  
  public static void severe(String format, Object... args) {
    String message = String.format(format, args);
    LOGGER.error("[Shaders] " + message);
  }
  
  public static void warning(String format, Object... args) {
    String message = String.format(format, args);
    LOGGER.warn("[Shaders] " + message);
  }
  
  public static void info(String format, Object... args) {
    String message = String.format(format, args);
    LOGGER.info("[Shaders] " + message);
  }
  
  public static void fine(String format, Object... args) {
    String message = String.format(format, args);
    LOGGER.debug("[Shaders] " + message);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\SMCLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */