package net.optifine.shaders;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.ViewFrustum;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class ShadowUtils {
  public static Iterator<RenderChunk> makeShadowChunkIterator(WorldClient world, double partialTicks, Entity viewEntity, int renderDistanceChunks, ViewFrustum viewFrustum) {
    float shadowRenderDistance = Shaders.getShadowRenderDistance();
    if (shadowRenderDistance <= 0.0F || shadowRenderDistance >= ((renderDistanceChunks - 1) * 16)) {
      List<RenderChunk> listChunks = Arrays.asList(viewFrustum.renderChunks);
      Iterator<RenderChunk> iterator = listChunks.iterator();
      return iterator;
    } 
    int shadowDistanceChunks = MathHelper.ceil(shadowRenderDistance / 16.0F) + 1;
    float car = world.getCelestialAngleRadians((float)partialTicks);
    float sunTiltRad = Shaders.sunPathRotation * MathHelper.deg2Rad;
    float sar = (car > MathHelper.PId2 && car < 3.0F * MathHelper.PId2) ? (car + MathHelper.PI) : car;
    float dx = -MathHelper.sin(sar);
    float dy = MathHelper.cos(sar) * MathHelper.cos(sunTiltRad);
    float dz = -MathHelper.cos(sar) * MathHelper.sin(sunTiltRad);
    BlockPos posEntity = new BlockPos(MathHelper.floor(viewEntity.posX) >> 4, MathHelper.floor(viewEntity.posY) >> 4, MathHelper.floor(viewEntity.posZ) >> 4);
    BlockPos posStart = posEntity.add((-dx * shadowDistanceChunks), (-dy * shadowDistanceChunks), (-dz * shadowDistanceChunks));
    BlockPos posEnd = posEntity.add((dx * renderDistanceChunks), (dy * renderDistanceChunks), (dz * renderDistanceChunks));
    IteratorRenderChunks it = new IteratorRenderChunks(viewFrustum, posStart, posEnd, shadowDistanceChunks, shadowDistanceChunks);
    return it;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\ShadowUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */