package net.optifine.shaders;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.data.AnimationMetadataSection;
import net.minecraft.client.resources.data.AnimationMetadataSectionSerializer;
import net.minecraft.client.resources.data.FontMetadataSection;
import net.minecraft.client.resources.data.FontMetadataSectionSerializer;
import net.minecraft.client.resources.data.IMetadataSectionSerializer;
import net.minecraft.client.resources.data.LanguageMetadataSection;
import net.minecraft.client.resources.data.LanguageMetadataSectionSerializer;
import net.minecraft.client.resources.data.MetadataSerializer;
import net.minecraft.client.resources.data.PackMetadataSection;
import net.minecraft.client.resources.data.PackMetadataSectionSerializer;
import net.minecraft.client.resources.data.TextureMetadataSection;
import net.minecraft.client.resources.data.TextureMetadataSectionSerializer;
import org.apache.commons.io.IOUtils;

public class SimpleShaderTexture extends AbstractTexture {
  private String texturePath;
  
  private static final MetadataSerializer METADATA_SERIALIZER = makeMetadataSerializer();
  
  public SimpleShaderTexture(String texturePath) {
    this.texturePath = texturePath;
  }
  
  public void loadTexture(IResourceManager resourceManager) throws IOException {
    deleteGlTexture();
    InputStream inputStream = Shaders.getShaderPackResourceStream(this.texturePath);
    if (inputStream == null)
      throw new FileNotFoundException("Shader texture not found: " + this.texturePath); 
    try {
      BufferedImage bufferedimage = TextureUtil.readBufferedImage(inputStream);
      TextureMetadataSection tms = loadTextureMetadataSection();
      TextureUtil.uploadTextureImageAllocate(getGlTextureId(), bufferedimage, tms.getTextureBlur(), tms.getTextureClamp());
    } finally {
      IOUtils.closeQuietly(inputStream);
    } 
  }
  
  private TextureMetadataSection loadTextureMetadataSection() {
    String pathMeta = this.texturePath + ".mcmeta";
    String sectionName = "texture";
    InputStream inMeta = Shaders.getShaderPackResourceStream(pathMeta);
    if (inMeta != null) {
      MetadataSerializer ms = METADATA_SERIALIZER;
      BufferedReader brMeta = new BufferedReader(new InputStreamReader(inMeta));
      try {
        JsonObject jsonMeta = (new JsonParser()).parse(brMeta).getAsJsonObject();
        TextureMetadataSection meta = (TextureMetadataSection)ms.parseMetadataSection(sectionName, jsonMeta);
        if (meta != null)
          return meta; 
      } catch (RuntimeException re) {
        SMCLog.warning("Error reading metadata: " + pathMeta);
        SMCLog.warning("" + re.getClass().getName() + ": " + re.getMessage());
      } finally {
        IOUtils.closeQuietly(brMeta);
        IOUtils.closeQuietly(inMeta);
      } 
    } 
    return new TextureMetadataSection(false, false);
  }
  
  private static MetadataSerializer makeMetadataSerializer() {
    MetadataSerializer ms = new MetadataSerializer();
    ms.registerMetadataSectionType((IMetadataSectionSerializer)new TextureMetadataSectionSerializer(), TextureMetadataSection.class);
    ms.registerMetadataSectionType((IMetadataSectionSerializer)new FontMetadataSectionSerializer(), FontMetadataSection.class);
    ms.registerMetadataSectionType((IMetadataSectionSerializer)new AnimationMetadataSectionSerializer(), AnimationMetadataSection.class);
    ms.registerMetadataSectionType((IMetadataSectionSerializer)new PackMetadataSectionSerializer(), PackMetadataSection.class);
    ms.registerMetadataSectionType((IMetadataSectionSerializer)new LanguageMetadataSectionSerializer(), LanguageMetadataSection.class);
    return ms;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\shaders\SimpleShaderTexture.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */