package net.optifine.util;

import Config;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.optifine.reflect.Reflector;
import net.optifine.reflect.ReflectorClass;
import net.optifine.reflect.ReflectorField;

public class ChunkUtils {
  private static ReflectorClass chunkClass = new ReflectorClass(Chunk.class);
  
  private static ReflectorField fieldHasEntities = findFieldHasEntities();
  
  private static ReflectorField fieldPrecipitationHeightMap = new ReflectorField(chunkClass, int[].class, 0);
  
  public static boolean hasEntities(Chunk chunk) {
    return Reflector.getFieldValueBoolean(chunk, fieldHasEntities, true);
  }
  
  public static int getPrecipitationHeight(Chunk chunk, BlockPos pos) {
    int[] precipitationHeightMap = (int[])Reflector.getFieldValue(chunk, fieldPrecipitationHeightMap);
    if (precipitationHeightMap == null || precipitationHeightMap.length != 256)
      return -1; 
    int cx = pos.getX() & 0xF;
    int cz = pos.getZ() & 0xF;
    int ix = cx | cz << 4;
    int y = precipitationHeightMap[ix];
    if (y >= 0)
      return y; 
    BlockPos posPrep = chunk.getPrecipitationHeight(pos);
    return posPrep.getY();
  }
  
  private static ReflectorField findFieldHasEntities() {
    try {
      Chunk chunk = new Chunk(null, 0, 0);
      List<Field> listBoolFields = new ArrayList();
      List<Object> listBoolValuesPre = new ArrayList();
      Field[] fields = Chunk.class.getDeclaredFields();
      for (int i = 0; i < fields.length; i++) {
        Field field = fields[i];
        if (field.getType() == boolean.class) {
          field.setAccessible(true);
          listBoolFields.add(field);
          listBoolValuesPre.add(field.get(chunk));
        } 
      } 
      chunk.setHasEntities(false);
      List<Object> listBoolValuesFalse = new ArrayList();
      for (Iterator<Field> it = listBoolFields.iterator(); it.hasNext(); ) {
        Field field = it.next();
        listBoolValuesFalse.add(field.get(chunk));
      } 
      chunk.setHasEntities(true);
      List<Object> listBoolValuesTrue = new ArrayList();
      for (Iterator<Field> iterator1 = listBoolFields.iterator(); iterator1.hasNext(); ) {
        Field field = iterator1.next();
        listBoolValuesTrue.add(field.get(chunk));
      } 
      List<Field> listMatchingFields = new ArrayList();
      for (int j = 0; j < listBoolFields.size(); j++) {
        Field field = listBoolFields.get(j);
        Boolean valFalse = (Boolean)listBoolValuesFalse.get(j);
        Boolean valTrue = (Boolean)listBoolValuesTrue.get(j);
        if (!valFalse.booleanValue() && valTrue.booleanValue() == true) {
          listMatchingFields.add(field);
          Boolean valPre = (Boolean)listBoolValuesPre.get(j);
          field.set(chunk, valPre);
        } 
      } 
      if (listMatchingFields.size() == 1) {
        Field field = listMatchingFields.get(0);
        return new ReflectorField(field);
      } 
    } catch (Exception e) {
      Config.warn(e.getClass().getName() + " " + e.getMessage());
    } 
    Config.warn("Error finding Chunk.hasEntities");
    return new ReflectorField(new ReflectorClass(Chunk.class), "hasEntities");
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifin\\util\ChunkUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */