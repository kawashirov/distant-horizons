package net.optifine.util;

public class ArrayUtils {
  public static boolean contains(Object[] arr, Object val) {
    if (arr == null)
      return false; 
    for (int i = 0; i < arr.length; i++) {
      Object obj = arr[i];
      if (obj == val)
        return true; 
    } 
    return false;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifin\\util\ArrayUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */