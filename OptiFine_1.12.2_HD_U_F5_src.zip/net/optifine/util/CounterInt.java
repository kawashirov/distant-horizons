package net.optifine.util;

public class CounterInt {
  private int startValue;
  
  private int value;
  
  public CounterInt(int startValue) {
    this.startValue = startValue;
    this.value = startValue;
  }
  
  public synchronized int nextValue() {
    int valueNow = this.value;
    this.value++;
    return valueNow;
  }
  
  public synchronized void reset() {
    this.value = this.startValue;
  }
  
  public int getValue() {
    return this.value;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifin\\util\CounterInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */