package net.optifine.util;

import Config;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityList;
import net.minecraft.util.ResourceLocation;

public class EntityUtils {
  private static final Map<Class, Integer> mapIdByClass = (Map)new HashMap<>();
  
  private static final Map<String, Integer> mapIdByLocation = new HashMap<>();
  
  private static final Map<String, Integer> mapIdByName = new HashMap<>();
  
  static {
    for (int i = 0; i < 1000; i++) {
      Class cls = EntityList.getClassFromID(i);
      if (cls != null) {
        ResourceLocation loc = EntityList.getKey(cls);
        if (loc != null) {
          String locStr = loc.toString();
          String name = EntityList.getTranslationName(loc);
          if (name != null) {
            if (mapIdByClass.containsKey(cls))
              Config.warn("Duplicate entity class: " + cls + ", id1: " + mapIdByClass.get(cls) + ", id2: " + i); 
            if (mapIdByLocation.containsKey(locStr))
              Config.warn("Duplicate entity location: " + locStr + ", id1: " + mapIdByLocation.get(locStr) + ", id2: " + i); 
            if (mapIdByName.containsKey(locStr))
              Config.warn("Duplicate entity name: " + name + ", id1: " + mapIdByName.get(name) + ", id2: " + i); 
            mapIdByClass.put(cls, Integer.valueOf(i));
            mapIdByLocation.put(locStr, Integer.valueOf(i));
            mapIdByName.put(name, Integer.valueOf(i));
          } 
        } 
      } 
    } 
  }
  
  public static int getEntityIdByClass(Entity entity) {
    if (entity == null)
      return -1; 
    return getEntityIdByClass(entity.getClass());
  }
  
  public static int getEntityIdByClass(Class cls) {
    Integer id = mapIdByClass.get(cls);
    if (id == null)
      return -1; 
    return id.intValue();
  }
  
  public static int getEntityIdByLocation(String locStr) {
    Integer id = mapIdByLocation.get(locStr);
    if (id == null)
      return -1; 
    return id.intValue();
  }
  
  public static int getEntityIdByName(String name) {
    Integer id = mapIdByName.get(name);
    if (id == null)
      return -1; 
    return id.intValue();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifin\\util\EntityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */