package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelCreeper;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderCreeper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.monster.EntityCreeper;

public class ModelAdapterCreeper extends ModelAdapter {
  public ModelAdapterCreeper() {
    super(EntityCreeper.class, "creeper", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelCreeper();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelCreeper))
      return null; 
    ModelCreeper modelCreeper = (ModelCreeper)model;
    if (modelPart.equals("head"))
      return modelCreeper.head; 
    if (modelPart.equals("armor"))
      return modelCreeper.creeperArmor; 
    if (modelPart.equals("body"))
      return modelCreeper.body; 
    if (modelPart.equals("leg1"))
      return modelCreeper.leg1; 
    if (modelPart.equals("leg2"))
      return modelCreeper.leg2; 
    if (modelPart.equals("leg3"))
      return modelCreeper.leg3; 
    if (modelPart.equals("leg4"))
      return modelCreeper.leg4; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "armor", "body", "leg1", "leg2", "leg3", "leg4" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderCreeper render = new RenderCreeper(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterCreeper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */