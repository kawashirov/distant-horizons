package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelWither;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWither;
import net.minecraft.entity.boss.EntityWither;
import net.optifine.reflect.Reflector;

public class ModelAdapterWither extends ModelAdapter {
  public ModelAdapterWither() {
    super(EntityWither.class, "wither", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelWither(0.0F);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelWither))
      return null; 
    ModelWither modelWither = (ModelWither)model;
    String PREFIX_BODY = "body";
    if (modelPart.startsWith(PREFIX_BODY)) {
      ModelRenderer[] bodyParts = (ModelRenderer[])Reflector.getFieldValue(modelWither, Reflector.ModelWither_bodyParts);
      if (bodyParts == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_BODY.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= bodyParts.length)
        return null; 
      return bodyParts[index];
    } 
    String PREFIX_HEAD = "head";
    if (modelPart.startsWith(PREFIX_HEAD)) {
      ModelRenderer[] heads = (ModelRenderer[])Reflector.getFieldValue(modelWither, Reflector.ModelWither_heads);
      if (heads == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_HEAD.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= heads.length)
        return null; 
      return heads[index];
    } 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "body1", "body2", "body3", "head1", "head2", "head3" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderWither render = new RenderWither(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterWither.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */