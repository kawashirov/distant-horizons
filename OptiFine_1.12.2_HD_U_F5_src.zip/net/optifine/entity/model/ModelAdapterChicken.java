package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelChicken;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderChicken;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.passive.EntityChicken;

public class ModelAdapterChicken extends ModelAdapter {
  public ModelAdapterChicken() {
    super(EntityChicken.class, "chicken", 0.3F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelChicken();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelChicken))
      return null; 
    ModelChicken modelChicken = (ModelChicken)model;
    if (modelPart.equals("head"))
      return modelChicken.head; 
    if (modelPart.equals("body"))
      return modelChicken.body; 
    if (modelPart.equals("right_leg"))
      return modelChicken.rightLeg; 
    if (modelPart.equals("left_leg"))
      return modelChicken.leftLeg; 
    if (modelPart.equals("right_wing"))
      return modelChicken.rightWing; 
    if (modelPart.equals("left_wing"))
      return modelChicken.leftWing; 
    if (modelPart.equals("bill"))
      return modelChicken.bill; 
    if (modelPart.equals("chin"))
      return modelChicken.chin; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "right_leg", "left_leg", "right_wing", "left_wing", "bill", "chin" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderChicken render = new RenderChicken(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterChicken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */