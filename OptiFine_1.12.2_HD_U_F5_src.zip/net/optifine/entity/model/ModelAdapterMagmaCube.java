package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelMagmaCube;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderMagmaCube;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.optifine.reflect.Reflector;

public class ModelAdapterMagmaCube extends ModelAdapter {
  public ModelAdapterMagmaCube() {
    super(EntityMagmaCube.class, "magma_cube", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelMagmaCube();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelMagmaCube))
      return null; 
    ModelMagmaCube modelMagmaCube = (ModelMagmaCube)model;
    if (modelPart.equals("core"))
      return (ModelRenderer)Reflector.getFieldValue(modelMagmaCube, Reflector.ModelMagmaCube_core); 
    String PREFIX_SEGMENTS = "segment";
    if (modelPart.startsWith(PREFIX_SEGMENTS)) {
      ModelRenderer[] segments = (ModelRenderer[])Reflector.getFieldValue(modelMagmaCube, Reflector.ModelMagmaCube_segments);
      if (segments == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_SEGMENTS.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= segments.length)
        return null; 
      return segments[index];
    } 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "core", "segment1", "segment2", "segment3", "segment4", "segment5", "segment6", "segment7", "segment8" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderMagmaCube render = new RenderMagmaCube(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterMagmaCube.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */