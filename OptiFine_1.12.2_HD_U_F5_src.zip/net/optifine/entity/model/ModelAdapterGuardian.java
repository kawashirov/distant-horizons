package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelGuardian;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderGuardian;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.monster.EntityGuardian;
import net.optifine.reflect.Reflector;

public class ModelAdapterGuardian extends ModelAdapter {
  public ModelAdapterGuardian() {
    super(EntityGuardian.class, "guardian", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelGuardian();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelGuardian))
      return null; 
    ModelGuardian modelGuardian = (ModelGuardian)model;
    if (modelPart.equals("body"))
      return (ModelRenderer)Reflector.getFieldValue(modelGuardian, Reflector.ModelGuardian_body); 
    if (modelPart.equals("eye"))
      return (ModelRenderer)Reflector.getFieldValue(modelGuardian, Reflector.ModelGuardian_eye); 
    String PREFIX_SPINE = "spine";
    if (modelPart.startsWith(PREFIX_SPINE)) {
      ModelRenderer[] spines = (ModelRenderer[])Reflector.getFieldValue(modelGuardian, Reflector.ModelGuardian_spines);
      if (spines == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_SPINE.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= spines.length)
        return null; 
      return spines[index];
    } 
    String PREFIX_TAIL = "tail";
    if (modelPart.startsWith(PREFIX_TAIL)) {
      ModelRenderer[] tails = (ModelRenderer[])Reflector.getFieldValue(modelGuardian, Reflector.ModelGuardian_tail);
      if (tails == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_TAIL.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= tails.length)
        return null; 
      return tails[index];
    } 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { 
        "body", "eye", "spine1", "spine2", "spine3", "spine4", "spine5", "spine6", "spine7", "spine8", 
        "spine9", "spine10", "spine11", "spine12", "tail1", "tail2", "tail3" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderGuardian render = new RenderGuardian(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterGuardian.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */