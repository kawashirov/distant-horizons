package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelMinecart;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderMinecart;
import net.minecraft.entity.item.EntityMinecart;
import net.optifine.reflect.Reflector;

public class ModelAdapterMinecart extends ModelAdapter {
  public ModelAdapterMinecart() {
    super(EntityMinecart.class, "minecart", 0.5F);
  }
  
  protected ModelAdapterMinecart(Class entityClass, String name, float shadow) {
    super(entityClass, name, shadow);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelMinecart();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelMinecart))
      return null; 
    ModelMinecart modelMinecart = (ModelMinecart)model;
    if (modelPart.equals("bottom"))
      return modelMinecart.sideModels[0]; 
    if (modelPart.equals("back"))
      return modelMinecart.sideModels[1]; 
    if (modelPart.equals("front"))
      return modelMinecart.sideModels[2]; 
    if (modelPart.equals("right"))
      return modelMinecart.sideModels[3]; 
    if (modelPart.equals("left"))
      return modelMinecart.sideModels[4]; 
    if (modelPart.equals("dirt"))
      return modelMinecart.sideModels[5]; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "bottom", "back", "front", "right", "left", "dirt" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderMinecart render = new RenderMinecart(renderManager);
    if (!Reflector.RenderMinecart_modelMinecart.exists()) {
      Config.warn("Field not found: RenderMinecart.modelMinecart");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderMinecart_modelMinecart, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterMinecart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */