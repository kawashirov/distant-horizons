package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapterBiped extends ModelAdapter {
  public ModelAdapterBiped(Class entityClass, String name, float shadowSize) {
    super(entityClass, name, shadowSize);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBiped))
      return null; 
    ModelBiped modelBiped = (ModelBiped)model;
    if (modelPart.equals("head"))
      return modelBiped.bipedHead; 
    if (modelPart.equals("headwear"))
      return modelBiped.bipedHeadwear; 
    if (modelPart.equals("body"))
      return modelBiped.bipedBody; 
    if (modelPart.equals("left_arm"))
      return modelBiped.bipedLeftArm; 
    if (modelPart.equals("right_arm"))
      return modelBiped.bipedRightArm; 
    if (modelPart.equals("left_leg"))
      return modelBiped.bipedLeftLeg; 
    if (modelPart.equals("right_leg"))
      return modelBiped.bipedRightLeg; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "headwear", "body", "left_arm", "right_arm", "left_leg", "right_leg" };
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBiped.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */