package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBook;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityEnchantmentTableRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityEnchantmentTable;
import net.optifine.reflect.Reflector;

public class ModelAdapterBook extends ModelAdapter {
  public ModelAdapterBook() {
    super(TileEntityEnchantmentTable.class, "book", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelBook();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBook))
      return null; 
    ModelBook modelBook = (ModelBook)model;
    if (modelPart.equals("cover_right"))
      return modelBook.coverRight; 
    if (modelPart.equals("cover_left"))
      return modelBook.coverLeft; 
    if (modelPart.equals("pages_right"))
      return modelBook.pagesRight; 
    if (modelPart.equals("pages_left"))
      return modelBook.pagesLeft; 
    if (modelPart.equals("flipping_page_right"))
      return modelBook.flippingPageRight; 
    if (modelPart.equals("flipping_page_left"))
      return modelBook.flippingPageLeft; 
    if (modelPart.equals("book_spine"))
      return modelBook.bookSpine; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "cover_right", "cover_left", "pages_right", "pages_left", "flipping_page_right", "flipping_page_left", "book_spine" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntityEnchantmentTableRenderer tileEntityEnchantmentTableRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntityEnchantmentTable.class);
    if (!(renderer instanceof TileEntityEnchantmentTableRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntityEnchantmentTableRenderer = new TileEntityEnchantmentTableRenderer();
      tileEntityEnchantmentTableRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntityEnchantmentTableRenderer_modelBook.exists()) {
      Config.warn("Field not found: TileEntityEnchantmentTableRenderer.modelBook");
      return null;
    } 
    Reflector.setFieldValue(tileEntityEnchantmentTableRenderer, Reflector.TileEntityEnchantmentTableRenderer_modelBook, modelBase);
    return (IEntityRenderer)tileEntityEnchantmentTableRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */