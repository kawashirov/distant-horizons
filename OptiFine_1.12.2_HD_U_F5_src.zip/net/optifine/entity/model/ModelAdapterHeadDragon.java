package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelDragonHead;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySkullRenderer;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntitySkull;
import net.optifine.reflect.Reflector;

public class ModelAdapterHeadDragon extends ModelAdapter {
  public ModelAdapterHeadDragon() {
    super(TileEntitySkull.class, "head_dragon", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelDragonHead(0.0F);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelDragonHead))
      return null; 
    ModelDragonHead modelDragonHead = (ModelDragonHead)model;
    if (modelPart.equals("head"))
      return (ModelRenderer)Reflector.getFieldValue(modelDragonHead, Reflector.ModelDragonHead_head); 
    if (modelPart.equals("jaw"))
      return (ModelRenderer)Reflector.getFieldValue(modelDragonHead, Reflector.ModelDragonHead_jaw); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "jaw" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntitySkullRenderer tileEntitySkullRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntitySkull.class);
    if (!(renderer instanceof TileEntitySkullRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntitySkullRenderer = new TileEntitySkullRenderer();
      tileEntitySkullRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntitySkullRenderer_dragonHead.exists()) {
      Config.warn("Field not found: TileEntitySkullRenderer.dragonHead");
      return null;
    } 
    Reflector.setFieldValue(tileEntitySkullRenderer, Reflector.TileEntitySkullRenderer_dragonHead, modelBase);
    return (IEntityRenderer)tileEntitySkullRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterHeadDragon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */