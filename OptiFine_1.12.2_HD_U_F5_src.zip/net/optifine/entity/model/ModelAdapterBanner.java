package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBanner;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityBannerRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityBanner;
import net.optifine.reflect.Reflector;

public class ModelAdapterBanner extends ModelAdapter {
  public ModelAdapterBanner() {
    super(TileEntityBanner.class, "banner", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelBanner();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBanner))
      return null; 
    ModelBanner modelBanner = (ModelBanner)model;
    if (modelPart.equals("slate"))
      return modelBanner.bannerSlate; 
    if (modelPart.equals("stand"))
      return modelBanner.bannerStand; 
    if (modelPart.equals("top"))
      return modelBanner.bannerTop; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "slate", "stand", "top" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntityBannerRenderer tileEntityBannerRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntityBanner.class);
    if (!(renderer instanceof TileEntityBannerRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntityBannerRenderer = new TileEntityBannerRenderer();
      tileEntityBannerRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntityBannerRenderer_bannerModel.exists()) {
      Config.warn("Field not found: TileEntityBannerRenderer.bannerModel");
      return null;
    } 
    Reflector.setFieldValue(tileEntityBannerRenderer, Reflector.TileEntityBannerRenderer_bannerModel, modelBase);
    return (IEntityRenderer)tileEntityBannerRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */