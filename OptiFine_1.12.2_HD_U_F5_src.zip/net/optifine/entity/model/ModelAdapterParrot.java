package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelParrot;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderParrot;
import net.minecraft.entity.passive.EntityParrot;
import net.optifine.reflect.Reflector;

public class ModelAdapterParrot extends ModelAdapter {
  public ModelAdapterParrot() {
    super(EntityParrot.class, "parrot", 0.3F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelParrot();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelParrot))
      return null; 
    ModelParrot modelParrot = (ModelParrot)model;
    if (modelPart.equals("body"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 0); 
    if (modelPart.equals("tail"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 1); 
    if (modelPart.equals("left_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 2); 
    if (modelPart.equals("right_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 3); 
    if (modelPart.equals("head"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 4); 
    if (modelPart.equals("left_leg"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 9); 
    if (modelPart.equals("right_leg"))
      return (ModelRenderer)Reflector.getFieldValue(modelParrot, Reflector.ModelParrot_ModelRenderers, 10); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "body", "tail", "left_wing", "right_wing", "head", "left_leg", "right_leg" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderParrot render = new RenderParrot(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterParrot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */