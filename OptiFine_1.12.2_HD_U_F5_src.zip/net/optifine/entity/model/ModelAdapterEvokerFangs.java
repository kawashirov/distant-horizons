package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEvokerFangs;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderEvokerFangs;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.projectile.EntityEvokerFangs;
import net.optifine.reflect.Reflector;

public class ModelAdapterEvokerFangs extends ModelAdapter {
  public ModelAdapterEvokerFangs() {
    super(EntityEvokerFangs.class, "evocation_fangs", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelEvokerFangs();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelEvokerFangs))
      return null; 
    ModelEvokerFangs modelEvokerFangs = (ModelEvokerFangs)model;
    if (modelPart.equals("base"))
      return (ModelRenderer)Reflector.getFieldValue(modelEvokerFangs, Reflector.ModelEvokerFangs_ModelRenderers, 0); 
    if (modelPart.equals("upper_jaw"))
      return (ModelRenderer)Reflector.getFieldValue(modelEvokerFangs, Reflector.ModelEvokerFangs_ModelRenderers, 1); 
    if (modelPart.equals("lower_jaw"))
      return (ModelRenderer)Reflector.getFieldValue(modelEvokerFangs, Reflector.ModelEvokerFangs_ModelRenderers, 2); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "base", "upper_jaw", "lower_jaw" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderEvokerFangs render = new RenderEvokerFangs(renderManager);
    if (!Reflector.RenderEvokerFangs_model.exists()) {
      Config.warn("Field not found: RenderEvokerFangs.model");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderEvokerFangs_model, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterEvokerFangs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */