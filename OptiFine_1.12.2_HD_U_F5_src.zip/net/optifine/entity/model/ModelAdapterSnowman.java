package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSnowMan;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSnowMan;
import net.minecraft.entity.monster.EntitySnowman;

public class ModelAdapterSnowman extends ModelAdapter {
  public ModelAdapterSnowman() {
    super(EntitySnowman.class, "snow_golem", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSnowMan();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelSnowMan))
      return null; 
    ModelSnowMan modelSnowman = (ModelSnowMan)model;
    if (modelPart.equals("body"))
      return modelSnowman.body; 
    if (modelPart.equals("body_bottom"))
      return modelSnowman.bottomBody; 
    if (modelPart.equals("head"))
      return modelSnowman.head; 
    if (modelPart.equals("left_hand"))
      return modelSnowman.leftHand; 
    if (modelPart.equals("right_hand"))
      return modelSnowman.rightHand; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "body", "body_bottom", "head", "right_hand", "left_hand" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderSnowMan render = new RenderSnowMan(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterSnowman.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */