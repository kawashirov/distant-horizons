package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelSkeleton;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderStray;
import net.minecraft.entity.monster.EntityStray;

public class ModelAdapterStray extends ModelAdapterBiped {
  public ModelAdapterStray() {
    super(EntityStray.class, "stray", 0.7F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSkeleton();
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderStray render = new RenderStray(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterStray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */