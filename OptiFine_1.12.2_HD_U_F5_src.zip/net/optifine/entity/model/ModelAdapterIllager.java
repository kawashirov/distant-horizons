package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelIllager;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapterIllager extends ModelAdapter {
  public ModelAdapterIllager(Class entityClass, String name, float shadowSize) {
    super(entityClass, name, shadowSize);
  }
  
  public ModelAdapterIllager(Class entityClass, String name, float shadowSize, String[] aliases) {
    super(entityClass, name, shadowSize, aliases);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelIllager))
      return null; 
    ModelIllager modelVillager = (ModelIllager)model;
    if (modelPart.equals("head"))
      return modelVillager.head; 
    if (modelPart.equals("body"))
      return modelVillager.body; 
    if (modelPart.equals("arms"))
      return modelVillager.arms; 
    if (modelPart.equals("left_leg"))
      return modelVillager.leg1; 
    if (modelPart.equals("right_leg"))
      return modelVillager.leg0; 
    if (modelPart.equals("nose"))
      return modelVillager.nose; 
    if (modelPart.equals("left_arm"))
      return modelVillager.leftArm; 
    if (modelPart.equals("right_arm"))
      return modelVillager.rightArm; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "arms", "right_leg", "left_leg", "nose", "right_arm", "left_arm" };
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterIllager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */