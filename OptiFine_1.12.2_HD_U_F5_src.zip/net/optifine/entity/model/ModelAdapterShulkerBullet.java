package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelShulkerBullet;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderShulkerBullet;
import net.minecraft.entity.projectile.EntityShulkerBullet;
import net.optifine.reflect.Reflector;

public class ModelAdapterShulkerBullet extends ModelAdapter {
  public ModelAdapterShulkerBullet() {
    super(EntityShulkerBullet.class, "shulker_bullet", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelShulkerBullet();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelShulkerBullet))
      return null; 
    ModelShulkerBullet modelShulkerBullet = (ModelShulkerBullet)model;
    if (modelPart.equals("bullet"))
      return modelShulkerBullet.renderer; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "bullet" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderShulkerBullet render = new RenderShulkerBullet(renderManager);
    if (!Reflector.RenderShulkerBullet_model.exists()) {
      Config.warn("Field not found: RenderShulkerBullet.model");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderShulkerBullet_model, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterShulkerBullet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */