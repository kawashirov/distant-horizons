package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelVillager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderVillager;
import net.minecraft.entity.passive.EntityVillager;

public class ModelAdapterVillager extends ModelAdapter {
  public ModelAdapterVillager() {
    super(EntityVillager.class, "villager", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelVillager(0.0F);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelVillager))
      return null; 
    ModelVillager modelVillager = (ModelVillager)model;
    if (modelPart.equals("head"))
      return modelVillager.villagerHead; 
    if (modelPart.equals("body"))
      return modelVillager.villagerBody; 
    if (modelPart.equals("arms"))
      return modelVillager.villagerArms; 
    if (modelPart.equals("left_leg"))
      return modelVillager.leftVillagerLeg; 
    if (modelPart.equals("right_leg"))
      return modelVillager.rightVillagerLeg; 
    if (modelPart.equals("nose"))
      return modelVillager.villagerNose; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "arms", "right_leg", "left_leg", "nose" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderVillager render = new RenderVillager(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterVillager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */