package net.optifine.entity.model;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapter {
  private Class entityClass;
  
  private String name;
  
  private float shadowSize;
  
  private String[] aliases;
  
  public ModelAdapter(Class entityClass, String name, float shadowSize) {
    this.entityClass = entityClass;
    this.name = name;
    this.shadowSize = shadowSize;
  }
  
  public ModelAdapter(Class entityClass, String name, float shadowSize, String[] aliases) {
    this.entityClass = entityClass;
    this.name = name;
    this.shadowSize = shadowSize;
    this.aliases = aliases;
  }
  
  public Class getEntityClass() {
    return this.entityClass;
  }
  
  public String getName() {
    return this.name;
  }
  
  public String[] getAliases() {
    return this.aliases;
  }
  
  public float getShadowSize() {
    return this.shadowSize;
  }
  
  public abstract ModelBase makeModel();
  
  public abstract ModelRenderer getModelRenderer(ModelBase paramModelBase, String paramString);
  
  public abstract String[] getModelRendererNames();
  
  public abstract IEntityRenderer makeEntityRender(ModelBase paramModelBase, float paramFloat);
  
  public ModelRenderer[] getModelRenderers(ModelBase model) {
    String[] names = getModelRendererNames();
    List<ModelRenderer> list = new ArrayList<>();
    for (int i = 0; i < names.length; i++) {
      String name = names[i];
      ModelRenderer mr = getModelRenderer(model, name);
      if (mr != null)
        list.add(mr); 
    } 
    ModelRenderer[] mrs = list.<ModelRenderer>toArray(new ModelRenderer[list.size()]);
    return mrs;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */