package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelChest;
import net.minecraft.client.model.ModelLargeChest;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityChestRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityChest;
import net.optifine.reflect.Reflector;

public class ModelAdapterChestLarge extends ModelAdapter {
  public ModelAdapterChestLarge() {
    super(TileEntityChest.class, "chest_large", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelLargeChest();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelChest))
      return null; 
    ModelChest modelChest = (ModelChest)model;
    if (modelPart.equals("lid"))
      return modelChest.chestLid; 
    if (modelPart.equals("base"))
      return modelChest.chestBelow; 
    if (modelPart.equals("knob"))
      return modelChest.chestKnob; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "lid", "base", "knob" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntityChestRenderer tileEntityChestRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntityChest.class);
    if (!(renderer instanceof TileEntityChestRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntityChestRenderer = new TileEntityChestRenderer();
      tileEntityChestRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntityChestRenderer_largeChest.exists()) {
      Config.warn("Field not found: TileEntityChestRenderer.largeChest");
      return null;
    } 
    Reflector.setFieldValue(tileEntityChestRenderer, Reflector.TileEntityChestRenderer_largeChest, modelBase);
    return (IEntityRenderer)tileEntityChestRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterChestLarge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */