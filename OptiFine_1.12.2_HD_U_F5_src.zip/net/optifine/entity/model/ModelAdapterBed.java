package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBed;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityBedRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityBed;
import net.optifine.reflect.Reflector;

public class ModelAdapterBed extends ModelAdapter {
  public ModelAdapterBed() {
    super(TileEntityBed.class, "bed", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelBed();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBed))
      return null; 
    ModelBed modelBed = (ModelBed)model;
    if (modelPart.equals("head"))
      return modelBed.headPiece; 
    if (modelPart.equals("foot"))
      return modelBed.footPiece; 
    if (modelPart.equals("leg1"))
      return modelBed.legs[0]; 
    if (modelPart.equals("leg2"))
      return modelBed.legs[1]; 
    if (modelPart.equals("leg3"))
      return modelBed.legs[2]; 
    if (modelPart.equals("leg4"))
      return modelBed.legs[3]; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "foot", "leg1", "leg2", "leg3", "leg4" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntityBedRenderer tileEntityBedRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntityBed.class);
    if (!(renderer instanceof TileEntityBedRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntityBedRenderer = new TileEntityBedRenderer();
      tileEntityBedRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntityBedRenderer_model.exists()) {
      Config.warn("Field not found: TileEntityBedRenderer.model");
      return null;
    } 
    Reflector.setFieldValue(tileEntityBedRenderer, Reflector.TileEntityBedRenderer_model, modelBase);
    return (IEntityRenderer)tileEntityBedRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */