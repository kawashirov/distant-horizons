package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSlime;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSlime;
import net.minecraft.entity.monster.EntitySlime;
import net.optifine.reflect.Reflector;

public class ModelAdapterSlime extends ModelAdapter {
  public ModelAdapterSlime() {
    super(EntitySlime.class, "slime", 0.25F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSlime(16);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelSlime))
      return null; 
    ModelSlime modelSlime = (ModelSlime)model;
    if (modelPart.equals("body"))
      return (ModelRenderer)Reflector.getFieldValue(modelSlime, Reflector.ModelSlime_ModelRenderers, 0); 
    if (modelPart.equals("left_eye"))
      return (ModelRenderer)Reflector.getFieldValue(modelSlime, Reflector.ModelSlime_ModelRenderers, 1); 
    if (modelPart.equals("right_eye"))
      return (ModelRenderer)Reflector.getFieldValue(modelSlime, Reflector.ModelSlime_ModelRenderers, 2); 
    if (modelPart.equals("mouth"))
      return (ModelRenderer)Reflector.getFieldValue(modelSlime, Reflector.ModelSlime_ModelRenderers, 3); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "body", "left_eye", "right_eye", "mouth" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderSlime render = new RenderSlime(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterSlime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */