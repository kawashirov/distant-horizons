package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelShulker;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderShulker;
import net.minecraft.entity.monster.EntityShulker;

public class ModelAdapterShulker extends ModelAdapter {
  public ModelAdapterShulker() {
    super(EntityShulker.class, "shulker", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelShulker();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelShulker))
      return null; 
    ModelShulker modelShulker = (ModelShulker)model;
    if (modelPart.equals("head"))
      return modelShulker.head; 
    if (modelPart.equals("base"))
      return modelShulker.base; 
    if (modelPart.equals("lid"))
      return modelShulker.lid; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "base", "lid", "head" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderShulker render = new RenderShulker(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterShulker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */