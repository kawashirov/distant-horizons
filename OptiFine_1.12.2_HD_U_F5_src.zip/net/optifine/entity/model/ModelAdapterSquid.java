package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSquid;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSquid;
import net.minecraft.entity.passive.EntitySquid;
import net.optifine.reflect.Reflector;

public class ModelAdapterSquid extends ModelAdapter {
  public ModelAdapterSquid() {
    super(EntitySquid.class, "squid", 0.7F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSquid();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelSquid))
      return null; 
    ModelSquid modelSquid = (ModelSquid)model;
    if (modelPart.equals("body"))
      return (ModelRenderer)Reflector.getFieldValue(modelSquid, Reflector.ModelSquid_body); 
    String PREFIX_TENTACLE = "tentacle";
    if (modelPart.startsWith(PREFIX_TENTACLE)) {
      ModelRenderer[] tentacles = (ModelRenderer[])Reflector.getFieldValue(modelSquid, Reflector.ModelSquid_tentacles);
      if (tentacles == null)
        return null; 
      String numStr = modelPart.substring(PREFIX_TENTACLE.length());
      int index = Config.parseInt(numStr, -1);
      index--;
      if (index < 0 || index >= tentacles.length)
        return null; 
      return tentacles[index];
    } 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "body", "tentacle1", "tentacle2", "tentacle3", "tentacle4", "tentacle5", "tentacle6", "tentacle7", "tentacle8" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderSquid render = new RenderSquid(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterSquid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */