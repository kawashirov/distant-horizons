package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelIronGolem;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderIronGolem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.monster.EntityIronGolem;

public class ModelAdapterIronGolem extends ModelAdapter {
  public ModelAdapterIronGolem() {
    super(EntityIronGolem.class, "iron_golem", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelIronGolem();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelIronGolem))
      return null; 
    ModelIronGolem modelIronGolem = (ModelIronGolem)model;
    if (modelPart.equals("head"))
      return modelIronGolem.ironGolemHead; 
    if (modelPart.equals("body"))
      return modelIronGolem.ironGolemBody; 
    if (modelPart.equals("left_arm"))
      return modelIronGolem.ironGolemLeftArm; 
    if (modelPart.equals("right_arm"))
      return modelIronGolem.ironGolemRightArm; 
    if (modelPart.equals("left_leg"))
      return modelIronGolem.ironGolemLeftLeg; 
    if (modelPart.equals("right_leg"))
      return modelIronGolem.ironGolemRightLeg; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "right_arm", "left_arm", "left_leg", "right_leg" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderIronGolem render = new RenderIronGolem(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterIronGolem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */