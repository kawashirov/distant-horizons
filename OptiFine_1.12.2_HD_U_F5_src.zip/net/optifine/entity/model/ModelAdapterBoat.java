package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBoat;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderBoat;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityBoat;
import net.optifine.reflect.Reflector;

public class ModelAdapterBoat extends ModelAdapter {
  public ModelAdapterBoat() {
    super(EntityBoat.class, "boat", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelBoat();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBoat))
      return null; 
    ModelBoat modelBoat = (ModelBoat)model;
    if (modelPart.equals("bottom"))
      return modelBoat.boatSides[0]; 
    if (modelPart.equals("back"))
      return modelBoat.boatSides[1]; 
    if (modelPart.equals("front"))
      return modelBoat.boatSides[2]; 
    if (modelPart.equals("right"))
      return modelBoat.boatSides[3]; 
    if (modelPart.equals("left"))
      return modelBoat.boatSides[4]; 
    if (modelPart.equals("paddle_left"))
      return modelBoat.paddles[0]; 
    if (modelPart.equals("paddle_right"))
      return modelBoat.paddles[1]; 
    if (modelPart.equals("bottom_no_water"))
      return modelBoat.noWater; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "bottom", "back", "front", "right", "left", "paddle_left", "paddle_right", "bottom_no_water" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderBoat render = new RenderBoat(renderManager);
    if (!Reflector.RenderBoat_modelBoat.exists()) {
      Config.warn("Field not found: RenderBoat.modelBoat");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderBoat_modelBoat, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBoat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */