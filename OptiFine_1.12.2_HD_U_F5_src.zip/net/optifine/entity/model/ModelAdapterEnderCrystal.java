package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEnderCrystal;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.optifine.reflect.Reflector;

public class ModelAdapterEnderCrystal extends ModelAdapter {
  public ModelAdapterEnderCrystal() {
    this("end_crystal");
  }
  
  protected ModelAdapterEnderCrystal(String name) {
    super(EntityEnderCrystal.class, name, 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelEnderCrystal(0.0F, true);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelEnderCrystal))
      return null; 
    ModelEnderCrystal modelEnderCrystal = (ModelEnderCrystal)model;
    if (modelPart.equals("cube"))
      return (ModelRenderer)Reflector.getFieldValue(modelEnderCrystal, Reflector.ModelEnderCrystal_ModelRenderers, 0); 
    if (modelPart.equals("glass"))
      return (ModelRenderer)Reflector.getFieldValue(modelEnderCrystal, Reflector.ModelEnderCrystal_ModelRenderers, 1); 
    if (modelPart.equals("base"))
      return (ModelRenderer)Reflector.getFieldValue(modelEnderCrystal, Reflector.ModelEnderCrystal_ModelRenderers, 2); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "cube", "glass", "base" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    Render renderObj = (Render)renderManager.getEntityRenderMap().get(EntityEnderCrystal.class);
    if (!(renderObj instanceof RenderEnderCrystal)) {
      Config.warn("Not an instance of RenderEnderCrystal: " + renderObj);
      return null;
    } 
    RenderEnderCrystal render = (RenderEnderCrystal)renderObj;
    if (!Reflector.RenderEnderCrystal_modelEnderCrystal.exists()) {
      Config.warn("Field not found: RenderEnderCrystal.modelEnderCrystal");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderEnderCrystal_modelEnderCrystal, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterEnderCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */