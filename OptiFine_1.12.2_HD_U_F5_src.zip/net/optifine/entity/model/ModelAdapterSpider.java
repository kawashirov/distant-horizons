package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSpider;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSpider;
import net.minecraft.entity.monster.EntitySpider;

public class ModelAdapterSpider extends ModelAdapter {
  public ModelAdapterSpider() {
    super(EntitySpider.class, "spider", 1.0F);
  }
  
  protected ModelAdapterSpider(Class entityClass, String name, float shadowSize) {
    super(entityClass, name, shadowSize);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSpider();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelSpider))
      return null; 
    ModelSpider modelSpider = (ModelSpider)model;
    if (modelPart.equals("head"))
      return modelSpider.spiderHead; 
    if (modelPart.equals("neck"))
      return modelSpider.spiderNeck; 
    if (modelPart.equals("body"))
      return modelSpider.spiderBody; 
    if (modelPart.equals("leg1"))
      return modelSpider.spiderLeg1; 
    if (modelPart.equals("leg2"))
      return modelSpider.spiderLeg2; 
    if (modelPart.equals("leg3"))
      return modelSpider.spiderLeg3; 
    if (modelPart.equals("leg4"))
      return modelSpider.spiderLeg4; 
    if (modelPart.equals("leg5"))
      return modelSpider.spiderLeg5; 
    if (modelPart.equals("leg6"))
      return modelSpider.spiderLeg6; 
    if (modelPart.equals("leg7"))
      return modelSpider.spiderLeg7; 
    if (modelPart.equals("leg8"))
      return modelSpider.spiderLeg8; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { 
        "head", "neck", "body", "leg1", "leg2", "leg3", "leg4", "leg5", "leg6", "leg7", 
        "leg8" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderSpider render = new RenderSpider(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterSpider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */