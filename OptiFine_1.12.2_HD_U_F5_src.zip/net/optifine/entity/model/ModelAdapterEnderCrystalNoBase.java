package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelEnderCrystal;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderEnderCrystal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.optifine.reflect.Reflector;

public class ModelAdapterEnderCrystalNoBase extends ModelAdapterEnderCrystal {
  public ModelAdapterEnderCrystalNoBase() {
    super("end_crystal_no_base");
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelEnderCrystal(0.0F, false);
  }
  
  public String[] getModelRendererNames() {
    String[] names = super.getModelRendererNames();
    names = (String[])Config.removeObjectFromArray((Object[])names, "base");
    return names;
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    Render renderObj = (Render)renderManager.getEntityRenderMap().get(EntityEnderCrystal.class);
    if (!(renderObj instanceof RenderEnderCrystal)) {
      Config.warn("Not an instance of RenderEnderCrystal: " + renderObj);
      return null;
    } 
    RenderEnderCrystal render = (RenderEnderCrystal)renderObj;
    if (!Reflector.RenderEnderCrystal_modelEnderCrystalNoBase.exists()) {
      Config.warn("Field not found: RenderEnderCrystal.modelEnderCrystalNoBase");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderEnderCrystal_modelEnderCrystalNoBase, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterEnderCrystalNoBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */