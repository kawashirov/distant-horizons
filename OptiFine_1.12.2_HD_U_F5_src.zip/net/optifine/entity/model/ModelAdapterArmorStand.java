package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelArmorStand;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderArmorStand;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityArmorStand;

public class ModelAdapterArmorStand extends ModelAdapterBiped {
  public ModelAdapterArmorStand() {
    super(EntityArmorStand.class, "armor_stand", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelArmorStand();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelArmorStand))
      return null; 
    ModelArmorStand modelArmorStand = (ModelArmorStand)model;
    if (modelPart.equals("right"))
      return modelArmorStand.standRightSide; 
    if (modelPart.equals("left"))
      return modelArmorStand.standLeftSide; 
    if (modelPart.equals("waist"))
      return modelArmorStand.standWaist; 
    if (modelPart.equals("base"))
      return modelArmorStand.standBase; 
    return super.getModelRenderer((ModelBase)modelArmorStand, modelPart);
  }
  
  public String[] getModelRendererNames() {
    String[] names = super.getModelRendererNames();
    names = (String[])Config.addObjectsToArray((Object[])names, (Object[])new String[] { "right", "left", "waist", "base" });
    return names;
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderArmorStand render = new RenderArmorStand(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterArmorStand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */