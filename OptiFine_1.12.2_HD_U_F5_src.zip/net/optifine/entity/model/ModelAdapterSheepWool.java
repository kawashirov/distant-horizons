package net.optifine.entity.model;

import Config;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelSheep1;
import net.minecraft.client.model.ModelSheep2;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSheep;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.layers.LayerSheepWool;
import net.minecraft.entity.passive.EntitySheep;

public class ModelAdapterSheepWool extends ModelAdapterQuadruped {
  public ModelAdapterSheepWool() {
    super(EntitySheep.class, "sheep_wool", 0.7F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelSheep1();
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderSheep renderSheep1;
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    Render render = (Render)renderManager.getEntityRenderMap().get(EntitySheep.class);
    if (!(render instanceof RenderSheep)) {
      Config.warn("Not a RenderSheep: " + render);
      return null;
    } 
    if (render.getEntityClass() == null) {
      RenderSheep rs = new RenderSheep(renderManager);
      rs.mainModel = (ModelBase)new ModelSheep2();
      rs.shadowSize = 0.7F;
      renderSheep1 = rs;
    } 
    RenderSheep renderSheep = renderSheep1;
    List<LayerRenderer<EntitySheep>> list = renderSheep.getLayerRenderers();
    for (Iterator<LayerRenderer<EntitySheep>> it = list.iterator(); it.hasNext(); ) {
      LayerRenderer layerRenderer = it.next();
      if (layerRenderer instanceof LayerSheepWool)
        it.remove(); 
    } 
    LayerSheepWool layer = new LayerSheepWool(renderSheep);
    layer.sheepModel = (ModelSheep1)modelBase;
    renderSheep.addLayer((LayerRenderer)layer);
    return (IEntityRenderer)renderSheep;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterSheepWool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */