package net.optifine.entity.model;

import Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelLeashKnot;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderLeashKnot;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLeashKnot;
import net.optifine.reflect.Reflector;

public class ModelAdapterLeadKnot extends ModelAdapter {
  public ModelAdapterLeadKnot() {
    super(EntityLeashKnot.class, "lead_knot", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelLeashKnot();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelLeashKnot))
      return null; 
    ModelLeashKnot modelLeashKnot = (ModelLeashKnot)model;
    if (modelPart.equals("knot"))
      return modelLeashKnot.knotRenderer; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "knot" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderLeashKnot render = new RenderLeashKnot(renderManager);
    if (!Reflector.RenderLeashKnot_leashKnotModel.exists()) {
      Config.warn("Field not found: RenderLeashKnot.leashKnotModel");
      return null;
    } 
    Reflector.setFieldValue(render, Reflector.RenderLeashKnot_leashKnotModel, modelBase);
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterLeadKnot.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */