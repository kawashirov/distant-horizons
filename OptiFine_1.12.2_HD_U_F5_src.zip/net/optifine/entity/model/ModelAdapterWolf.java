package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelWolf;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWolf;
import net.minecraft.entity.passive.EntityWolf;
import net.optifine.reflect.Reflector;

public class ModelAdapterWolf extends ModelAdapter {
  public ModelAdapterWolf() {
    super(EntityWolf.class, "wolf", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelWolf();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelWolf))
      return null; 
    ModelWolf modelWolf = (ModelWolf)model;
    if (modelPart.equals("head"))
      return modelWolf.wolfHeadMain; 
    if (modelPart.equals("body"))
      return modelWolf.wolfBody; 
    if (modelPart.equals("leg1"))
      return modelWolf.wolfLeg1; 
    if (modelPart.equals("leg2"))
      return modelWolf.wolfLeg2; 
    if (modelPart.equals("leg3"))
      return modelWolf.wolfLeg3; 
    if (modelPart.equals("leg4"))
      return modelWolf.wolfLeg4; 
    if (modelPart.equals("tail"))
      return (ModelRenderer)Reflector.getFieldValue(modelWolf, Reflector.ModelWolf_tail); 
    if (modelPart.equals("mane"))
      return (ModelRenderer)Reflector.getFieldValue(modelWolf, Reflector.ModelWolf_mane); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "leg1", "leg2", "leg3", "leg4", "tail", "mane" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderWolf render = new RenderWolf(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterWolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */