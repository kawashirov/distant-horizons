package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelWitch;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderWitch;
import net.minecraft.entity.monster.EntityWitch;
import net.optifine.reflect.Reflector;

public class ModelAdapterWitch extends ModelAdapter {
  public ModelAdapterWitch() {
    super(EntityWitch.class, "witch", 0.5F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelWitch(0.0F);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelWitch))
      return null; 
    ModelWitch modelWitch = (ModelWitch)model;
    if (modelPart.equals("mole"))
      return (ModelRenderer)Reflector.getFieldValue(modelWitch, Reflector.ModelWitch_mole); 
    if (modelPart.equals("hat"))
      return (ModelRenderer)Reflector.getFieldValue(modelWitch, Reflector.ModelWitch_hat); 
    if (modelPart.equals("head"))
      return modelWitch.villagerHead; 
    if (modelPart.equals("body"))
      return modelWitch.villagerBody; 
    if (modelPart.equals("arms"))
      return modelWitch.villagerArms; 
    if (modelPart.equals("left_leg"))
      return modelWitch.leftVillagerLeg; 
    if (modelPart.equals("right_leg"))
      return modelWitch.rightVillagerLeg; 
    if (modelPart.equals("nose"))
      return modelWitch.villagerNose; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "mole", "head", "body", "arms", "right_leg", "left_leg", "nose" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderWitch render = new RenderWitch(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterWitch.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */