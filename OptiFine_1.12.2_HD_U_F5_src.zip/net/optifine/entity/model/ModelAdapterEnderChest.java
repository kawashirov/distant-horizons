package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelChest;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityEnderChestRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.optifine.reflect.Reflector;

public class ModelAdapterEnderChest extends ModelAdapter {
  public ModelAdapterEnderChest() {
    super(TileEntityEnderChest.class, "ender_chest", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelChest();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelChest))
      return null; 
    ModelChest modelChest = (ModelChest)model;
    if (modelPart.equals("lid"))
      return modelChest.chestLid; 
    if (modelPart.equals("base"))
      return modelChest.chestBelow; 
    if (modelPart.equals("knob"))
      return modelChest.chestKnob; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "lid", "base", "knob" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntityEnderChestRenderer tileEntityEnderChestRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntityEnderChest.class);
    if (!(renderer instanceof TileEntityEnderChestRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntityEnderChestRenderer = new TileEntityEnderChestRenderer();
      tileEntityEnderChestRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntityEnderChestRenderer_modelChest.exists()) {
      Config.warn("Field not found: TileEntityEnderChestRenderer.modelChest");
      return null;
    } 
    Reflector.setFieldValue(tileEntityEnderChestRenderer, Reflector.TileEntityEnderChestRenderer_modelChest, modelBase);
    return (IEntityRenderer)tileEntityEnderChestRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterEnderChest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */