package net.optifine.entity.model;

import Config;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelHumanoidHead;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySkullRenderer;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.tileentity.TileEntitySkull;
import net.optifine.reflect.Reflector;

public class ModelAdapterHeadHumanoid extends ModelAdapter {
  public ModelAdapterHeadHumanoid() {
    super(TileEntitySkull.class, "head_humanoid", 0.0F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelHumanoidHead();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelHumanoidHead))
      return null; 
    ModelHumanoidHead modelHumanoidHead = (ModelHumanoidHead)model;
    if (modelPart.equals("head"))
      return modelHumanoidHead.skeletonHead; 
    if (modelPart.equals("head2")) {
      if (!Reflector.ModelHumanoidHead_head.exists())
        return null; 
      return (ModelRenderer)Reflector.getFieldValue(modelHumanoidHead, Reflector.ModelHumanoidHead_head);
    } 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    TileEntitySkullRenderer tileEntitySkullRenderer;
    TileEntityRendererDispatcher dispatcher = TileEntityRendererDispatcher.instance;
    TileEntitySpecialRenderer renderer = dispatcher.getRenderer(TileEntitySkull.class);
    if (!(renderer instanceof TileEntitySkullRenderer))
      return null; 
    if (renderer.getEntityClass() == null) {
      tileEntitySkullRenderer = new TileEntitySkullRenderer();
      tileEntitySkullRenderer.setRendererDispatcher(dispatcher);
    } 
    if (!Reflector.TileEntitySkullRenderer_humanoidHead.exists()) {
      Config.warn("Field not found: TileEntitySkullRenderer.humanoidHead");
      return null;
    } 
    Reflector.setFieldValue(tileEntitySkullRenderer, Reflector.TileEntitySkullRenderer_humanoidHead, modelBase);
    return (IEntityRenderer)tileEntitySkullRenderer;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterHeadHumanoid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */