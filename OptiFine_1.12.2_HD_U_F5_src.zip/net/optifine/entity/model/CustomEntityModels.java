package net.optifine.entity.model;

import Config;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.util.ResourceLocation;
import net.optifine.entity.model.anim.IModelResolver;
import net.optifine.entity.model.anim.ModelResolver;
import net.optifine.entity.model.anim.ModelUpdater;

public class CustomEntityModels {
  private static boolean active = false;
  
  private static Map<Class, Render> originalEntityRenderMap = null;
  
  private static Map<Class, TileEntitySpecialRenderer> originalTileEntityRenderMap = null;
  
  public static void update() {
    Map<Class<?>, Render> entityRenderMap = getEntityRenderMap();
    Map<Class<?>, TileEntitySpecialRenderer> tileEntityRenderMap = getTileEntityRenderMap();
    if (entityRenderMap == null) {
      Config.warn("Entity render map not found, custom entity models are DISABLED.");
      return;
    } 
    if (tileEntityRenderMap == null) {
      Config.warn("Tile entity render map not found, custom entity models are DISABLED.");
      return;
    } 
    active = false;
    entityRenderMap.clear();
    tileEntityRenderMap.clear();
    entityRenderMap.putAll((Map)originalEntityRenderMap);
    tileEntityRenderMap.putAll((Map)originalTileEntityRenderMap);
    if (!Config.isCustomEntityModels())
      return; 
    ResourceLocation[] locs = getModelLocations();
    for (int i = 0; i < locs.length; i++) {
      ResourceLocation loc = locs[i];
      Config.dbg("CustomEntityModel: " + loc.getResourcePath());
      IEntityRenderer rc = parseEntityRender(loc);
      if (rc != null) {
        Class<?> entityClass = rc.getEntityClass();
        if (entityClass != null) {
          if (rc instanceof Render) {
            entityRenderMap.put(entityClass, (Render)rc);
          } else if (rc instanceof TileEntitySpecialRenderer) {
            tileEntityRenderMap.put(entityClass, (TileEntitySpecialRenderer)rc);
          } else {
            Config.warn("Unknown renderer type: " + rc.getClass().getName());
          } 
          active = true;
        } 
      } 
    } 
  }
  
  private static Map<Class, Render> getEntityRenderMap() {
    RenderManager rm = Minecraft.getMinecraft().getRenderManager();
    Map<Class<?>, Render> entityRenderMap = rm.getEntityRenderMap();
    if (entityRenderMap == null)
      return null; 
    if (originalEntityRenderMap == null)
      originalEntityRenderMap = (Map)new HashMap<>(entityRenderMap); 
    return entityRenderMap;
  }
  
  private static Map<Class, TileEntitySpecialRenderer> getTileEntityRenderMap() {
    Map<Class<?>, TileEntitySpecialRenderer> tileEntityRenderMap = TileEntityRendererDispatcher.instance.renderers;
    if (originalTileEntityRenderMap == null)
      originalTileEntityRenderMap = (Map)new HashMap<>(tileEntityRenderMap); 
    return tileEntityRenderMap;
  }
  
  private static ResourceLocation[] getModelLocations() {
    String prefix = "optifine/cem/";
    String suffix = ".jem";
    List<ResourceLocation> resourceLocations = new ArrayList<>();
    String[] names = CustomModelRegistry.getModelNames();
    for (int i = 0; i < names.length; i++) {
      String name = names[i];
      String path = prefix + name + suffix;
      ResourceLocation loc = new ResourceLocation(path);
      if (Config.hasResource(loc))
        resourceLocations.add(loc); 
    } 
    ResourceLocation[] locs = resourceLocations.<ResourceLocation>toArray(new ResourceLocation[resourceLocations.size()]);
    return locs;
  }
  
  private static IEntityRenderer parseEntityRender(ResourceLocation location) {
    try {
      JsonObject jo = CustomEntityModelParser.loadJson(location);
      IEntityRenderer render = parseEntityRender(jo, location.getResourcePath());
      return render;
    } catch (IOException e) {
      Config.error("" + e.getClass().getName() + ": " + e.getMessage());
      return null;
    } catch (JsonParseException e) {
      Config.error("" + e.getClass().getName() + ": " + e.getMessage());
      return null;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    } 
  }
  
  private static IEntityRenderer parseEntityRender(JsonObject obj, String path) {
    CustomEntityRenderer cer = CustomEntityModelParser.parseEntityRender(obj, path);
    String name = cer.getName();
    ModelAdapter modelAdapter = CustomModelRegistry.getModelAdapter(name);
    checkNull(modelAdapter, "Entity not found: " + name);
    Class entityClass = modelAdapter.getEntityClass();
    checkNull(entityClass, "Entity class not found: " + name);
    IEntityRenderer render = makeEntityRender(modelAdapter, cer);
    if (render == null)
      return null; 
    render.setEntityClass(entityClass);
    return render;
  }
  
  private static IEntityRenderer makeEntityRender(ModelAdapter modelAdapter, CustomEntityRenderer cer) {
    ResourceLocation textureLocation = cer.getTextureLocation();
    CustomModelRenderer[] modelRenderers = cer.getCustomModelRenderers();
    float shadowSize = cer.getShadowSize();
    if (shadowSize < 0.0F)
      shadowSize = modelAdapter.getShadowSize(); 
    ModelBase model = modelAdapter.makeModel();
    if (model == null)
      return null; 
    ModelResolver mr = new ModelResolver(modelAdapter, model, modelRenderers);
    if (!modifyModel(modelAdapter, model, modelRenderers, mr))
      return null; 
    IEntityRenderer r = modelAdapter.makeEntityRender(model, shadowSize);
    if (r == null)
      throw new JsonParseException("Entity renderer is null, model: " + modelAdapter.getName() + ", adapter: " + modelAdapter.getClass().getName()); 
    if (textureLocation != null)
      r.setLocationTextureCustom(textureLocation); 
    return r;
  }
  
  private static boolean modifyModel(ModelAdapter modelAdapter, ModelBase model, CustomModelRenderer[] modelRenderers, ModelResolver mr) {
    for (int i = 0; i < modelRenderers.length; i++) {
      CustomModelRenderer cmr = modelRenderers[i];
      if (!modifyModel(modelAdapter, model, cmr, mr))
        return false; 
    } 
    return true;
  }
  
  private static boolean modifyModel(ModelAdapter modelAdapter, ModelBase model, CustomModelRenderer customModelRenderer, ModelResolver modelResolver) {
    String modelPart = customModelRenderer.getModelPart();
    ModelRenderer parent = modelAdapter.getModelRenderer(model, modelPart);
    if (parent == null) {
      Config.warn("Model part not found: " + modelPart + ", model: " + model);
      return false;
    } 
    if (!customModelRenderer.isAttach()) {
      if (parent.cubeList != null)
        parent.cubeList.clear(); 
      if (parent.spriteList != null)
        parent.spriteList.clear(); 
      if (parent.childModels != null) {
        ModelRenderer[] mrs = modelAdapter.getModelRenderers(model);
        Set<ModelRenderer> setMrs = Collections.newSetFromMap(new IdentityHashMap<>());
        setMrs.addAll(Arrays.asList(mrs));
        List<ModelRenderer> childModels = parent.childModels;
        for (Iterator<ModelRenderer> it = childModels.iterator(); it.hasNext(); ) {
          ModelRenderer mr = it.next();
          if (setMrs.contains(mr))
            continue; 
          it.remove();
        } 
      } 
    } 
    parent.addChild(customModelRenderer.getModelRenderer());
    ModelUpdater mu = customModelRenderer.getModelUpdater();
    if (mu != null) {
      modelResolver.setThisModelRenderer(customModelRenderer.getModelRenderer());
      modelResolver.setPartModelRenderer(parent);
      if (!mu.initialize((IModelResolver)modelResolver))
        return false; 
      customModelRenderer.getModelRenderer().setModelUpdater(mu);
    } 
    return true;
  }
  
  private static void checkNull(Object obj, String msg) {
    if (obj == null)
      throw new JsonParseException(msg); 
  }
  
  public static boolean isActive() {
    return active;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\CustomEntityModels.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */