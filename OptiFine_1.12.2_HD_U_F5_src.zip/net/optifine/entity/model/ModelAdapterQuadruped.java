package net.optifine.entity.model;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelQuadruped;
import net.minecraft.client.model.ModelRenderer;

public abstract class ModelAdapterQuadruped extends ModelAdapter {
  public ModelAdapterQuadruped(Class entityClass, String name, float shadowSize) {
    super(entityClass, name, shadowSize);
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelQuadruped))
      return null; 
    ModelQuadruped modelQuadruped = (ModelQuadruped)model;
    if (modelPart.equals("head"))
      return modelQuadruped.head; 
    if (modelPart.equals("body"))
      return modelQuadruped.body; 
    if (modelPart.equals("leg1"))
      return modelQuadruped.leg1; 
    if (modelPart.equals("leg2"))
      return modelQuadruped.leg2; 
    if (modelPart.equals("leg3"))
      return modelQuadruped.leg3; 
    if (modelPart.equals("leg4"))
      return modelQuadruped.leg4; 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "leg1", "leg2", "leg3", "leg4" };
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterQuadruped.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */