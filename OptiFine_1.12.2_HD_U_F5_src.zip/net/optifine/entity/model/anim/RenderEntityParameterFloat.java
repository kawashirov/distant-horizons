package net.optifine.entity.model.anim;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.optifine.expr.IExpressionFloat;

public enum RenderEntityParameterFloat implements IExpressionFloat {
  LIMB_SWING("limb_swing"),
  LIMB_SWING_SPEED("limb_speed"),
  AGE("age"),
  HEAD_YAW("head_yaw"),
  HEAD_PITCH("head_pitch"),
  SCALE("scale"),
  HEALTH("health"),
  HURT_TIME("hurt_time"),
  IDLE_TIME("idle_time"),
  MAX_HEALTH("max_health"),
  MOVE_FORWARD("move_forward"),
  MOVE_STRAFING("move_strafing"),
  PARTIAL_TICKS("partial_ticks"),
  POS_X("pos_x"),
  POS_Y("pos_Y"),
  POS_Z("pos_Z"),
  REVENGE_TIME("revenge_time"),
  SWING_PROGRESS("swing_progress");
  
  private String name;
  
  private RenderManager renderManager;
  
  private static final RenderEntityParameterFloat[] VALUES;
  
  static {
    VALUES = values();
  }
  
  RenderEntityParameterFloat(String name) {
    this.name = name;
    this.renderManager = Minecraft.getMinecraft().getRenderManager();
  }
  
  public String getName() {
    return this.name;
  }
  
  public float eval() {
    Render render = this.renderManager.renderRender;
    if (render == null)
      return 0.0F; 
    if (render instanceof RenderLivingBase) {
      RenderLivingBase rlb = (RenderLivingBase)render;
      switch (this) {
        case LIMB_SWING:
          return rlb.renderLimbSwing;
        case LIMB_SWING_SPEED:
          return rlb.renderLimbSwingAmount;
        case AGE:
          return rlb.renderAgeInTicks;
        case HEAD_YAW:
          return rlb.renderHeadYaw;
        case HEAD_PITCH:
          return rlb.renderHeadPitch;
        case SCALE:
          return rlb.renderScaleFactor;
      } 
      EntityLivingBase entity = rlb.renderEntity;
      if (entity == null)
        return 0.0F; 
      switch (this) {
        case HEALTH:
          return entity.getHealth();
        case HURT_TIME:
          return entity.hurtTime;
        case IDLE_TIME:
          return entity.getIdleTime();
        case MAX_HEALTH:
          return entity.getMaxHealth();
        case MOVE_FORWARD:
          return entity.moveVertical;
        case MOVE_STRAFING:
          return entity.moveStrafing;
        case POS_X:
          return (float)entity.posX;
        case POS_Y:
          return (float)entity.posY;
        case POS_Z:
          return (float)entity.posZ;
        case REVENGE_TIME:
          return entity.getRevengeTimer();
        case SWING_PROGRESS:
          return entity.getSwingProgress(rlb.renderPartialTicks);
      } 
    } 
    return 0.0F;
  }
  
  public static RenderEntityParameterFloat parse(String str) {
    if (str == null)
      return null; 
    for (int i = 0; i < VALUES.length; i++) {
      RenderEntityParameterFloat type = VALUES[i];
      if (type.getName().equals(str))
        return type; 
    } 
    return null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\anim\RenderEntityParameterFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */