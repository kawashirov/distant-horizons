package net.optifine.entity.model.anim;

import net.optifine.expr.IExpression;

public class RenderResolverEntity implements IRenderResolver {
  public IExpression getParameter(String name) {
    RenderEntityParameterBool parBool = RenderEntityParameterBool.parse(name);
    if (parBool != null)
      return (IExpression)parBool; 
    RenderEntityParameterFloat parFloat = RenderEntityParameterFloat.parse(name);
    if (parFloat != null)
      return (IExpression)parFloat; 
    return null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\anim\RenderResolverEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */