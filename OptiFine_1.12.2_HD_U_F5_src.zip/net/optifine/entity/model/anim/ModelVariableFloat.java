package net.optifine.entity.model.anim;

import net.minecraft.client.model.ModelRenderer;
import net.optifine.expr.IExpressionFloat;

public class ModelVariableFloat implements IExpressionFloat {
  private String name;
  
  private ModelRenderer modelRenderer;
  
  private ModelVariableType enumModelVariable;
  
  public ModelVariableFloat(String name, ModelRenderer modelRenderer, ModelVariableType enumModelVariable) {
    this.name = name;
    this.modelRenderer = modelRenderer;
    this.enumModelVariable = enumModelVariable;
  }
  
  public float eval() {
    return getValue();
  }
  
  public float getValue() {
    return this.enumModelVariable.getFloat(this.modelRenderer);
  }
  
  public void setValue(float value) {
    this.enumModelVariable.setFloat(this.modelRenderer, value);
  }
  
  public String toString() {
    return this.name;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\anim\ModelVariableFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */