package net.optifine.entity.model.anim;

public class ModelUpdater {
  private ModelVariableUpdater[] modelVariableUpdaters;
  
  public ModelUpdater(ModelVariableUpdater[] modelVariableUpdaters) {
    this.modelVariableUpdaters = modelVariableUpdaters;
  }
  
  public void update() {
    for (int i = 0; i < this.modelVariableUpdaters.length; i++) {
      ModelVariableUpdater mvu = this.modelVariableUpdaters[i];
      mvu.update();
    } 
  }
  
  public boolean initialize(IModelResolver mr) {
    for (int i = 0; i < this.modelVariableUpdaters.length; i++) {
      ModelVariableUpdater mvu = this.modelVariableUpdaters[i];
      if (!mvu.initialize(mr))
        return false; 
    } 
    return true;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\anim\ModelUpdater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */