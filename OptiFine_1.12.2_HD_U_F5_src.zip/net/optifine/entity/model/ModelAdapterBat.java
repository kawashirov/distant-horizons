package net.optifine.entity.model;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBat;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderBat;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.passive.EntityBat;
import net.optifine.reflect.Reflector;

public class ModelAdapterBat extends ModelAdapter {
  public ModelAdapterBat() {
    super(EntityBat.class, "bat", 0.25F);
  }
  
  public ModelBase makeModel() {
    return (ModelBase)new ModelBat();
  }
  
  public ModelRenderer getModelRenderer(ModelBase model, String modelPart) {
    if (!(model instanceof ModelBat))
      return null; 
    ModelBat modelBat = (ModelBat)model;
    if (modelPart.equals("head"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 0); 
    if (modelPart.equals("body"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 1); 
    if (modelPart.equals("right_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 2); 
    if (modelPart.equals("left_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 3); 
    if (modelPart.equals("outer_right_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 4); 
    if (modelPart.equals("outer_left_wing"))
      return (ModelRenderer)Reflector.getFieldValue(modelBat, Reflector.ModelBat_ModelRenderers, 5); 
    return null;
  }
  
  public String[] getModelRendererNames() {
    return new String[] { "head", "body", "right_wing", "left_wing", "outer_right_wing", "outer_left_wing" };
  }
  
  public IEntityRenderer makeEntityRender(ModelBase modelBase, float shadowSize) {
    RenderManager renderManager = Minecraft.getMinecraft().getRenderManager();
    RenderBat render = new RenderBat(renderManager);
    render.mainModel = modelBase;
    render.shadowSize = shadowSize;
    return (IEntityRenderer)render;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\entity\model\ModelAdapterBat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */