package net.optifine.texture;

public enum TextureType {
  TEXTURE_1D(3552),
  TEXTURE_2D(3553),
  TEXTURE_3D(32879),
  TEXTURE_RECTANGLE(34037);
  
  private int id;
  
  TextureType(int id) {
    this.id = id;
  }
  
  public int getId() {
    return this.id;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\texture\TextureType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */