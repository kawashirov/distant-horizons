package net.optifine.texture;

public enum PixelFormat {
  RED(6403),
  RG(33319),
  RGB(6407),
  BGR(32992),
  RGBA(6408),
  BGRA(32993),
  RED_INTEGER(36244),
  RG_INTEGER(33320),
  RGB_INTEGER(36248),
  BGR_INTEGER(36250),
  RGBA_INTEGER(36249),
  BGRA_INTEGER(36251);
  
  private int id;
  
  PixelFormat(int id) {
    this.id = id;
  }
  
  public int getId() {
    return this.id;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\texture\PixelFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */