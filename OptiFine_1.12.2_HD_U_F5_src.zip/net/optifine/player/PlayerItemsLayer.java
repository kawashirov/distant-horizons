package net.optifine.player;

import Config;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;

public class PlayerItemsLayer implements LayerRenderer {
  private RenderPlayer renderPlayer = null;
  
  public PlayerItemsLayer(RenderPlayer renderPlayer) {
    this.renderPlayer = renderPlayer;
  }
  
  public void doRenderLayer(EntityLivingBase entityLiving, float limbSwing, float limbSwingAmount, float partialTicks, float ticksExisted, float headYaw, float rotationPitch, float scale) {
    renderEquippedItems(entityLiving, scale, partialTicks);
  }
  
  protected void renderEquippedItems(EntityLivingBase entityLiving, float scale, float partialTicks) {
    if (!Config.isShowCapes())
      return; 
    if (!(entityLiving instanceof AbstractClientPlayer))
      return; 
    AbstractClientPlayer player = (AbstractClientPlayer)entityLiving;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.disableRescaleNormal();
    GlStateManager.enableCull();
    ModelPlayer modelPlayer = this.renderPlayer.getMainModel();
    PlayerConfigurations.renderPlayerItems((ModelBiped)modelPlayer, player, scale, partialTicks);
    GlStateManager.disableCull();
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
  
  public static void register(Map renderPlayerMap) {
    Set keys = renderPlayerMap.keySet();
    boolean registered = false;
    for (Iterator it = keys.iterator(); it.hasNext(); ) {
      Object key = it.next();
      Object renderer = renderPlayerMap.get(key);
      if (renderer instanceof RenderPlayer) {
        RenderPlayer renderPlayer = (RenderPlayer)renderer;
        renderPlayer.addLayer(new PlayerItemsLayer(renderPlayer));
        registered = true;
      } 
    } 
    if (!registered)
      Config.warn("PlayerItemsLayer not registered"); 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\player\PlayerItemsLayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */