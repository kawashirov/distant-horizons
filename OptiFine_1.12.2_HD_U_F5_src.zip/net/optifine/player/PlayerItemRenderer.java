package net.optifine.player;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;

public class PlayerItemRenderer {
  private int attachTo = 0;
  
  private ModelRenderer modelRenderer = null;
  
  public PlayerItemRenderer(int attachTo, ModelRenderer modelRenderer) {
    this.attachTo = attachTo;
    this.modelRenderer = modelRenderer;
  }
  
  public ModelRenderer getModelRenderer() {
    return this.modelRenderer;
  }
  
  public void render(ModelBiped modelBiped, float scale) {
    ModelRenderer attachModel = PlayerItemModel.getAttachModel(modelBiped, this.attachTo);
    if (attachModel != null)
      attachModel.postRender(scale); 
    this.modelRenderer.render(scale);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\player\PlayerItemRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */