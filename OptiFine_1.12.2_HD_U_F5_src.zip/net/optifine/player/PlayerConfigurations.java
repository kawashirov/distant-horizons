package net.optifine.player;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBiped;
import net.optifine.http.FileDownloadThread;
import net.optifine.http.HttpUtils;

public class PlayerConfigurations {
  private static Map mapConfigurations = null;
  
  private static boolean reloadPlayerItems = Boolean.getBoolean("player.models.reload");
  
  private static long timeReloadPlayerItemsMs = System.currentTimeMillis();
  
  public static void renderPlayerItems(ModelBiped modelBiped, AbstractClientPlayer player, float scale, float partialTicks) {
    PlayerConfiguration cfg = getPlayerConfiguration(player);
    if (cfg != null)
      cfg.renderPlayerItems(modelBiped, player, scale, partialTicks); 
  }
  
  public static synchronized PlayerConfiguration getPlayerConfiguration(AbstractClientPlayer player) {
    if (reloadPlayerItems)
      if (System.currentTimeMillis() > timeReloadPlayerItemsMs + 5000L) {
        EntityPlayerSP entityPlayerSP = (Minecraft.getMinecraft()).player;
        if (entityPlayerSP != null) {
          setPlayerConfiguration(entityPlayerSP.getNameClear(), null);
          timeReloadPlayerItemsMs = System.currentTimeMillis();
        } 
      }  
    String name = player.getNameClear();
    if (name == null)
      return null; 
    PlayerConfiguration pc = (PlayerConfiguration)getMapConfigurations().get(name);
    if (pc == null) {
      pc = new PlayerConfiguration();
      getMapConfigurations().put(name, pc);
      PlayerConfigurationReceiver pcl = new PlayerConfigurationReceiver(name);
      String url = HttpUtils.getPlayerItemsUrl() + "/users/" + name + ".cfg";
      FileDownloadThread fdt = new FileDownloadThread(url, pcl);
      fdt.start();
    } 
    return pc;
  }
  
  public static synchronized void setPlayerConfiguration(String player, PlayerConfiguration pc) {
    getMapConfigurations().put(player, pc);
  }
  
  private static Map getMapConfigurations() {
    if (mapConfigurations == null)
      mapConfigurations = new HashMap<>(); 
    return mapConfigurations;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\player\PlayerConfigurations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */