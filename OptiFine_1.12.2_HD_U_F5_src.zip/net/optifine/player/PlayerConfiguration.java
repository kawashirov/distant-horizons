package net.optifine.player;

import Config;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelBiped;

public class PlayerConfiguration {
  private PlayerItemModel[] playerItemModels = new PlayerItemModel[0];
  
  private boolean initialized = false;
  
  public void renderPlayerItems(ModelBiped modelBiped, AbstractClientPlayer player, float scale, float partialTicks) {
    if (!this.initialized)
      return; 
    for (int i = 0; i < this.playerItemModels.length; i++) {
      PlayerItemModel model = this.playerItemModels[i];
      model.render(modelBiped, player, scale, partialTicks);
    } 
  }
  
  public boolean isInitialized() {
    return this.initialized;
  }
  
  public void setInitialized(boolean initialized) {
    this.initialized = initialized;
  }
  
  public PlayerItemModel[] getPlayerItemModels() {
    return this.playerItemModels;
  }
  
  public void addPlayerItemModel(PlayerItemModel playerItemModel) {
    this.playerItemModels = (PlayerItemModel[])Config.addObjectToArray((Object[])this.playerItemModels, playerItemModel);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\player\PlayerConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */