package net.optifine.config;

import Config;

public class RangeListInt {
  private RangeInt[] ranges = new RangeInt[0];
  
  public RangeListInt() {}
  
  public RangeListInt(RangeInt ri) {
    addRange(ri);
  }
  
  public void addRange(RangeInt ri) {
    this.ranges = (RangeInt[])Config.addObjectToArray((Object[])this.ranges, ri);
  }
  
  public boolean isInRange(int val) {
    for (int i = 0; i < this.ranges.length; i++) {
      RangeInt ri = this.ranges[i];
      if (ri.isInRange(val))
        return true; 
    } 
    return false;
  }
  
  public int getCountRanges() {
    return this.ranges.length;
  }
  
  public RangeInt getRange(int i) {
    return this.ranges[i];
  }
  
  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("[");
    for (int i = 0; i < this.ranges.length; i++) {
      RangeInt ri = this.ranges[i];
      if (i > 0)
        sb.append(", "); 
      sb.append(ri.toString());
    } 
    sb.append("]");
    return sb.toString();
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\config\RangeListInt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */