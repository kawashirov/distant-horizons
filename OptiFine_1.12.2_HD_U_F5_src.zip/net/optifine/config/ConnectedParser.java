package net.optifine.config;

import Config;
import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockObserver;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityList;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.optifine.ConnectedProperties;

public class ConnectedParser {
  private String context = null;
  
  public static final VillagerProfession[] PROFESSIONS_INVALID = new VillagerProfession[0];
  
  public static final EnumDyeColor[] DYE_COLORS_INVALID = new EnumDyeColor[0];
  
  private static final INameGetter<Enum> NAME_GETTER_ENUM = new INameGetter<Enum>() {
      public String getName(Enum en) {
        return en.name();
      }
    };
  
  private static final INameGetter<EnumDyeColor> NAME_GETTER_DYE_COLOR = new INameGetter<EnumDyeColor>() {
      public String getName(EnumDyeColor col) {
        return col.getName();
      }
    };
  
  public ConnectedParser(String context) {
    this.context = context;
  }
  
  public String parseName(String path) {
    String str = path;
    int pos = str.lastIndexOf('/');
    if (pos >= 0)
      str = str.substring(pos + 1); 
    int pos2 = str.lastIndexOf('.');
    if (pos2 >= 0)
      str = str.substring(0, pos2); 
    return str;
  }
  
  public String parseBasePath(String path) {
    int pos = path.lastIndexOf('/');
    if (pos < 0)
      return ""; 
    return path.substring(0, pos);
  }
  
  public MatchBlock[] parseMatchBlocks(String propMatchBlocks) {
    if (propMatchBlocks == null)
      return null; 
    List list = new ArrayList();
    String[] blockStrs = Config.tokenize(propMatchBlocks, " ");
    for (int i = 0; i < blockStrs.length; i++) {
      String blockStr = blockStrs[i];
      MatchBlock[] arrayOfMatchBlock = parseMatchBlock(blockStr);
      if (arrayOfMatchBlock != null)
        list.addAll(Arrays.asList(arrayOfMatchBlock)); 
    } 
    MatchBlock[] mbs = (MatchBlock[])list.toArray((Object[])new MatchBlock[list.size()]);
    return mbs;
  }
  
  public IBlockState parseBlockState(String str, IBlockState def) {
    MatchBlock[] mbs = parseMatchBlock(str);
    if (mbs == null)
      return def; 
    if (mbs.length != 1)
      return def; 
    MatchBlock mb = mbs[0];
    int blockId = mb.getBlockId();
    Block block = Block.getBlockById(blockId);
    return block.getDefaultState();
  }
  
  public MatchBlock[] parseMatchBlock(String blockStr) {
    if (blockStr == null)
      return null; 
    blockStr = blockStr.trim();
    if (blockStr.length() <= 0)
      return null; 
    String[] parts = Config.tokenize(blockStr, ":");
    String domain = "minecraft";
    int blockIndex = 0;
    if (parts.length > 1 && isFullBlockName(parts)) {
      domain = parts[0];
      blockIndex = 1;
    } else {
      domain = "minecraft";
      blockIndex = 0;
    } 
    String blockPart = parts[blockIndex];
    String[] params = Arrays.<String>copyOfRange(parts, blockIndex + 1, parts.length);
    Block[] blocks = parseBlockPart(domain, blockPart);
    if (blocks == null)
      return null; 
    MatchBlock[] datas = new MatchBlock[blocks.length];
    for (int i = 0; i < blocks.length; i++) {
      Block block = blocks[i];
      int blockId = Block.getIdFromBlock(block);
      int[] metadatas = null;
      if (params.length > 0) {
        metadatas = parseBlockMetadatas(block, params);
        if (metadatas == null)
          return null; 
      } 
      MatchBlock bd = new MatchBlock(blockId, metadatas);
      datas[i] = bd;
    } 
    return datas;
  }
  
  public boolean isFullBlockName(String[] parts) {
    if (parts.length < 2)
      return false; 
    String part1 = parts[1];
    if (part1.length() < 1)
      return false; 
    if (startsWithDigit(part1))
      return false; 
    if (part1.contains("="))
      return false; 
    return true;
  }
  
  public boolean startsWithDigit(String str) {
    if (str == null)
      return false; 
    if (str.length() < 1)
      return false; 
    char ch = str.charAt(0);
    return Character.isDigit(ch);
  }
  
  public Block[] parseBlockPart(String domain, String blockPart) {
    if (startsWithDigit(blockPart)) {
      int[] ids = parseIntList(blockPart);
      if (ids == null)
        return null; 
      Block[] arrayOfBlock = new Block[ids.length];
      for (int i = 0; i < ids.length; i++) {
        int id = ids[i];
        Block block1 = Block.getBlockById(id);
        if (block1 == null) {
          warn("Block not found for id: " + id);
          return null;
        } 
        arrayOfBlock[i] = block1;
      } 
      return arrayOfBlock;
    } 
    String fullName = domain + ":" + blockPart;
    Block block = Block.getBlockFromName(fullName);
    if (block == null) {
      warn("Block not found for name: " + fullName);
      return null;
    } 
    Block[] blocks = { block };
    return blocks;
  }
  
  public int[] parseBlockMetadatas(Block block, String[] params) {
    if (params.length <= 0)
      return null; 
    String param0 = params[0];
    if (startsWithDigit(param0)) {
      int[] mds = parseIntList(param0);
      return mds;
    } 
    IBlockState stateDefault = block.getDefaultState();
    Collection properties = stateDefault.getPropertyKeys();
    Map<IProperty, List<Comparable>> mapPropValues = new HashMap<>();
    for (int i = 0; i < params.length; i++) {
      String param = params[i];
      if (param.length() > 0) {
        String[] parts = Config.tokenize(param, "=");
        if (parts.length != 2) {
          warn("Invalid block property: " + param);
          return null;
        } 
        String key = parts[0];
        String valStr = parts[1];
        IProperty prop = ConnectedProperties.getProperty(key, properties);
        if (prop == null) {
          warn("Property not found: " + key + ", block: " + block);
          return null;
        } 
        List<Comparable> list = mapPropValues.get(key);
        if (list == null) {
          list = new ArrayList<>();
          mapPropValues.put(prop, list);
        } 
        String[] vals = Config.tokenize(valStr, ",");
        for (int v = 0; v < vals.length; v++) {
          String val = vals[v];
          Comparable propVal = parsePropertyValue(prop, val);
          if (propVal == null) {
            warn("Property value not found: " + val + ", property: " + key + ", block: " + block);
            return null;
          } 
          list.add(propVal);
        } 
      } 
    } 
    if (mapPropValues.isEmpty())
      return null; 
    List<Integer> listMetadatas = new ArrayList<>();
    for (int j = 0; j < 16; j++) {
      int md = j;
      try {
        IBlockState bs = getStateFromMeta(block, md);
        if (matchState(bs, mapPropValues))
          listMetadatas.add(Integer.valueOf(md)); 
      } catch (IllegalArgumentException illegalArgumentException) {}
    } 
    if (listMetadatas.size() == 16)
      return null; 
    int[] metadatas = new int[listMetadatas.size()];
    for (int k = 0; k < metadatas.length; k++)
      metadatas[k] = ((Integer)listMetadatas.get(k)).intValue(); 
    return metadatas;
  }
  
  private IBlockState getStateFromMeta(Block block, int md) {
    try {
      IBlockState bs = block.getStateFromMeta(md);
      if (block == Blocks.DOUBLE_PLANT)
        if (md > 7) {
          IBlockState bsLow = block.getStateFromMeta(md & 0x7);
          bs = bs.withProperty((IProperty)BlockDoublePlant.VARIANT, bsLow.getValue((IProperty)BlockDoublePlant.VARIANT));
        }  
      if (block == Blocks.OBSERVER)
        if ((md & 0x8) != 0)
          bs = bs.withProperty((IProperty)BlockObserver.POWERED, Boolean.valueOf(true));  
      return bs;
    } catch (IllegalArgumentException e) {
      return block.getDefaultState();
    } 
  }
  
  public static Comparable parsePropertyValue(IProperty prop, String valStr) {
    Class valueClass = prop.getValueClass();
    Comparable valueObj = parseValue(valStr, valueClass);
    if (valueObj == null) {
      Collection propertyValues = prop.getAllowedValues();
      valueObj = getPropertyValue(valStr, propertyValues);
    } 
    return valueObj;
  }
  
  public static Comparable getPropertyValue(String value, Collection propertyValues) {
    for (Iterator<Comparable> it = propertyValues.iterator(); it.hasNext(); ) {
      Comparable obj = it.next();
      if (getValueName(obj).equals(value))
        return obj; 
    } 
    return null;
  }
  
  private static Object getValueName(Comparable obj) {
    if (obj instanceof IStringSerializable) {
      IStringSerializable iss = (IStringSerializable)obj;
      return iss.getName();
    } 
    return obj.toString();
  }
  
  public static Comparable parseValue(String str, Class<String> cls) {
    if (cls == String.class)
      return str; 
    if (cls == Boolean.class)
      return Boolean.valueOf(str); 
    if (cls == Float.class)
      return Float.valueOf(str); 
    if (cls == Double.class)
      return Double.valueOf(str); 
    if (cls == Integer.class)
      return Integer.valueOf(str); 
    if (cls == Long.class)
      return Long.valueOf(str); 
    return null;
  }
  
  public boolean matchState(IBlockState bs, Map<IProperty, List<Comparable>> mapPropValues) {
    Set<IProperty> keys = mapPropValues.keySet();
    for (Iterator<IProperty> it = keys.iterator(); it.hasNext(); ) {
      IProperty prop = it.next();
      List<Comparable> vals = mapPropValues.get(prop);
      Comparable bsVal = bs.getValue(prop);
      if (bsVal == null)
        return false; 
      if (!vals.contains(bsVal))
        return false; 
    } 
    return true;
  }
  
  public Biome[] parseBiomes(String str) {
    if (str == null)
      return null; 
    str = str.trim();
    boolean negative = false;
    if (str.startsWith("!")) {
      negative = true;
      str = str.substring(1);
    } 
    String[] biomeNames = Config.tokenize(str, " ");
    List<Biome> list = new ArrayList();
    for (int i = 0; i < biomeNames.length; i++) {
      String biomeName = biomeNames[i];
      Biome biome = findBiome(biomeName);
      if (biome == null) {
        warn("Biome not found: " + biomeName);
      } else {
        list.add(biome);
      } 
    } 
    if (negative) {
      List<Biome> listAllBiomes = Lists.newArrayList(Biome.REGISTRY.iterator());
      listAllBiomes.removeAll(list);
      list = listAllBiomes;
    } 
    Biome[] biomeArr = list.<Biome>toArray(new Biome[list.size()]);
    return biomeArr;
  }
  
  public Biome findBiome(String biomeName) {
    biomeName = biomeName.toLowerCase();
    if (biomeName.equals("nether"))
      return Biomes.HELL; 
    Set<ResourceLocation> biomeIds = Biome.REGISTRY.getKeys();
    for (Iterator<ResourceLocation> it = biomeIds.iterator(); it.hasNext(); ) {
      ResourceLocation loc = it.next();
      Biome biome = (Biome)Biome.REGISTRY.getObject(loc);
      if (biome == null)
        continue; 
      String name = biome.getBiomeName().replace(" ", "").toLowerCase();
      if (name.equals(biomeName))
        return biome; 
    } 
    return null;
  }
  
  public int parseInt(String str, int defVal) {
    if (str == null)
      return defVal; 
    str = str.trim();
    int num = Config.parseInt(str, -1);
    if (num < 0) {
      warn("Invalid number: " + str);
      return defVal;
    } 
    return num;
  }
  
  public int[] parseIntList(String str) {
    if (str == null)
      return null; 
    List<Integer> list = new ArrayList<>();
    String[] intStrs = Config.tokenize(str, " ,");
    for (int i = 0; i < intStrs.length; i++) {
      String intStr = intStrs[i];
      if (intStr.contains("-")) {
        String[] subStrs = Config.tokenize(intStr, "-");
        if (subStrs.length != 2) {
          warn("Invalid interval: " + intStr + ", when parsing: " + str);
        } else {
          int min = Config.parseInt(subStrs[0], -1);
          int max = Config.parseInt(subStrs[1], -1);
          if (min < 0 || max < 0 || min > max) {
            warn("Invalid interval: " + intStr + ", when parsing: " + str);
          } else {
            for (int n = min; n <= max; n++)
              list.add(Integer.valueOf(n)); 
          } 
        } 
      } else {
        int val = Config.parseInt(intStr, -1);
        if (val < 0) {
          warn("Invalid number: " + intStr + ", when parsing: " + str);
        } else {
          list.add(Integer.valueOf(val));
        } 
      } 
    } 
    int[] ints = new int[list.size()];
    for (int j = 0; j < ints.length; j++)
      ints[j] = ((Integer)list.get(j)).intValue(); 
    return ints;
  }
  
  public boolean[] parseFaces(String str, boolean[] defVal) {
    if (str == null)
      return defVal; 
    EnumSet<EnumFacing> setFaces = EnumSet.allOf(EnumFacing.class);
    String[] faceStrs = Config.tokenize(str, " ,");
    for (int i = 0; i < faceStrs.length; i++) {
      String faceStr = faceStrs[i];
      if (faceStr.equals("sides")) {
        setFaces.add(EnumFacing.NORTH);
        setFaces.add(EnumFacing.SOUTH);
        setFaces.add(EnumFacing.WEST);
        setFaces.add(EnumFacing.EAST);
      } else if (faceStr.equals("all")) {
        setFaces.addAll(Arrays.asList(EnumFacing.VALUES));
      } else {
        EnumFacing face = parseFace(faceStr);
        if (face != null)
          setFaces.add(face); 
      } 
    } 
    boolean[] faces = new boolean[EnumFacing.VALUES.length];
    for (int j = 0; j < faces.length; j++)
      faces[j] = setFaces.contains(EnumFacing.VALUES[j]); 
    return faces;
  }
  
  public EnumFacing parseFace(String str) {
    str = str.toLowerCase();
    if (str.equals("bottom") || str.equals("down"))
      return EnumFacing.DOWN; 
    if (str.equals("top") || str.equals("up"))
      return EnumFacing.UP; 
    if (str.equals("north"))
      return EnumFacing.NORTH; 
    if (str.equals("south"))
      return EnumFacing.SOUTH; 
    if (str.equals("east"))
      return EnumFacing.EAST; 
    if (str.equals("west"))
      return EnumFacing.WEST; 
    Config.warn("Unknown face: " + str);
    return null;
  }
  
  public void dbg(String str) {
    Config.dbg("" + this.context + ": " + str);
  }
  
  public void warn(String str) {
    Config.warn("" + this.context + ": " + str);
  }
  
  public RangeListInt parseRangeListInt(String str) {
    if (str == null)
      return null; 
    RangeListInt list = new RangeListInt();
    String[] parts = Config.tokenize(str, " ,");
    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      RangeInt ri = parseRangeInt(part);
      if (ri == null)
        return null; 
      list.addRange(ri);
    } 
    return list;
  }
  
  private RangeInt parseRangeInt(String str) {
    if (str == null)
      return null; 
    if (str.indexOf('-') >= 0) {
      String[] parts = Config.tokenize(str, "-");
      if (parts.length != 2) {
        warn("Invalid range: " + str);
        return null;
      } 
      int min = Config.parseInt(parts[0], -1);
      int max = Config.parseInt(parts[1], -1);
      if (min < 0 || max < 0) {
        warn("Invalid range: " + str);
        return null;
      } 
      return new RangeInt(min, max);
    } 
    int val = Config.parseInt(str, -1);
    if (val < 0) {
      warn("Invalid integer: " + str);
      return null;
    } 
    return new RangeInt(val, val);
  }
  
  public boolean parseBoolean(String str, boolean defVal) {
    if (str == null)
      return defVal; 
    String strLower = str.toLowerCase().trim();
    if (strLower.equals("true"))
      return true; 
    if (strLower.equals("false"))
      return false; 
    warn("Invalid boolean: " + str);
    return defVal;
  }
  
  public Boolean parseBooleanObject(String str) {
    if (str == null)
      return null; 
    String strLower = str.toLowerCase().trim();
    if (strLower.equals("true"))
      return Boolean.TRUE; 
    if (strLower.equals("false"))
      return Boolean.FALSE; 
    warn("Invalid boolean: " + str);
    return null;
  }
  
  public static int parseColor(String str, int defVal) {
    if (str == null)
      return defVal; 
    str = str.trim();
    try {
      int val = Integer.parseInt(str, 16) & 0xFFFFFF;
      return val;
    } catch (NumberFormatException e) {
      return defVal;
    } 
  }
  
  public static int parseColor4(String str, int defVal) {
    if (str == null)
      return defVal; 
    str = str.trim();
    try {
      int val = (int)(Long.parseLong(str, 16) & 0xFFFFFFFFFFFFFFFFL);
      return val;
    } catch (NumberFormatException e) {
      return defVal;
    } 
  }
  
  public BlockRenderLayer parseBlockRenderLayer(String str, BlockRenderLayer def) {
    if (str == null)
      return def; 
    str = str.toLowerCase().trim();
    BlockRenderLayer[] layers = BlockRenderLayer.values();
    for (int i = 0; i < layers.length; i++) {
      BlockRenderLayer layer = layers[i];
      if (str.equals(layer.name().toLowerCase()))
        return layer; 
    } 
    return def;
  }
  
  public <T> T parseObject(String str, T[] objs, INameGetter<T> nameGetter, String property) {
    if (str == null)
      return null; 
    String strLower = str.toLowerCase().trim();
    for (int i = 0; i < objs.length; i++) {
      T obj = objs[i];
      String name = nameGetter.getName(obj);
      if (name != null)
        if (name.toLowerCase().equals(strLower))
          return obj;  
    } 
    warn("Invalid " + property + ": " + str);
    return null;
  }
  
  public <T> T[] parseObjects(String str, T[] objs, INameGetter nameGetter, String property, T[] errValue) {
    if (str == null)
      return null; 
    str = str.toLowerCase().trim();
    String[] parts = Config.tokenize(str, " ");
    T[] arr = (T[])Array.newInstance(objs.getClass().getComponentType(), parts.length);
    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      T obj = parseObject(part, objs, nameGetter, property);
      if (obj == null)
        return errValue; 
      arr[i] = obj;
    } 
    return arr;
  }
  
  public Enum parseEnum(String str, Enum[] enums, String property) {
    return parseObject(str, enums, NAME_GETTER_ENUM, property);
  }
  
  public Enum[] parseEnums(String str, Enum[] enums, String property, Enum[] errValue) {
    return parseObjects(str, enums, NAME_GETTER_ENUM, property, errValue);
  }
  
  public EnumDyeColor[] parseDyeColors(String str, String property, EnumDyeColor[] errValue) {
    return parseObjects(str, EnumDyeColor.values(), NAME_GETTER_DYE_COLOR, property, errValue);
  }
  
  public Weather[] parseWeather(String str, String property, Weather[] errValue) {
    return parseObjects(str, Weather.values(), NAME_GETTER_ENUM, property, errValue);
  }
  
  public NbtTagValue parseNbtTagValue(String path, String value) {
    if (path == null || value == null)
      return null; 
    return new NbtTagValue(path, value);
  }
  
  public VillagerProfession[] parseProfessions(String profStr) {
    if (profStr == null)
      return null; 
    List<VillagerProfession> list = new ArrayList<>();
    String[] tokens = Config.tokenize(profStr, " ");
    for (int i = 0; i < tokens.length; i++) {
      String str = tokens[i];
      VillagerProfession prof = parseProfession(str);
      if (prof == null) {
        warn("Invalid profession: " + str);
        return PROFESSIONS_INVALID;
      } 
      list.add(prof);
    } 
    if (list.isEmpty())
      return null; 
    VillagerProfession[] arr = list.<VillagerProfession>toArray(new VillagerProfession[list.size()]);
    return arr;
  }
  
  private VillagerProfession parseProfession(String str) {
    str = str.toLowerCase();
    String[] parts = Config.tokenize(str, ":");
    if (parts.length > 2)
      return null; 
    String profStr = parts[0];
    String carStr = null;
    if (parts.length > 1)
      carStr = parts[1]; 
    int prof = parseProfessionId(profStr);
    if (prof < 0)
      return null; 
    int[] cars = null;
    if (carStr != null) {
      cars = parseCareerIds(prof, carStr);
      if (cars == null)
        return null; 
    } 
    return new VillagerProfession(prof, cars);
  }
  
  private static int parseProfessionId(String str) {
    int id = Config.parseInt(str, -1);
    if (id >= 0)
      return id; 
    if (str.equals("farmer"))
      return 0; 
    if (str.equals("librarian"))
      return 1; 
    if (str.equals("priest"))
      return 2; 
    if (str.equals("blacksmith"))
      return 3; 
    if (str.equals("butcher"))
      return 4; 
    if (str.equals("nitwit"))
      return 5; 
    return -1;
  }
  
  private static int[] parseCareerIds(int prof, String str) {
    IntArraySet intArraySet = new IntArraySet();
    String[] parts = Config.tokenize(str, ",");
    for (int i = 0; i < parts.length; i++) {
      String part = parts[i];
      int id = parseCareerId(prof, part);
      if (id < 0)
        return null; 
      intArraySet.add(id);
    } 
    int[] arr = intArraySet.toIntArray();
    return arr;
  }
  
  private static int parseCareerId(int prof, String str) {
    int id = Config.parseInt(str, -1);
    if (id >= 0)
      return id; 
    if (prof == 0) {
      if (str.equals("farmer"))
        return 1; 
      if (str.equals("fisherman"))
        return 2; 
      if (str.equals("shepherd"))
        return 3; 
      if (str.equals("fletcher"))
        return 4; 
    } 
    if (prof == 1) {
      if (str.equals("librarian"))
        return 1; 
      if (str.equals("cartographer"))
        return 2; 
    } 
    if (prof == 2)
      if (str.equals("cleric"))
        return 1;  
    if (prof == 3) {
      if (str.equals("armor"))
        return 1; 
      if (str.equals("weapon"))
        return 2; 
      if (str.equals("tool"))
        return 3; 
    } 
    if (prof == 4) {
      if (str.equals("butcher"))
        return 1; 
      if (str.equals("leather"))
        return 2; 
    } 
    if (prof == 5)
      if (str.equals("nitwit"))
        return 1;  
    return -1;
  }
  
  public int[] parseItems(String str) {
    str = str.trim();
    Set<Integer> setIds = new TreeSet<>();
    String[] tokens = Config.tokenize(str, " ");
    for (int i = 0; i < tokens.length; i++) {
      String token = tokens[i];
      ResourceLocation loc = new ResourceLocation(token);
      Item item = (Item)Item.REGISTRY.getObject(loc);
      if (item == null) {
        warn("Item not found: " + token);
      } else {
        int id = Item.getIdFromItem(item);
        if (id < 0) {
          warn("Item has no ID: " + item + ", name: " + token);
        } else {
          setIds.add(new Integer(id));
        } 
      } 
    } 
    Integer[] integers = setIds.<Integer>toArray(new Integer[setIds.size()]);
    int[] ints = Config.toPrimitive(integers);
    return ints;
  }
  
  public int[] parseEntities(String str) {
    str = str.trim();
    Set<Integer> setIds = new TreeSet<>();
    String[] tokens = Config.tokenize(str, " ");
    for (int i = 0; i < tokens.length; i++) {
      String token = tokens[i];
      ResourceLocation loc = new ResourceLocation(token);
      Class type = (Class)EntityList.REGISTRY.getObject(loc);
      if (type == null) {
        warn("Entity not found: " + token);
      } else {
        int id = EntityList.REGISTRY.getIDForObject(type);
        if (id < 0) {
          warn("Entity has no ID: " + type + ", name: " + token);
        } else {
          setIds.add(new Integer(id));
        } 
      } 
    } 
    Integer[] integers = setIds.<Integer>toArray(new Integer[setIds.size()]);
    int[] ints = Config.toPrimitive(integers);
    return ints;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\config\ConnectedParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */