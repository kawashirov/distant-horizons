package net.optifine.config;

import net.minecraft.entity.EntityList;
import net.minecraft.util.ResourceLocation;

public class EntityClassLocator implements IObjectLocator {
  public Object getObject(ResourceLocation loc) {
    Class cls = EntityList.getClassFromName(loc.toString());
    return cls;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\config\EntityClassLocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */