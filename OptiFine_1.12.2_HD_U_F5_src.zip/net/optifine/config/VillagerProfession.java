package net.optifine.config;

import Config;

public class VillagerProfession {
  private int profession;
  
  private int[] careers;
  
  public VillagerProfession(int profession) {
    this(profession, (int[])null);
  }
  
  public VillagerProfession(int profession, int career) {
    this(profession, new int[] { career });
  }
  
  public VillagerProfession(int profession, int[] careers) {
    this.profession = profession;
    this.careers = careers;
  }
  
  public boolean matches(int prof, int car) {
    if (this.profession != prof)
      return false; 
    if (this.careers != null)
      if (!Config.equalsOne(car, this.careers))
        return false;  
    return true;
  }
  
  private boolean hasCareer(int car) {
    if (this.careers == null)
      return false; 
    return Config.equalsOne(car, this.careers);
  }
  
  public boolean addCareer(int car) {
    if (this.careers == null) {
      this.careers = new int[] { car };
      return true;
    } 
    if (hasCareer(car))
      return false; 
    this.careers = Config.addIntToArray(this.careers, car);
    return true;
  }
  
  public int getProfession() {
    return this.profession;
  }
  
  public int[] getCareers() {
    return this.careers;
  }
  
  public String toString() {
    if (this.careers == null)
      return "" + this.profession; 
    return "" + this.profession + ":" + Config.arrayToString(this.careers);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\config\VillagerProfession.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */