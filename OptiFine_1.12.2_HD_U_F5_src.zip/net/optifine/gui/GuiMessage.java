package net.optifine.gui;

import Config;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;

public class GuiMessage extends GuiScreen {
  private GuiScreen parentScreen;
  
  private String messageLine1;
  
  private String messageLine2;
  
  private final List listLines2 = Lists.newArrayList();
  
  protected String confirmButtonText;
  
  private int ticksUntilEnable;
  
  public GuiMessage(GuiScreen parentScreen, String line1, String line2) {
    this.parentScreen = parentScreen;
    this.messageLine1 = line1;
    this.messageLine2 = line2;
    this.confirmButtonText = I18n.format("gui.done", new Object[0]);
  }
  
  public void initGui() {
    this.buttonList.add(new GuiOptionButton(0, this.width / 2 - 74, this.height / 6 + 96, this.confirmButtonText));
    this.listLines2.clear();
    this.listLines2.addAll(this.fontRenderer.listFormattedStringToWidth(this.messageLine2, this.width - 50));
  }
  
  protected void actionPerformed(GuiButton button) throws IOException {
    Config.getMinecraft().displayGuiScreen(this.parentScreen);
  }
  
  public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    drawDefaultBackground();
    drawCenteredString(this.fontRenderer, this.messageLine1, this.width / 2, 70, 16777215);
    int var4 = 90;
    for (Iterator<String> var5 = this.listLines2.iterator(); var5.hasNext(); var4 += this.fontRenderer.FONT_HEIGHT) {
      String var6 = var5.next();
      drawCenteredString(this.fontRenderer, var6, this.width / 2, var4, 16777215);
    } 
    super.drawScreen(mouseX, mouseY, partialTicks);
  }
  
  public void setButtonDelay(int ticksUntilEnable) {
    this.ticksUntilEnable = ticksUntilEnable;
    for (Iterator<GuiButton> var2 = this.buttonList.iterator(); var2.hasNext(); var3.enabled = false)
      GuiButton var3 = var2.next(); 
  }
  
  public void updateScreen() {
    super.updateScreen();
    if (--this.ticksUntilEnable == 0)
      for (Iterator<GuiButton> var1 = this.buttonList.iterator(); var1.hasNext(); var2.enabled = true)
        GuiButton var2 = var1.next();  
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */