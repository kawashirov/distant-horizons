package net.optifine.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.optifine.Lang;

public class GuiAnimationSettingsOF extends GuiScreen {
  private GuiScreen prevScreen;
  
  protected String title;
  
  private GameSettings settings;
  
  private static GameSettings.Options[] enumOptions = new GameSettings.Options[] { 
      GameSettings.Options.ANIMATED_WATER, GameSettings.Options.ANIMATED_LAVA, GameSettings.Options.ANIMATED_FIRE, GameSettings.Options.ANIMATED_PORTAL, GameSettings.Options.ANIMATED_REDSTONE, GameSettings.Options.ANIMATED_EXPLOSION, GameSettings.Options.ANIMATED_FLAME, GameSettings.Options.ANIMATED_SMOKE, GameSettings.Options.VOID_PARTICLES, GameSettings.Options.WATER_PARTICLES, 
      GameSettings.Options.RAIN_SPLASH, GameSettings.Options.PORTAL_PARTICLES, GameSettings.Options.POTION_PARTICLES, GameSettings.Options.DRIPPING_WATER_LAVA, GameSettings.Options.ANIMATED_TERRAIN, GameSettings.Options.ANIMATED_TEXTURES, GameSettings.Options.FIREWORK_PARTICLES, GameSettings.Options.PARTICLES };
  
  public GuiAnimationSettingsOF(GuiScreen guiscreen, GameSettings gamesettings) {
    this.prevScreen = guiscreen;
    this.settings = gamesettings;
  }
  
  public void initGui() {
    this.title = I18n.format("of.options.animationsTitle", new Object[0]);
    this.buttonList.clear();
    for (int i = 0; i < enumOptions.length; i++) {
      GameSettings.Options opt = enumOptions[i];
      int x = this.width / 2 - 155 + i % 2 * 160;
      int y = this.height / 6 + 21 * i / 2 - 12;
      if (!opt.isFloat()) {
        this.buttonList.add(new GuiOptionButtonOF(opt.getOrdinal(), x, y, opt, this.settings.getKeyBinding(opt)));
      } else {
        this.buttonList.add(new GuiOptionSliderOF(opt.getOrdinal(), x, y, opt));
      } 
    } 
    this.buttonList.add(new GuiButton(210, this.width / 2 - 155, this.height / 6 + 168 + 11, 70, 20, Lang.get("of.options.animation.allOn")));
    this.buttonList.add(new GuiButton(211, this.width / 2 - 155 + 80, this.height / 6 + 168 + 11, 70, 20, Lang.get("of.options.animation.allOff")));
    this.buttonList.add(new GuiOptionButton(200, this.width / 2 + 5, this.height / 6 + 168 + 11, I18n.format("gui.done", new Object[0])));
  }
  
  protected void actionPerformed(GuiButton guibutton) {
    if (!guibutton.enabled)
      return; 
    if (guibutton.id < 200 && guibutton instanceof GuiOptionButton) {
      this.settings.setOptionValue(((GuiOptionButton)guibutton).getOption(), 1);
      guibutton.displayString = this.settings.getKeyBinding(GameSettings.Options.byOrdinal(guibutton.id));
    } 
    if (guibutton.id == 200) {
      this.mc.gameSettings.saveOptions();
      this.mc.displayGuiScreen(this.prevScreen);
    } 
    if (guibutton.id == 210)
      this.mc.gameSettings.setAllAnimations(true); 
    if (guibutton.id == 211)
      this.mc.gameSettings.setAllAnimations(false); 
    ScaledResolution sr = new ScaledResolution(this.mc);
    setWorldAndResolution(this.mc, sr.getScaledWidth(), sr.getScaledHeight());
  }
  
  public void drawScreen(int x, int y, float f) {
    drawDefaultBackground();
    drawCenteredString(this.fontRenderer, this.title, this.width / 2, 15, 16777215);
    super.drawScreen(x, y, f);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiAnimationSettingsOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */