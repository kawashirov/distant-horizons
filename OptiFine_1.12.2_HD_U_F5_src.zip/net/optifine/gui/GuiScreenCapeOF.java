package net.optifine.gui;

import Config;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import java.math.BigInteger;
import java.net.URI;
import java.util.Random;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.optifine.Lang;

public class GuiScreenCapeOF extends GuiScreenOF {
  private final GuiScreen parentScreen;
  
  private String title;
  
  private String message;
  
  private long messageHideTimeMs;
  
  private String linkUrl;
  
  private GuiButtonOF buttonCopyLink;
  
  public GuiScreenCapeOF(GuiScreen parentScreenIn) {
    this.parentScreen = parentScreenIn;
  }
  
  public void initGui() {
    int i = 0;
    this.title = I18n.format("of.options.capeOF.title", new Object[0]);
    i += 2;
    this.buttonList.add(new GuiButtonOF(210, this.width / 2 - 155, this.height / 6 + 24 * (i >> 1), 150, 20, I18n.format("of.options.capeOF.openEditor", new Object[0])));
    this.buttonList.add(new GuiButtonOF(220, this.width / 2 - 155 + 160, this.height / 6 + 24 * (i >> 1), 150, 20, I18n.format("of.options.capeOF.reloadCape", new Object[0])));
    i += 6;
    this.buttonCopyLink = new GuiButtonOF(230, this.width / 2 - 100, this.height / 6 + 24 * (i >> 1), 200, 20, I18n.format("of.options.capeOF.copyEditorLink", new Object[0]));
    this.buttonCopyLink.visible = (this.linkUrl != null);
    addButton(this.buttonCopyLink);
    i += 4;
    this.buttonList.add(new GuiButtonOF(200, this.width / 2 - 100, this.height / 6 + 24 * (i >> 1), I18n.format("gui.done", new Object[0])));
  }
  
  protected void actionPerformed(GuiButton button) {
    if (button.enabled) {
      if (button.id == 200)
        this.mc.displayGuiScreen(this.parentScreen); 
      if (button.id == 210)
        try {
          String userName = this.mc.getSession().getProfile().getName();
          String userId = this.mc.getSession().getProfile().getId().toString().replace("-", "");
          String accessToken = this.mc.getSession().getToken();
          Random r1 = new Random();
          Random r2 = new Random(System.identityHashCode(new Object()));
          BigInteger random1Bi = new BigInteger(128, r1);
          BigInteger random2Bi = new BigInteger(128, r2);
          BigInteger serverBi = random1Bi.xor(random2Bi);
          String serverId = serverBi.toString(16);
          this.mc.getSessionService().joinServer(this.mc.getSession().getProfile(), accessToken, serverId);
          String urlStr = "https://optifine.net/capeChange?u=" + userId + "&n=" + userName + "&s=" + serverId;
          boolean opened = Config.openWebLink(new URI(urlStr));
          if (opened) {
            showMessage(Lang.get("of.message.capeOF.openEditor"), 10000L);
          } else {
            showMessage(Lang.get("of.message.capeOF.openEditorError"), 10000L);
            setLinkUrl(urlStr);
          } 
        } catch (InvalidCredentialsException e) {
          Config.showGuiMessage(I18n.format("of.message.capeOF.error1", new Object[0]), I18n.format("of.message.capeOF.error2", new Object[] { e.getMessage() }));
          Config.warn("Mojang authentication failed");
          Config.warn(e.getClass().getName() + ": " + e.getMessage());
        } catch (Exception e) {
          Config.warn("Error opening OptiFine cape link");
          Config.warn(e.getClass().getName() + ": " + e.getMessage());
        }  
      if (button.id == 220) {
        showMessage(Lang.get("of.message.capeOF.reloadCape"), 15000L);
        if (this.mc.player != null) {
          long delayMs = 15000L;
          long reloadTimeMs = System.currentTimeMillis() + delayMs;
          this.mc.player.setReloadCapeTimeMs(reloadTimeMs);
        } 
      } 
      if (button.id == 230)
        if (this.linkUrl != null)
          setClipboardString(this.linkUrl);  
    } 
  }
  
  private void showMessage(String msg, long timeMs) {
    this.message = msg;
    this.messageHideTimeMs = System.currentTimeMillis() + timeMs;
    setLinkUrl((String)null);
  }
  
  public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    drawDefaultBackground();
    drawCenteredString(this.fontRenderer, this.title, this.width / 2, 20, 16777215);
    if (this.message != null) {
      drawCenteredString(this.fontRenderer, this.message, this.width / 2, this.height / 6 + 60, 16777215);
      if (System.currentTimeMillis() > this.messageHideTimeMs) {
        this.message = null;
        setLinkUrl((String)null);
      } 
    } 
    super.drawScreen(mouseX, mouseY, partialTicks);
  }
  
  public void setLinkUrl(String linkUrl) {
    this.linkUrl = linkUrl;
    this.buttonCopyLink.visible = (linkUrl != null);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiScreenCapeOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */