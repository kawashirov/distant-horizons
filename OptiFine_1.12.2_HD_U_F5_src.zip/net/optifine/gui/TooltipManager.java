package net.optifine.gui;

import java.awt.Rectangle;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class TooltipManager {
  private GuiScreen guiScreen;
  
  private TooltipProvider tooltipProvider;
  
  private int lastMouseX = 0;
  
  private int lastMouseY = 0;
  
  private long mouseStillTime = 0L;
  
  public TooltipManager(GuiScreen guiScreen, TooltipProvider tooltipProvider) {
    this.guiScreen = guiScreen;
    this.tooltipProvider = tooltipProvider;
  }
  
  public void drawTooltips(int x, int y, List<GuiButton> buttonList) {
    if (Math.abs(x - this.lastMouseX) > 5 || Math.abs(y - this.lastMouseY) > 5) {
      this.lastMouseX = x;
      this.lastMouseY = y;
      this.mouseStillTime = System.currentTimeMillis();
      return;
    } 
    int activateDelay = 700;
    if (System.currentTimeMillis() < this.mouseStillTime + activateDelay)
      return; 
    GuiButton btn = GuiScreenOF.getSelectedButton(x, y, buttonList);
    if (btn == null)
      return; 
    Rectangle rect = this.tooltipProvider.getTooltipBounds(this.guiScreen, x, y);
    String[] lines = this.tooltipProvider.getTooltipLines(btn, rect.width);
    if (lines == null)
      return; 
    if (lines.length > 8) {
      lines = Arrays.<String>copyOf(lines, 8);
      lines[lines.length - 1] = lines[lines.length - 1] + " ...";
    } 
    if (this.tooltipProvider.isRenderBorder()) {
      int colBorder = -528449408;
      drawRectBorder(rect.x, rect.y, rect.x + rect.width, rect.y + rect.height, colBorder);
    } 
    Gui.drawRect(rect.x, rect.y, rect.x + rect.width, rect.y + rect.height, -536870912);
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i];
      int col = 14540253;
      if (line.endsWith("!"))
        col = 16719904; 
      FontRenderer fontRenderer = (Minecraft.getMinecraft()).fontRenderer;
      fontRenderer.drawStringWithShadow(line, (rect.x + 5), (rect.y + 5 + i * 11), col);
    } 
  }
  
  private void drawRectBorder(int x1, int y1, int x2, int y2, int col) {
    Gui.drawRect(x1, y1 - 1, x2, y1, col);
    Gui.drawRect(x1, y2, x2, y2 + 1, col);
    Gui.drawRect(x1 - 1, y1, x1, y2, col);
    Gui.drawRect(x2, y1, x2 + 1, y2, col);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\TooltipManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */