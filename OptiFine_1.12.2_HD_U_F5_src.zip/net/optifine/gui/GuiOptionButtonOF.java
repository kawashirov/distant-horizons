package net.optifine.gui;

import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.settings.GameSettings;

public class GuiOptionButtonOF extends GuiOptionButton implements IOptionControl {
  private GameSettings.Options option = null;
  
  public GuiOptionButtonOF(int id, int x, int y, GameSettings.Options option, String text) {
    super(id, x, y, option, text);
    this.option = option;
  }
  
  public GameSettings.Options getOption() {
    return this.option;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiOptionButtonOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */