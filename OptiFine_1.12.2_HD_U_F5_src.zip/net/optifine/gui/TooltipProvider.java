package net.optifine.gui;

import java.awt.Rectangle;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public interface TooltipProvider {
  Rectangle getTooltipBounds(GuiScreen paramGuiScreen, int paramInt1, int paramInt2);
  
  String[] getTooltipLines(GuiButton paramGuiButton, int paramInt);
  
  boolean isRenderBorder();
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\TooltipProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */