package net.optifine.gui;

import java.io.IOException;
import java.util.List;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiVideoSettings;

public class GuiScreenOF extends GuiScreen {
  protected void actionPerformedRightClick(GuiButton button) throws IOException {}
  
  protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
    super.mouseClicked(mouseX, mouseY, mouseButton);
    if (mouseButton == 1) {
      GuiButton btn = getSelectedButton(mouseX, mouseY, this.buttonList);
      if (btn != null)
        if (btn.enabled) {
          btn.playPressSound(this.mc.getSoundHandler());
          actionPerformedRightClick(btn);
        }  
    } 
  }
  
  public static GuiButton getSelectedButton(int x, int y, List<GuiButton> listButtons) {
    for (int i = 0; i < listButtons.size(); i++) {
      GuiButton btn = listButtons.get(i);
      if (btn.visible) {
        int btnWidth = GuiVideoSettings.getButtonWidth(btn);
        int btnHeight = GuiVideoSettings.getButtonHeight(btn);
        if (x >= btn.x && y >= btn.y && x < btn.x + btnWidth && y < btn.y + btnHeight)
          return btn; 
      } 
    } 
    return null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiScreenOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */