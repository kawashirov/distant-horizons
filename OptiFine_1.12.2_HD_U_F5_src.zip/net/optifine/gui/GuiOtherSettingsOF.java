package net.optifine.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;

public class GuiOtherSettingsOF extends GuiScreen implements GuiYesNoCallback {
  private GuiScreen prevScreen;
  
  protected String title;
  
  private GameSettings settings;
  
  private static GameSettings.Options[] enumOptions = new GameSettings.Options[] { 
      GameSettings.Options.LAGOMETER, GameSettings.Options.PROFILER, GameSettings.Options.SHOW_FPS, GameSettings.Options.ADVANCED_TOOLTIPS, GameSettings.Options.WEATHER, GameSettings.Options.TIME, GameSettings.Options.USE_FULLSCREEN, GameSettings.Options.FULLSCREEN_MODE, GameSettings.Options.ANAGLYPH, GameSettings.Options.AUTOSAVE_TICKS, 
      GameSettings.Options.SCREENSHOT_SIZE, GameSettings.Options.SHOW_GL_ERRORS };
  
  private TooltipManager tooltipManager = new TooltipManager(this, new TooltipProviderOptions());
  
  public GuiOtherSettingsOF(GuiScreen guiscreen, GameSettings gamesettings) {
    this.prevScreen = guiscreen;
    this.settings = gamesettings;
  }
  
  public void initGui() {
    this.title = I18n.format("of.options.otherTitle", new Object[0]);
    this.buttonList.clear();
    for (int i = 0; i < enumOptions.length; i++) {
      GameSettings.Options enumoptions = enumOptions[i];
      int x = this.width / 2 - 155 + i % 2 * 160;
      int y = this.height / 6 + 21 * i / 2 - 12;
      if (!enumoptions.isFloat()) {
        this.buttonList.add(new GuiOptionButtonOF(enumoptions.getOrdinal(), x, y, enumoptions, this.settings.getKeyBinding(enumoptions)));
      } else {
        this.buttonList.add(new GuiOptionSliderOF(enumoptions.getOrdinal(), x, y, enumoptions));
      } 
    } 
    this.buttonList.add(new GuiButton(210, this.width / 2 - 100, this.height / 6 + 168 + 11 - 44, I18n.format("of.options.other.reset", new Object[0])));
    this.buttonList.add(new GuiButton(200, this.width / 2 - 100, this.height / 6 + 168 + 11, I18n.format("gui.done", new Object[0])));
  }
  
  protected void actionPerformed(GuiButton guibutton) {
    if (!guibutton.enabled)
      return; 
    if (guibutton.id < 200 && guibutton instanceof GuiOptionButton) {
      this.settings.setOptionValue(((GuiOptionButton)guibutton).getOption(), 1);
      guibutton.displayString = this.settings.getKeyBinding(GameSettings.Options.byOrdinal(guibutton.id));
    } 
    if (guibutton.id == 200) {
      this.mc.gameSettings.saveOptions();
      this.mc.displayGuiScreen(this.prevScreen);
    } 
    if (guibutton.id == 210) {
      this.mc.gameSettings.saveOptions();
      GuiYesNo guiyesno = new GuiYesNo(this, I18n.format("of.message.other.reset", new Object[0]), "", 9999);
      this.mc.displayGuiScreen((GuiScreen)guiyesno);
    } 
  }
  
  public void confirmClicked(boolean flag, int i) {
    if (flag)
      this.mc.gameSettings.resetSettings(); 
    this.mc.displayGuiScreen(this);
  }
  
  public void drawScreen(int x, int y, float f) {
    drawDefaultBackground();
    drawCenteredString(this.fontRenderer, this.title, this.width / 2, 15, 16777215);
    super.drawScreen(x, y, f);
    this.tooltipManager.drawTooltips(x, y, this.buttonList);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiOtherSettingsOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */