package net.optifine.gui;

import Config;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiVideoSettings;
import net.optifine.shaders.Shaders;

public class GuiChatOF extends GuiChat {
  private static final String CMD_RELOAD_SHADERS = "/reloadShaders";
  
  private static final String CMD_RELOAD_CHUNKS = "/reloadChunks";
  
  public GuiChatOF(GuiChat guiChat) {
    super(GuiVideoSettings.getGuiChatText(guiChat));
  }
  
  public void sendChatMessage(String msg) {
    if (checkCustomCommand(msg)) {
      this.mc.ingameGUI.getChatGUI().addToSentMessages(msg);
      return;
    } 
    super.sendChatMessage(msg);
  }
  
  private boolean checkCustomCommand(String msg) {
    if (msg == null)
      return false; 
    msg = msg.trim();
    if (msg.equals("/reloadShaders")) {
      if (Config.isShaders()) {
        Shaders.uninit();
        Shaders.loadShaderPack();
      } 
      return true;
    } 
    if (msg.equals("/reloadChunks")) {
      this.mc.renderGlobal.loadRenderers();
      return true;
    } 
    return false;
  }
  
  public void setCompletions(String... newCompletions) {
    String prefix = GuiVideoSettings.getGuiChatText(this);
    if ("/reloadShaders".startsWith(prefix))
      newCompletions = (String[])Config.addObjectToArray((Object[])newCompletions, "/reloadShaders"); 
    if ("/reloadChunks".startsWith(prefix))
      newCompletions = (String[])Config.addObjectToArray((Object[])newCompletions, "/reloadChunks"); 
    super.setCompletions(newCompletions);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\gui\GuiChatOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */