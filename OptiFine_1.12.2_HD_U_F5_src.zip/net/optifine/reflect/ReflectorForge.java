package net.optifine.reflect;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.EntityLiving;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapData;

public class ReflectorForge {
  public static Object EVENT_RESULT_ALLOW = Reflector.getFieldValue(Reflector.Event_Result_ALLOW);
  
  public static Object EVENT_RESULT_DENY = Reflector.getFieldValue(Reflector.Event_Result_DENY);
  
  public static Object EVENT_RESULT_DEFAULT = Reflector.getFieldValue(Reflector.Event_Result_DEFAULT);
  
  public static void FMLClientHandler_trackBrokenTexture(ResourceLocation loc, String message) {
    if (Reflector.FMLClientHandler_trackBrokenTexture.exists())
      return; 
    Object instance = Reflector.call(Reflector.FMLClientHandler_instance, new Object[0]);
    Reflector.call(instance, Reflector.FMLClientHandler_trackBrokenTexture, new Object[] { loc, message });
  }
  
  public static void FMLClientHandler_trackMissingTexture(ResourceLocation loc) {
    if (Reflector.FMLClientHandler_trackMissingTexture.exists())
      return; 
    Object instance = Reflector.call(Reflector.FMLClientHandler_instance, new Object[0]);
    Reflector.call(instance, Reflector.FMLClientHandler_trackMissingTexture, new Object[] { loc });
  }
  
  public static void putLaunchBlackboard(String key, Object value) {
    Map<String, Object> blackboard = (Map)Reflector.getFieldValue(Reflector.Launch_blackboard);
    if (blackboard == null)
      return; 
    blackboard.put(key, value);
  }
  
  public static boolean renderFirstPersonHand(RenderGlobal renderGlobal, float partialTicks, int pass) {
    if (!Reflector.ForgeHooksClient_renderFirstPersonHand.exists())
      return false; 
    return Reflector.callBoolean(Reflector.ForgeHooksClient_renderFirstPersonHand, new Object[] { renderGlobal, Float.valueOf(partialTicks), Integer.valueOf(pass) });
  }
  
  public static InputStream getOptiFineResourceStream(String path) {
    if (!Reflector.OptiFineClassTransformer_instance.exists())
      return null; 
    Object instance = Reflector.getFieldValue(Reflector.OptiFineClassTransformer_instance);
    if (instance == null)
      return null; 
    if (path.startsWith("/"))
      path = path.substring(1); 
    byte[] bytes = (byte[])Reflector.call(instance, Reflector.OptiFineClassTransformer_getOptiFineResource, new Object[] { path });
    if (bytes == null)
      return null; 
    InputStream in = new ByteArrayInputStream(bytes);
    return in;
  }
  
  public static boolean blockHasTileEntity(IBlockState state) {
    Block block = state.getBlock();
    if (!Reflector.ForgeBlock_hasTileEntity.exists())
      return block.hasTileEntity(); 
    return Reflector.callBoolean(block, Reflector.ForgeBlock_hasTileEntity, new Object[] { state });
  }
  
  public static boolean isItemDamaged(ItemStack stack) {
    if (!Reflector.ForgeItem_showDurabilityBar.exists())
      return stack.isItemDamaged(); 
    return Reflector.callBoolean(stack.getItem(), Reflector.ForgeItem_showDurabilityBar, new Object[] { stack });
  }
  
  public static boolean armorHasOverlay(ItemArmor itemArmor, ItemStack itemStack) {
    if (Reflector.ForgeItemArmor_hasOverlay.exists())
      return Reflector.callBoolean(itemArmor, Reflector.ForgeItemArmor_hasOverlay, new Object[] { itemStack }); 
    int i = itemArmor.getColor(itemStack);
    return (i != 16777215);
  }
  
  public static int getLightValue(IBlockState stateIn, IBlockAccess worldIn, BlockPos posIn) {
    if (Reflector.ForgeIBlockProperties_getLightValue2.exists())
      return Reflector.callInt(stateIn, Reflector.ForgeIBlockProperties_getLightValue2, new Object[] { worldIn, posIn }); 
    return stateIn.getLightValue();
  }
  
  public static MapData getMapData(ItemMap itemMap, ItemStack stack, World world) {
    if (Reflector.ForgeHooksClient.exists())
      return ((ItemMap)stack.getItem()).getMapData(stack, world); 
    return itemMap.getMapData(stack, world);
  }
  
  public static String[] getForgeModIds() {
    if (!Reflector.Loader.exists())
      return new String[0]; 
    Object loader = Reflector.call(Reflector.Loader_instance, new Object[0]);
    List listActiveMods = (List)Reflector.call(loader, Reflector.Loader_getActiveModList, new Object[0]);
    if (listActiveMods == null)
      return new String[0]; 
    List<String> listModIds = new ArrayList<>();
    for (Iterator it = listActiveMods.iterator(); it.hasNext(); ) {
      Object modContainer = it.next();
      if (!Reflector.ModContainer.isInstance(modContainer))
        continue; 
      String modId = Reflector.callString(modContainer, Reflector.ModContainer_getModId, new Object[0]);
      if (modId == null)
        continue; 
      listModIds.add(modId);
    } 
    String[] modIds = listModIds.<String>toArray(new String[listModIds.size()]);
    return modIds;
  }
  
  public static boolean canEntitySpawn(EntityLiving entityliving, World world, float x, float y, float z) {
    Object canSpawn = Reflector.call(Reflector.ForgeEventFactory_canEntitySpawn, new Object[] { entityliving, world, Float.valueOf(x), Float.valueOf(y), Float.valueOf(z), Boolean.valueOf(false) });
    return (canSpawn == EVENT_RESULT_ALLOW || (canSpawn == EVENT_RESULT_DEFAULT && entityliving.getCanSpawnHere() && entityliving.isNotColliding()));
  }
  
  public static boolean doSpecialSpawn(EntityLiving entityliving, World world, float x, int y, float z) {
    if (Reflector.ForgeEventFactory_doSpecialSpawn.exists())
      return Reflector.callBoolean(Reflector.ForgeEventFactory_doSpecialSpawn, new Object[] { entityliving, world, Float.valueOf(x), Integer.valueOf(y), Float.valueOf(z) }); 
    return false;
  }
  
  public static boolean isAmbientOcclusion(IBakedModel model, IBlockState state) {
    if (Reflector.ForgeIBakedModel_isAmbientOcclusion2.exists())
      return Reflector.callBoolean(model, Reflector.ForgeIBakedModel_isAmbientOcclusion2, new Object[] { state }); 
    return model.isAmbientOcclusion();
  }
  
  public static ICrashReportDetail<String> getDetailItemRegistryName(final Item item) {
    return new ICrashReportDetail<String>() {
        public String call() throws Exception {
          Object registryName = Reflector.call(item, Reflector.IForgeRegistryEntry_Impl_getRegistryName, new Object[0]);
          return String.valueOf(registryName);
        }
      };
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\ReflectorForge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */