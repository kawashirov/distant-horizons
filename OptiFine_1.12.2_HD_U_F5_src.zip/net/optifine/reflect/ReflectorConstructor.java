package net.optifine.reflect;

import Config;
import java.lang.reflect.Constructor;

public class ReflectorConstructor {
  private ReflectorClass reflectorClass = null;
  
  private Class[] parameterTypes = null;
  
  private boolean checked = false;
  
  private Constructor targetConstructor = null;
  
  public ReflectorConstructor(ReflectorClass reflectorClass, Class[] parameterTypes) {
    this.reflectorClass = reflectorClass;
    this.parameterTypes = parameterTypes;
    Constructor c = getTargetConstructor();
  }
  
  public Constructor getTargetConstructor() {
    if (this.checked)
      return this.targetConstructor; 
    this.checked = true;
    Class cls = this.reflectorClass.getTargetClass();
    if (cls == null)
      return null; 
    try {
      this.targetConstructor = findConstructor(cls, this.parameterTypes);
      if (this.targetConstructor == null)
        Config.dbg("(Reflector) Constructor not present: " + cls.getName() + ", params: " + Config.arrayToString((Object[])this.parameterTypes)); 
      if (this.targetConstructor != null)
        this.targetConstructor.setAccessible(true); 
    } catch (Throwable e) {
      e.printStackTrace();
    } 
    return this.targetConstructor;
  }
  
  private static Constructor findConstructor(Class cls, Class[] paramTypes) {
    Constructor[] cs = (Constructor[])cls.getDeclaredConstructors();
    for (int i = 0; i < cs.length; i++) {
      Constructor c = cs[i];
      Class[] types = c.getParameterTypes();
      if (Reflector.matchesTypes(paramTypes, types))
        return c; 
    } 
    return null;
  }
  
  public boolean exists() {
    if (this.checked)
      return (this.targetConstructor != null); 
    return (getTargetConstructor() != null);
  }
  
  public void deactivate() {
    this.checked = true;
    this.targetConstructor = null;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\ReflectorConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */