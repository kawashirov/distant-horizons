package net.optifine.reflect;

import Config;

public class ReflectorClass {
  private String targetClassName = null;
  
  private boolean checked = false;
  
  private Class targetClass = null;
  
  public ReflectorClass(String targetClassName) {
    this(targetClassName, false);
  }
  
  public ReflectorClass(String targetClassName, boolean lazyResolve) {
    this.targetClassName = targetClassName;
    if (!lazyResolve)
      Class clazz = getTargetClass(); 
  }
  
  public ReflectorClass(Class targetClass) {
    this.targetClass = targetClass;
    this.targetClassName = targetClass.getName();
    this.checked = true;
  }
  
  public Class getTargetClass() {
    if (this.checked)
      return this.targetClass; 
    this.checked = true;
    try {
      this.targetClass = Class.forName(this.targetClassName);
    } catch (ClassNotFoundException e) {
      Config.log("(Reflector) Class not present: " + this.targetClassName);
    } catch (Throwable e) {
      e.printStackTrace();
    } 
    return this.targetClass;
  }
  
  public boolean exists() {
    return (getTargetClass() != null);
  }
  
  public String getTargetClassName() {
    return this.targetClassName;
  }
  
  public boolean isInstance(Object obj) {
    if (getTargetClass() == null)
      return false; 
    return getTargetClass().isInstance(obj);
  }
  
  public ReflectorField makeField(String name) {
    return new ReflectorField(this, name);
  }
  
  public ReflectorMethod makeMethod(String name) {
    return new ReflectorMethod(this, name);
  }
  
  public ReflectorMethod makeMethod(String name, Class[] paramTypes) {
    return new ReflectorMethod(this, name, paramTypes);
  }
  
  public ReflectorMethod makeMethod(String name, Class[] paramTypes, boolean lazyResolve) {
    return new ReflectorMethod(this, name, paramTypes, lazyResolve);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\ReflectorClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */