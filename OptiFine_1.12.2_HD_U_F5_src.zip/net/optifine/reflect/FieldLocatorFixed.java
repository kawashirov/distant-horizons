package net.optifine.reflect;

import java.lang.reflect.Field;

public class FieldLocatorFixed implements IFieldLocator {
  private Field field;
  
  public FieldLocatorFixed(Field field) {
    this.field = field;
  }
  
  public Field getField() {
    return this.field;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\FieldLocatorFixed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */