package net.optifine.reflect;

import Config;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.Minecraft;

public class FieldLocatorActionKeyF3 implements IFieldLocator {
  public Field getField() {
    Class<Minecraft> mcClass = Minecraft.class;
    Field fieldRenderChunksMany = getFieldRenderChunksMany();
    if (fieldRenderChunksMany == null) {
      Config.log("(Reflector) Field not present: " + mcClass.getName() + ".actionKeyF3 (field renderChunksMany not found)");
      return null;
    } 
    Field fieldActionkeyF3 = ReflectorRaw.getFieldAfter(Minecraft.class, fieldRenderChunksMany, boolean.class, 0);
    if (fieldActionkeyF3 == null) {
      Config.log("(Reflector) Field not present: " + mcClass.getName() + ".actionKeyF3");
      return null;
    } 
    return fieldActionkeyF3;
  }
  
  private Field getFieldRenderChunksMany() {
    Minecraft mc = Minecraft.getMinecraft();
    boolean oldRenderChunksMany = mc.renderChunksMany;
    Field[] fields = Minecraft.class.getDeclaredFields();
    mc.renderChunksMany = true;
    Field[] fieldsTrue = ReflectorRaw.getFields(mc, fields, boolean.class, Boolean.TRUE);
    mc.renderChunksMany = false;
    Field[] fieldsFalse = ReflectorRaw.getFields(mc, fields, boolean.class, Boolean.FALSE);
    mc.renderChunksMany = oldRenderChunksMany;
    Set<Field> setTrue = new HashSet<>(Arrays.asList(fieldsTrue));
    Set<Field> setFalse = new HashSet<>(Arrays.asList(fieldsFalse));
    Set<Field> setFields = new HashSet<>(setTrue);
    setFields.retainAll(setFalse);
    Field[] fs = setFields.<Field>toArray(new Field[setFields.size()]);
    if (fs.length != 1)
      return null; 
    return fs[0];
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\FieldLocatorActionKeyF3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */