package net.optifine.reflect;

public class ReflectorFields {
  private ReflectorClass reflectorClass;
  
  private Class fieldType;
  
  private int fieldCount;
  
  private ReflectorField[] reflectorFields;
  
  public ReflectorFields(ReflectorClass reflectorClass, Class fieldType, int fieldCount) {
    this.reflectorClass = reflectorClass;
    this.fieldType = fieldType;
    if (!reflectorClass.exists())
      return; 
    if (fieldType == null)
      return; 
    this.reflectorFields = new ReflectorField[fieldCount];
    for (int i = 0; i < this.reflectorFields.length; i++)
      this.reflectorFields[i] = new ReflectorField(reflectorClass, fieldType, i); 
  }
  
  public ReflectorClass getReflectorClass() {
    return this.reflectorClass;
  }
  
  public Class getFieldType() {
    return this.fieldType;
  }
  
  public int getFieldCount() {
    return this.fieldCount;
  }
  
  public ReflectorField getReflectorField(int index) {
    if (index < 0 || index >= this.reflectorFields.length)
      return null; 
    return this.reflectorFields[index];
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\ReflectorFields.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */