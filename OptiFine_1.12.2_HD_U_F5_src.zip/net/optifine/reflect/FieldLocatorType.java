package net.optifine.reflect;

import Config;
import java.lang.reflect.Field;

public class FieldLocatorType implements IFieldLocator {
  private ReflectorClass reflectorClass = null;
  
  private Class targetFieldType = null;
  
  private int targetFieldIndex;
  
  public FieldLocatorType(ReflectorClass reflectorClass, Class targetFieldType) {
    this(reflectorClass, targetFieldType, 0);
  }
  
  public FieldLocatorType(ReflectorClass reflectorClass, Class targetFieldType, int targetFieldIndex) {
    this.reflectorClass = reflectorClass;
    this.targetFieldType = targetFieldType;
    this.targetFieldIndex = targetFieldIndex;
  }
  
  public Field getField() {
    Class cls = this.reflectorClass.getTargetClass();
    if (cls == null)
      return null; 
    try {
      Field[] fileds = cls.getDeclaredFields();
      int fieldIndex = 0;
      for (int i = 0; i < fileds.length; i++) {
        Field field = fileds[i];
        if (field.getType() == this.targetFieldType)
          if (fieldIndex != this.targetFieldIndex) {
            fieldIndex++;
          } else {
            field.setAccessible(true);
            return field;
          }  
      } 
      Config.log("(Reflector) Field not present: " + cls.getName() + ".(type: " + this.targetFieldType + ", index: " + this.targetFieldIndex + ")");
      return null;
    } catch (SecurityException e) {
      e.printStackTrace();
      return null;
    } catch (Throwable e) {
      e.printStackTrace();
      return null;
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\FieldLocatorType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */