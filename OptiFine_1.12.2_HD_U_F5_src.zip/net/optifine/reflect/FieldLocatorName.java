package net.optifine.reflect;

import Config;
import java.lang.reflect.Field;

public class FieldLocatorName implements IFieldLocator {
  private ReflectorClass reflectorClass = null;
  
  private String targetFieldName = null;
  
  public FieldLocatorName(ReflectorClass reflectorClass, String targetFieldName) {
    this.reflectorClass = reflectorClass;
    this.targetFieldName = targetFieldName;
  }
  
  public Field getField() {
    Class cls = this.reflectorClass.getTargetClass();
    if (cls == null)
      return null; 
    try {
      Field targetField = getDeclaredField(cls, this.targetFieldName);
      targetField.setAccessible(true);
      return targetField;
    } catch (NoSuchFieldException e) {
      Config.log("(Reflector) Field not present: " + cls.getName() + "." + this.targetFieldName);
      return null;
    } catch (SecurityException e) {
      e.printStackTrace();
      return null;
    } catch (Throwable e) {
      e.printStackTrace();
      return null;
    } 
  }
  
  private Field getDeclaredField(Class<Object> cls, String name) throws NoSuchFieldException {
    Field[] fields = cls.getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
      Field field = fields[i];
      if (field.getName().equals(name))
        return field; 
    } 
    if (cls == Object.class)
      throw new NoSuchFieldException(name); 
    return getDeclaredField(cls.getSuperclass(), name);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\FieldLocatorName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */