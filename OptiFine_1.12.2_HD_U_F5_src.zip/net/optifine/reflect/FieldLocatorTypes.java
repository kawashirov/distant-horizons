package net.optifine.reflect;

import Config;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FieldLocatorTypes implements IFieldLocator {
  private Field field = null;
  
  public FieldLocatorTypes(Class cls, Class[] preTypes, Class<?> type, Class[] postTypes, String errorName) {
    Field[] fs = cls.getDeclaredFields();
    List<Class<?>> types = new ArrayList<>();
    for (int i = 0; i < fs.length; i++) {
      Field field = fs[i];
      types.add(field.getType());
    } 
    List<Class<?>> typesMatch = new ArrayList<>();
    typesMatch.addAll(Arrays.asList(preTypes));
    typesMatch.add(type);
    typesMatch.addAll(Arrays.asList(postTypes));
    int index = Collections.indexOfSubList(types, typesMatch);
    if (index < 0) {
      Config.log("(Reflector) Field not found: " + errorName);
      return;
    } 
    int index2 = Collections.indexOfSubList(types.subList(index + 1, types.size()), typesMatch);
    if (index2 >= 0) {
      Config.log("(Reflector) More than one match found for field: " + errorName);
      return;
    } 
    int indexField = index + preTypes.length;
    this.field = fs[indexField];
  }
  
  public Field getField() {
    return this.field;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\reflect\FieldLocatorTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */