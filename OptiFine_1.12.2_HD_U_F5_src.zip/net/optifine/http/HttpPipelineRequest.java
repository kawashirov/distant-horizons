package net.optifine.http;

public class HttpPipelineRequest {
  private HttpRequest httpRequest = null;
  
  private HttpListener httpListener = null;
  
  private boolean closed = false;
  
  public HttpPipelineRequest(HttpRequest httpRequest, HttpListener httpListener) {
    this.httpRequest = httpRequest;
    this.httpListener = httpListener;
  }
  
  public HttpRequest getHttpRequest() {
    return this.httpRequest;
  }
  
  public HttpListener getHttpListener() {
    return this.httpListener;
  }
  
  public boolean isClosed() {
    return this.closed;
  }
  
  public void setClosed(boolean closed) {
    this.closed = closed;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\http\HttpPipelineRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */