package net.optifine.http;

import net.minecraft.client.Minecraft;

public class FileDownloadThread extends Thread {
  private String urlString = null;
  
  private IFileDownloadListener listener = null;
  
  public FileDownloadThread(String urlString, IFileDownloadListener listener) {
    this.urlString = urlString;
    this.listener = listener;
  }
  
  public void run() {
    try {
      byte[] bytes = HttpPipeline.get(this.urlString, Minecraft.getMinecraft().getProxy());
      this.listener.fileDownloadFinished(this.urlString, bytes, null);
    } catch (Exception e) {
      this.listener.fileDownloadFinished(this.urlString, null, e);
    } 
  }
  
  public String getUrlString() {
    return this.urlString;
  }
  
  public IFileDownloadListener getListener() {
    return this.listener;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\http\FileDownloadThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */