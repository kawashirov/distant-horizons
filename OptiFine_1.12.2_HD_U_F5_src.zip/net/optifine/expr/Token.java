package net.optifine.expr;

public class Token {
  private TokenType type;
  
  private String text;
  
  public Token(TokenType type, String text) {
    this.type = type;
    this.text = text;
  }
  
  public TokenType getType() {
    return this.type;
  }
  
  public String getText() {
    return this.text;
  }
  
  public String toString() {
    return this.text;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */