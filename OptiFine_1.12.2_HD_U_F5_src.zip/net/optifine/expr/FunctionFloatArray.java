package net.optifine.expr;

public class FunctionFloatArray implements IExpressionFloatArray {
  private FunctionType type;
  
  private IExpression[] arguments;
  
  public FunctionFloatArray(FunctionType type, IExpression[] arguments) {
    this.type = type;
    this.arguments = arguments;
  }
  
  public float[] eval() {
    return this.type.evalFloatArray(this.arguments);
  }
  
  public String toString() {
    return "" + this.type + "()";
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\FunctionFloatArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */