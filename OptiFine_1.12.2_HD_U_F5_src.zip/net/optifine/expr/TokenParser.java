package net.optifine.expr;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class TokenParser {
  public static Token[] parse(String str) throws IOException, ParseException {
    Reader r = new StringReader(str);
    PushbackReader pr = new PushbackReader(r);
    List<Token> list = new ArrayList<>();
    while (true) {
      int i = pr.read();
      if (i < 0)
        break; 
      char ch = (char)i;
      if (Character.isWhitespace(ch))
        continue; 
      TokenType type = TokenType.getTypeByFirstChar(ch);
      if (type == null)
        throw new ParseException("Invalid character: '" + ch + "', in: " + str); 
      Token token = readToken(ch, type, pr);
      list.add(token);
    } 
    Token[] tokens = list.<Token>toArray(new Token[list.size()]);
    return tokens;
  }
  
  private static Token readToken(char chFirst, TokenType type, PushbackReader pr) throws IOException {
    StringBuffer sb = new StringBuffer();
    sb.append(chFirst);
    while (true) {
      int i = pr.read();
      if (i < 0)
        break; 
      char ch = (char)i;
      if (!type.hasCharNext(ch)) {
        pr.unread(ch);
        break;
      } 
      sb.append(ch);
    } 
    return new Token(type, sb.toString());
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\TokenParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */