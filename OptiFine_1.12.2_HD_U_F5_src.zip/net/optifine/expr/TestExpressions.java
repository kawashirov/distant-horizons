package net.optifine.expr;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestExpressions {
  public static void main(String[] args) throws Exception {
    ExpressionParser ep = new ExpressionParser(null);
    while (true) {
      try {
        InputStreamReader ir = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(ir);
        String line = br.readLine();
        if (line.length() <= 0)
          break; 
        IExpression expr = ep.parse(line);
        if (expr instanceof IExpressionFloat) {
          IExpressionFloat ef = (IExpressionFloat)expr;
          float val = ef.eval();
          System.out.println("" + val);
        } 
        if (expr instanceof IExpressionBool) {
          IExpressionBool eb = (IExpressionBool)expr;
          boolean val = eb.eval();
          System.out.println("" + val);
        } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\TestExpressions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */