package net.optifine.expr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ParametersVariable implements IParameters {
  private ExpressionType[] first;
  
  private ExpressionType[] repeat;
  
  private ExpressionType[] last;
  
  private int maxCount = Integer.MAX_VALUE;
  
  private static final ExpressionType[] EMPTY = new ExpressionType[0];
  
  public ParametersVariable() {
    this(null, null, null);
  }
  
  public ParametersVariable(ExpressionType[] first, ExpressionType[] repeat, ExpressionType[] last) {
    this(first, repeat, last, 2147483647);
  }
  
  public ParametersVariable(ExpressionType[] first, ExpressionType[] repeat, ExpressionType[] last, int maxCount) {
    this.first = normalize(first);
    this.repeat = normalize(repeat);
    this.last = normalize(last);
    this.maxCount = maxCount;
  }
  
  private static ExpressionType[] normalize(ExpressionType[] exprs) {
    if (exprs == null)
      return EMPTY; 
    return exprs;
  }
  
  public ExpressionType[] getFirst() {
    return this.first;
  }
  
  public ExpressionType[] getRepeat() {
    return this.repeat;
  }
  
  public ExpressionType[] getLast() {
    return this.last;
  }
  
  public int getCountRepeat() {
    if (this.first == null)
      return 0; 
    return this.first.length;
  }
  
  public ExpressionType[] getParameterTypes(IExpression[] arguments) {
    int countFixedParams = this.first.length + this.last.length;
    int countVarArgs = arguments.length - countFixedParams;
    int countRepeat = 0;
    int countVarParams = 0;
    while (countVarParams + this.repeat.length <= countVarArgs && countFixedParams + countVarParams + this.repeat.length <= this.maxCount) {
      countRepeat++;
      countVarParams += this.repeat.length;
    } 
    List<ExpressionType> list = new ArrayList<>();
    list.addAll(Arrays.asList(this.first));
    for (int i = 0; i < countRepeat; i++)
      list.addAll(Arrays.asList(this.repeat)); 
    list.addAll(Arrays.asList(this.last));
    ExpressionType[] ets = list.<ExpressionType>toArray(new ExpressionType[list.size()]);
    return ets;
  }
  
  public ParametersVariable first(ExpressionType... first) {
    return new ParametersVariable(first, this.repeat, this.last);
  }
  
  public ParametersVariable repeat(ExpressionType... repeat) {
    return new ParametersVariable(this.first, repeat, this.last);
  }
  
  public ParametersVariable last(ExpressionType... last) {
    return new ParametersVariable(this.first, this.repeat, last);
  }
  
  public ParametersVariable maxCount(int maxCount) {
    return new ParametersVariable(this.first, this.repeat, this.last, maxCount);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\ParametersVariable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */