package net.optifine.expr;

public class ConstantFloat implements IExpressionFloat {
  private float value;
  
  public ConstantFloat(float value) {
    this.value = value;
  }
  
  public float eval() {
    return this.value;
  }
  
  public String toString() {
    return "" + this.value;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\ConstantFloat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */