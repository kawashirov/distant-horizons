package net.optifine.expr;

public class Parameters implements IParameters {
  private ExpressionType[] parameterTypes;
  
  public Parameters(ExpressionType[] parameterTypes) {
    this.parameterTypes = parameterTypes;
  }
  
  public ExpressionType[] getParameterTypes(IExpression[] params) {
    return this.parameterTypes;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\expr\Parameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */