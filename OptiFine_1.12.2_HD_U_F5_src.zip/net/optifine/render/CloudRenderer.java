package net.optifine.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class CloudRenderer {
  private Minecraft mc;
  
  private boolean updated = false;
  
  private boolean renderFancy = false;
  
  int cloudTickCounter;
  
  private Vec3d cloudColor;
  
  float partialTicks;
  
  private boolean updateRenderFancy = false;
  
  private int updateCloudTickCounter = 0;
  
  private Vec3d updateCloudColor = new Vec3d(-1.0D, -1.0D, -1.0D);
  
  private double updatePlayerX = 0.0D;
  
  private double updatePlayerY = 0.0D;
  
  private double updatePlayerZ = 0.0D;
  
  private int glListClouds = -1;
  
  public CloudRenderer(Minecraft mc) {
    this.mc = mc;
    this.glListClouds = GLAllocation.generateDisplayLists(1);
  }
  
  public void prepareToRender(boolean renderFancy, int cloudTickCounter, float partialTicks, Vec3d cloudColor) {
    this.renderFancy = renderFancy;
    this.cloudTickCounter = cloudTickCounter;
    this.partialTicks = partialTicks;
    this.cloudColor = cloudColor;
  }
  
  public boolean shouldUpdateGlList() {
    if (!this.updated)
      return true; 
    if (this.renderFancy != this.updateRenderFancy)
      return true; 
    if (this.cloudTickCounter >= this.updateCloudTickCounter + 20)
      return true; 
    if (Math.abs(this.cloudColor.x - this.updateCloudColor.x) > 0.003D)
      return true; 
    if (Math.abs(this.cloudColor.y - this.updateCloudColor.y) > 0.003D)
      return true; 
    if (Math.abs(this.cloudColor.z - this.updateCloudColor.z) > 0.003D)
      return true; 
    Entity rve = this.mc.getRenderViewEntity();
    boolean belowCloudsPrev = (this.updatePlayerY + rve.getEyeHeight() < 128.0D + (this.mc.gameSettings.ofCloudsHeight * 128.0F));
    boolean belowClouds = (rve.prevPosY + rve.getEyeHeight() < 128.0D + (this.mc.gameSettings.ofCloudsHeight * 128.0F));
    if (belowClouds != belowCloudsPrev)
      return true; 
    return false;
  }
  
  public void startUpdateGlList() {
    GL11.glNewList(this.glListClouds, 4864);
  }
  
  public void endUpdateGlList() {
    GL11.glEndList();
    this.updateRenderFancy = this.renderFancy;
    this.updateCloudTickCounter = this.cloudTickCounter;
    this.updateCloudColor = this.cloudColor;
    this.updatePlayerX = (this.mc.getRenderViewEntity()).prevPosX;
    this.updatePlayerY = (this.mc.getRenderViewEntity()).prevPosY;
    this.updatePlayerZ = (this.mc.getRenderViewEntity()).prevPosZ;
    this.updated = true;
    GlStateManager.resetColor();
  }
  
  public void renderGlList() {
    Entity entityliving = this.mc.getRenderViewEntity();
    double exactPlayerX = entityliving.prevPosX + (entityliving.posX - entityliving.prevPosX) * this.partialTicks;
    double exactPlayerY = entityliving.prevPosY + (entityliving.posY - entityliving.prevPosY) * this.partialTicks;
    double exactPlayerZ = entityliving.prevPosZ + (entityliving.posZ - entityliving.prevPosZ) * this.partialTicks;
    double dc = ((this.cloudTickCounter - this.updateCloudTickCounter) + this.partialTicks);
    float cdx = (float)(exactPlayerX - this.updatePlayerX + dc * 0.03D);
    float cdy = (float)(exactPlayerY - this.updatePlayerY);
    float cdz = (float)(exactPlayerZ - this.updatePlayerZ);
    GlStateManager.pushMatrix();
    if (this.renderFancy) {
      GlStateManager.translate(-cdx / 12.0F, -cdy, -cdz / 12.0F);
    } else {
      GlStateManager.translate(-cdx, -cdy, -cdz);
    } 
    GlStateManager.callList(this.glListClouds);
    GlStateManager.popMatrix();
    GlStateManager.resetColor();
  }
  
  public void reset() {
    this.updated = false;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\render\CloudRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */