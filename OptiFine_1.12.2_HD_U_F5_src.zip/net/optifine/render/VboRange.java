package net.optifine.render;

import net.optifine.util.LinkedList;

public class VboRange {
  private int position = -1;
  
  private int size = 0;
  
  private LinkedList.Node<VboRange> node = new LinkedList.Node(this);
  
  public int getPosition() {
    return this.position;
  }
  
  public int getSize() {
    return this.size;
  }
  
  public int getPositionNext() {
    return this.position + this.size;
  }
  
  public void setPosition(int position) {
    this.position = position;
  }
  
  public void setSize(int size) {
    this.size = size;
  }
  
  public LinkedList.Node<VboRange> getNode() {
    return this.node;
  }
  
  public VboRange getPrev() {
    LinkedList.Node<VboRange> nodePrev = this.node.getPrev();
    if (nodePrev == null)
      return null; 
    return (VboRange)nodePrev.getItem();
  }
  
  public VboRange getNext() {
    LinkedList.Node<VboRange> nodeNext = this.node.getNext();
    if (nodeNext == null)
      return null; 
    return (VboRange)nodeNext.getItem();
  }
  
  public String toString() {
    return "" + this.position + "/" + this.size + "/" + (this.position + this.size);
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\render\VboRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */