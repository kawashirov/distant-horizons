package net.optifine.render;

import Config;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.VboRenderList;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.BlockRenderLayer;
import net.optifine.util.LinkedList;

public class VboRegion {
  private BlockRenderLayer layer = null;
  
  private int glBufferId = OpenGlHelper.glGenBuffers();
  
  private int capacity = 4096;
  
  private int positionTop = 0;
  
  private int sizeUsed;
  
  private LinkedList<VboRange> rangeList = new LinkedList();
  
  private VboRange compactRangeLast = null;
  
  private IntBuffer bufferIndexVertex = Config.createDirectIntBuffer(this.capacity);
  
  private IntBuffer bufferCountVertex = Config.createDirectIntBuffer(this.capacity);
  
  private int drawMode = 7;
  
  private final int vertexBytes = DefaultVertexFormats.BLOCK.getNextOffset();
  
  public VboRegion(BlockRenderLayer layer) {
    this.layer = layer;
    bindBuffer();
    long capacityBytes = toBytes(this.capacity);
    OpenGlHelper.glBufferData(OpenGlHelper.GL_ARRAY_BUFFER, capacityBytes, OpenGlHelper.GL_STATIC_DRAW);
    unbindBuffer();
  }
  
  public void bufferData(ByteBuffer data, VboRange range) {
    int posOld = range.getPosition();
    int sizeOld = range.getSize();
    int sizeNew = toVertex(data.limit());
    if (sizeNew <= 0) {
      if (posOld >= 0) {
        range.setPosition(-1);
        range.setSize(0);
        this.rangeList.remove(range.getNode());
        this.sizeUsed -= sizeOld;
      } 
      return;
    } 
    if (sizeNew > sizeOld) {
      range.setPosition(this.positionTop);
      range.setSize(sizeNew);
      this.positionTop += sizeNew;
      if (posOld >= 0)
        this.rangeList.remove(range.getNode()); 
      this.rangeList.addLast(range.getNode());
    } 
    range.setSize(sizeNew);
    this.sizeUsed += sizeNew - sizeOld;
    checkVboSize(range.getPositionNext());
    long positionBytes = toBytes(range.getPosition());
    bindBuffer();
    OpenGlHelper.glBufferSubData(OpenGlHelper.GL_ARRAY_BUFFER, positionBytes, data);
    unbindBuffer();
    if (this.positionTop > this.sizeUsed * 11 / 10)
      compactRanges(1); 
  }
  
  private void compactRanges(int countMax) {
    if (this.rangeList.isEmpty())
      return; 
    VboRange range = this.compactRangeLast;
    if (range == null || !this.rangeList.contains(range.getNode()))
      range = (VboRange)this.rangeList.getFirst().getItem(); 
    int posCompact = range.getPosition();
    VboRange rangePrev = range.getPrev();
    if (rangePrev == null) {
      posCompact = 0;
    } else {
      posCompact = rangePrev.getPositionNext();
    } 
    int count = 0;
    while (range != null && count < countMax) {
      count++;
      if (range.getPosition() == posCompact) {
        posCompact += range.getSize();
        range = range.getNext();
        continue;
      } 
      int sizeFree = range.getPosition() - posCompact;
      if (range.getSize() <= sizeFree) {
        copyVboData(range.getPosition(), posCompact, range.getSize());
        range.setPosition(posCompact);
        posCompact += range.getSize();
        range = range.getNext();
        continue;
      } 
      checkVboSize(this.positionTop + range.getSize());
      copyVboData(range.getPosition(), this.positionTop, range.getSize());
      range.setPosition(this.positionTop);
      this.positionTop += range.getSize();
      VboRange rangeNext = range.getNext();
      this.rangeList.remove(range.getNode());
      this.rangeList.addLast(range.getNode());
      range = rangeNext;
    } 
    if (range == null)
      this.positionTop = ((VboRange)this.rangeList.getLast().getItem()).getPositionNext(); 
    this.compactRangeLast = range;
  }
  
  private void checkRanges() {
    int count = 0;
    int size = 0;
    VboRange range = (VboRange)this.rangeList.getFirst().getItem();
    while (range != null) {
      count++;
      size += range.getSize();
      if (range.getPosition() < 0 || range.getSize() <= 0 || range.getPositionNext() > this.positionTop)
        throw new RuntimeException("Invalid range: " + range); 
      VboRange rangePrev = range.getPrev();
      if (rangePrev != null)
        if (range.getPosition() < rangePrev.getPositionNext())
          throw new RuntimeException("Invalid range: " + range);  
      VboRange rangeNext = range.getNext();
      if (rangeNext != null)
        if (range.getPositionNext() > rangeNext.getPosition())
          throw new RuntimeException("Invalid range: " + range);  
      range = range.getNext();
    } 
    if (count != this.rangeList.getSize())
      throw new RuntimeException("Invalid count: " + count + " <> " + this.rangeList.getSize()); 
    if (size != this.sizeUsed)
      throw new RuntimeException("Invalid size: " + size + " <> " + this.sizeUsed); 
  }
  
  private void checkVboSize(int sizeMin) {
    if (this.capacity < sizeMin)
      expandVbo(sizeMin); 
  }
  
  private void copyVboData(int posFrom, int posTo, int size) {
    long posFromBytes = toBytes(posFrom);
    long posToBytes = toBytes(posTo);
    long sizeBytes = toBytes(size);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_READ_BUFFER, this.glBufferId);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_WRITE_BUFFER, this.glBufferId);
    OpenGlHelper.glCopyBufferSubData(OpenGlHelper.GL_COPY_READ_BUFFER, OpenGlHelper.GL_COPY_WRITE_BUFFER, posFromBytes, posToBytes, sizeBytes);
    Config.checkGlError("Copy VBO range");
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_READ_BUFFER, 0);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_WRITE_BUFFER, 0);
  }
  
  private void expandVbo(int sizeMin) {
    int capacityNew = this.capacity * 6 / 4;
    while (capacityNew < sizeMin)
      capacityNew = capacityNew * 6 / 4; 
    long capacityBytes = toBytes(this.capacity);
    long capacityNewBytes = toBytes(capacityNew);
    int glBufferIdNew = OpenGlHelper.glGenBuffers();
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, glBufferIdNew);
    OpenGlHelper.glBufferData(OpenGlHelper.GL_ARRAY_BUFFER, capacityNewBytes, OpenGlHelper.GL_STATIC_DRAW);
    Config.checkGlError("Expand VBO");
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, 0);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_READ_BUFFER, this.glBufferId);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_WRITE_BUFFER, glBufferIdNew);
    OpenGlHelper.glCopyBufferSubData(OpenGlHelper.GL_COPY_READ_BUFFER, OpenGlHelper.GL_COPY_WRITE_BUFFER, 0L, 0L, capacityBytes);
    Config.checkGlError("Copy VBO: " + capacityNewBytes);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_READ_BUFFER, 0);
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_COPY_WRITE_BUFFER, 0);
    OpenGlHelper.glDeleteBuffers(this.glBufferId);
    this.bufferIndexVertex = Config.createDirectIntBuffer(capacityNew);
    this.bufferCountVertex = Config.createDirectIntBuffer(capacityNew);
    this.glBufferId = glBufferIdNew;
    this.capacity = capacityNew;
  }
  
  public void bindBuffer() {
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, this.glBufferId);
  }
  
  public void drawArrays(int drawMode, VboRange range) {
    if (this.drawMode != drawMode) {
      if (this.bufferIndexVertex.position() > 0)
        throw new IllegalArgumentException("Mixed region draw modes: " + this.drawMode + " != " + drawMode); 
      this.drawMode = drawMode;
    } 
    this.bufferIndexVertex.put(range.getPosition());
    this.bufferCountVertex.put(range.getSize());
  }
  
  public void finishDraw(VboRenderList vboRenderList) {
    bindBuffer();
    vboRenderList.setupArrayPointers();
    this.bufferIndexVertex.flip();
    this.bufferCountVertex.flip();
    GlStateManager.glMultiDrawArrays(this.drawMode, this.bufferIndexVertex, this.bufferCountVertex);
    this.bufferIndexVertex.limit(this.bufferIndexVertex.capacity());
    this.bufferCountVertex.limit(this.bufferCountVertex.capacity());
    if (this.positionTop > this.sizeUsed * 11 / 10)
      compactRanges(1); 
  }
  
  public void unbindBuffer() {
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, 0);
  }
  
  public void deleteGlBuffers() {
    if (this.glBufferId >= 0) {
      OpenGlHelper.glDeleteBuffers(this.glBufferId);
      this.glBufferId = -1;
    } 
  }
  
  private long toBytes(int vertex) {
    return vertex * this.vertexBytes;
  }
  
  private int toVertex(long bytes) {
    return (int)(bytes / this.vertexBytes);
  }
  
  public int getPositionTop() {
    return this.positionTop;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\render\VboRegion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */