package net.optifine.override;

import Config;
import java.util.Arrays;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.ChunkCache;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.optifine.DynamicLights;
import net.optifine.reflect.Reflector;
import net.optifine.util.ArrayCache;

public class ChunkCacheOF implements IBlockAccess {
  private final ChunkCache chunkCache;
  
  private final int posX;
  
  private final int posY;
  
  private final int posZ;
  
  private final int sizeX;
  
  private final int sizeY;
  
  private final int sizeZ;
  
  private final int sizeXY;
  
  private int[] combinedLights;
  
  private IBlockState[] blockStates;
  
  private final int arraySize;
  
  private final boolean dynamicLights = Config.isDynamicLights();
  
  private static final ArrayCache cacheCombinedLights = new ArrayCache(int.class, 16);
  
  private static final ArrayCache cacheBlockStates = new ArrayCache(IBlockState.class, 16);
  
  public ChunkCacheOF(ChunkCache chunkCache, BlockPos posFromIn, BlockPos posToIn, int subIn) {
    this.chunkCache = chunkCache;
    int minChunkX = posFromIn.getX() - subIn >> 4;
    int minChunkY = posFromIn.getY() - subIn >> 4;
    int minChunkZ = posFromIn.getZ() - subIn >> 4;
    int maxChunkX = posToIn.getX() + subIn >> 4;
    int maxChunkY = posToIn.getY() + subIn >> 4;
    int maxChunkZ = posToIn.getZ() + subIn >> 4;
    this.sizeX = maxChunkX - minChunkX + 1 << 4;
    this.sizeY = maxChunkY - minChunkY + 1 << 4;
    this.sizeZ = maxChunkZ - minChunkZ + 1 << 4;
    this.sizeXY = this.sizeX * this.sizeY;
    this.arraySize = this.sizeX * this.sizeY * this.sizeZ;
    this.posX = minChunkX << 4;
    this.posY = minChunkY << 4;
    this.posZ = minChunkZ << 4;
  }
  
  private int getPositionIndex(BlockPos pos) {
    int dx = pos.getX() - this.posX;
    if (dx < 0 || dx >= this.sizeX)
      return -1; 
    int dy = pos.getY() - this.posY;
    if (dy < 0 || dy >= this.sizeY)
      return -1; 
    int dz = pos.getZ() - this.posZ;
    if (dz < 0 || dz >= this.sizeZ)
      return -1; 
    return dz * this.sizeXY + dy * this.sizeX + dx;
  }
  
  public int getCombinedLight(BlockPos pos, int lightValue) {
    int index = getPositionIndex(pos);
    if (index < 0 || index >= this.arraySize || this.combinedLights == null)
      return getCombinedLightRaw(pos, lightValue); 
    int light = this.combinedLights[index];
    if (light == -1) {
      light = getCombinedLightRaw(pos, lightValue);
      this.combinedLights[index] = light;
    } 
    return light;
  }
  
  private int getCombinedLightRaw(BlockPos pos, int lightValue) {
    int light = this.chunkCache.getCombinedLight(pos, lightValue);
    if (this.dynamicLights)
      if (!getBlockState(pos).isOpaqueCube())
        light = DynamicLights.getCombinedLight(pos, light);  
    return light;
  }
  
  public IBlockState getBlockState(BlockPos pos) {
    int index = getPositionIndex(pos);
    if (index < 0 || index >= this.arraySize || this.blockStates == null)
      return this.chunkCache.getBlockState(pos); 
    IBlockState iblockstate = this.blockStates[index];
    if (iblockstate == null) {
      iblockstate = this.chunkCache.getBlockState(pos);
      this.blockStates[index] = iblockstate;
    } 
    return iblockstate;
  }
  
  public void renderStart() {
    if (this.combinedLights == null)
      this.combinedLights = (int[])cacheCombinedLights.allocate(this.arraySize); 
    Arrays.fill(this.combinedLights, -1);
    if (this.blockStates == null)
      this.blockStates = (IBlockState[])cacheBlockStates.allocate(this.arraySize); 
    Arrays.fill((Object[])this.blockStates, (Object)null);
  }
  
  public void renderFinish() {
    cacheCombinedLights.free(this.combinedLights);
    this.combinedLights = null;
    cacheBlockStates.free(this.blockStates);
    this.blockStates = null;
  }
  
  public boolean isEmpty() {
    return this.chunkCache.isEmpty();
  }
  
  public Biome getBiome(BlockPos pos) {
    return this.chunkCache.getBiome(pos);
  }
  
  public int getStrongPower(BlockPos pos, EnumFacing direction) {
    return this.chunkCache.getStrongPower(pos, direction);
  }
  
  public TileEntity getTileEntity(BlockPos pos) {
    return this.chunkCache.getTileEntity(pos, Chunk.EnumCreateEntityType.CHECK);
  }
  
  public TileEntity getTileEntity(BlockPos pos, Chunk.EnumCreateEntityType type) {
    return this.chunkCache.getTileEntity(pos, type);
  }
  
  public WorldType getWorldType() {
    return this.chunkCache.getWorldType();
  }
  
  public boolean isAirBlock(BlockPos pos) {
    return this.chunkCache.isAirBlock(pos);
  }
  
  public boolean isSideSolid(BlockPos pos, EnumFacing side, boolean _default) {
    return Reflector.callBoolean(this.chunkCache, Reflector.ForgeChunkCache_isSideSolid, new Object[] { pos, side, Boolean.valueOf(_default) });
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\optifine\override\ChunkCacheOF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */