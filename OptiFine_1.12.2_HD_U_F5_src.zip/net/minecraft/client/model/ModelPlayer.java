package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumHandSide;

public class ModelPlayer extends ModelBiped {
  public ModelRenderer bipedLeftArmwear;
  
  public ModelRenderer bipedRightArmwear;
  
  public ModelRenderer bipedLeftLegwear;
  
  public ModelRenderer bipedRightLegwear;
  
  public ModelRenderer bipedBodyWear;
  
  private final ModelRenderer bipedCape;
  
  private final ModelRenderer bipedDeadmau5Head;
  
  private final boolean smallArms;
  
  public ModelPlayer(float modelSize, boolean smallArmsIn) {
    super(modelSize, 0.0F, 64, 64);
    this.smallArms = smallArmsIn;
    this.bipedDeadmau5Head = new ModelRenderer((ModelBase)this, 24, 0);
    this.bipedDeadmau5Head.addBox(-3.0F, -6.0F, -1.0F, 6, 6, 1, modelSize);
    this.bipedCape = new ModelRenderer((ModelBase)this, 0, 0);
    this.bipedCape.setTextureSize(64, 32);
    this.bipedCape.addBox(-5.0F, 0.0F, -1.0F, 10, 16, 1, modelSize);
    if (smallArmsIn) {
      this.bipedLeftArm = new ModelRenderer((ModelBase)this, 32, 48);
      this.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, modelSize);
      this.bipedLeftArm.setRotationPoint(5.0F, 2.5F, 0.0F);
      this.bipedRightArm = new ModelRenderer((ModelBase)this, 40, 16);
      this.bipedRightArm.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, modelSize);
      this.bipedRightArm.setRotationPoint(-5.0F, 2.5F, 0.0F);
      this.bipedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48);
      this.bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, modelSize + 0.25F);
      this.bipedLeftArmwear.setRotationPoint(5.0F, 2.5F, 0.0F);
      this.bipedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32);
      this.bipedRightArmwear.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, modelSize + 0.25F);
      this.bipedRightArmwear.setRotationPoint(-5.0F, 2.5F, 10.0F);
    } else {
      this.bipedLeftArm = new ModelRenderer((ModelBase)this, 32, 48);
      this.bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, modelSize);
      this.bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      this.bipedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48);
      this.bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
      this.bipedLeftArmwear.setRotationPoint(5.0F, 2.0F, 0.0F);
      this.bipedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32);
      this.bipedRightArmwear.addBox(-3.0F, -2.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
      this.bipedRightArmwear.setRotationPoint(-5.0F, 2.0F, 10.0F);
    } 
    this.bipedLeftLeg = new ModelRenderer((ModelBase)this, 16, 48);
    this.bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize);
    this.bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
    this.bipedLeftLegwear = new ModelRenderer((ModelBase)this, 0, 48);
    this.bipedLeftLegwear.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
    this.bipedLeftLegwear.setRotationPoint(1.9F, 12.0F, 0.0F);
    this.bipedRightLegwear = new ModelRenderer((ModelBase)this, 0, 32);
    this.bipedRightLegwear.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, modelSize + 0.25F);
    this.bipedRightLegwear.setRotationPoint(-1.9F, 12.0F, 0.0F);
    this.bipedBodyWear = new ModelRenderer((ModelBase)this, 16, 32);
    this.bipedBodyWear.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, modelSize + 0.25F);
    this.bipedBodyWear.setRotationPoint(0.0F, 0.0F, 0.0F);
  }
  
  public void render(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
    super.render(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
    GlStateManager.pushMatrix();
    if (this.isChild) {
      float f = 2.0F;
      GlStateManager.scale(0.5F, 0.5F, 0.5F);
      GlStateManager.translate(0.0F, 24.0F * scale, 0.0F);
      this.bipedLeftLegwear.render(scale);
      this.bipedRightLegwear.render(scale);
      this.bipedLeftArmwear.render(scale);
      this.bipedRightArmwear.render(scale);
      this.bipedBodyWear.render(scale);
    } else {
      if (entityIn.isSneaking())
        GlStateManager.translate(0.0F, 0.2F, 0.0F); 
      this.bipedLeftLegwear.render(scale);
      this.bipedRightLegwear.render(scale);
      this.bipedLeftArmwear.render(scale);
      this.bipedRightArmwear.render(scale);
      this.bipedBodyWear.render(scale);
    } 
    GlStateManager.popMatrix();
  }
  
  public void renderDeadmau5Head(float scale) {
    copyModelAngles(this.bipedHead, this.bipedDeadmau5Head);
    this.bipedDeadmau5Head.rotationPointX = 0.0F;
    this.bipedDeadmau5Head.rotationPointY = 0.0F;
    this.bipedDeadmau5Head.render(scale);
  }
  
  public void renderCape(float scale) {
    this.bipedCape.render(scale);
  }
  
  public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, Entity entityIn) {
    super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
    copyModelAngles(this.bipedLeftLeg, this.bipedLeftLegwear);
    copyModelAngles(this.bipedRightLeg, this.bipedRightLegwear);
    copyModelAngles(this.bipedLeftArm, this.bipedLeftArmwear);
    copyModelAngles(this.bipedRightArm, this.bipedRightArmwear);
    copyModelAngles(this.bipedBody, this.bipedBodyWear);
  }
  
  public void setVisible(boolean visible) {
    super.setVisible(visible);
    this.bipedLeftArmwear.showModel = visible;
    this.bipedRightArmwear.showModel = visible;
    this.bipedLeftLegwear.showModel = visible;
    this.bipedRightLegwear.showModel = visible;
    this.bipedBodyWear.showModel = visible;
    this.bipedCape.showModel = visible;
    this.bipedDeadmau5Head.showModel = visible;
  }
  
  public void postRenderArm(float scale, EnumHandSide side) {
    ModelRenderer modelrenderer = getArmForSide(side);
    if (this.smallArms) {
      float f = 0.5F * ((side == EnumHandSide.RIGHT) ? true : -1);
      modelrenderer.rotationPointX += f;
      modelrenderer.postRender(scale);
      modelrenderer.rotationPointX -= f;
    } else {
      modelrenderer.postRender(scale);
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\model\ModelPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */