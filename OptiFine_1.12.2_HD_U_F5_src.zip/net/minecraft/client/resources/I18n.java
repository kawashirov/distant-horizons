package net.minecraft.client.resources;

import java.util.Map;

public class I18n {
  private static Locale i18nLocale;
  
  static void setLocale(Locale i18nLocaleIn) {
    i18nLocale = i18nLocaleIn;
  }
  
  public static String format(String translateKey, Object... parameters) {
    return i18nLocale.formatMessage(translateKey, parameters);
  }
  
  public static boolean hasKey(String key) {
    return i18nLocale.hasKey(key);
  }
  
  public static Map getLocaleProperties() {
    return i18nLocale.properties;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\resources\I18n.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */