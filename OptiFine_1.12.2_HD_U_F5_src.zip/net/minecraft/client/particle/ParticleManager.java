package net.minecraft.client.particle;

import Config;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.optifine.reflect.Reflector;

public class ParticleManager {
  private static final ResourceLocation PARTICLE_TEXTURES = new ResourceLocation("textures/particle/particles.png");
  
  protected World world;
  
  private final ArrayDeque<Particle>[][] fxLayers = (ArrayDeque<Particle>[][])new ArrayDeque[4][];
  
  private final Queue<ParticleEmitter> particleEmitters = Queues.newArrayDeque();
  
  private final TextureManager renderer;
  
  private final Random rand = new Random();
  
  private final Map<Integer, IParticleFactory> particleTypes = Maps.newHashMap();
  
  private final Queue<Particle> queue = Queues.newArrayDeque();
  
  public ParticleManager(World worldIn, TextureManager rendererIn) {
    this.world = worldIn;
    this.renderer = rendererIn;
    for (int i = 0; i < 4; i++) {
      this.fxLayers[i] = (ArrayDeque<Particle>[])new ArrayDeque[2];
      for (int j = 0; j < 2; j++)
        this.fxLayers[i][j] = Queues.newArrayDeque(); 
    } 
    registerVanillaParticles();
  }
  
  private void registerVanillaParticles() {
    registerParticle(EnumParticleTypes.EXPLOSION_NORMAL.getParticleID(), (IParticleFactory)new ParticleExplosion.Factory());
    registerParticle(EnumParticleTypes.SPIT.getParticleID(), (IParticleFactory)new ParticleSpit.Factory());
    registerParticle(EnumParticleTypes.WATER_BUBBLE.getParticleID(), (IParticleFactory)new ParticleBubble.Factory());
    registerParticle(EnumParticleTypes.WATER_SPLASH.getParticleID(), (IParticleFactory)new ParticleSplash.Factory());
    registerParticle(EnumParticleTypes.WATER_WAKE.getParticleID(), (IParticleFactory)new ParticleWaterWake.Factory());
    registerParticle(EnumParticleTypes.WATER_DROP.getParticleID(), (IParticleFactory)new ParticleRain.Factory());
    registerParticle(EnumParticleTypes.SUSPENDED.getParticleID(), (IParticleFactory)new ParticleSuspend.Factory());
    registerParticle(EnumParticleTypes.SUSPENDED_DEPTH.getParticleID(), (IParticleFactory)new ParticleSuspendedTown.Factory());
    registerParticle(EnumParticleTypes.CRIT.getParticleID(), (IParticleFactory)new ParticleCrit.Factory());
    registerParticle(EnumParticleTypes.CRIT_MAGIC.getParticleID(), (IParticleFactory)new ParticleCrit.MagicFactory());
    registerParticle(EnumParticleTypes.SMOKE_NORMAL.getParticleID(), (IParticleFactory)new ParticleSmokeNormal.Factory());
    registerParticle(EnumParticleTypes.SMOKE_LARGE.getParticleID(), (IParticleFactory)new ParticleSmokeLarge.Factory());
    registerParticle(EnumParticleTypes.SPELL.getParticleID(), (IParticleFactory)new ParticleSpell.Factory());
    registerParticle(EnumParticleTypes.SPELL_INSTANT.getParticleID(), (IParticleFactory)new ParticleSpell.InstantFactory());
    registerParticle(EnumParticleTypes.SPELL_MOB.getParticleID(), (IParticleFactory)new ParticleSpell.MobFactory());
    registerParticle(EnumParticleTypes.SPELL_MOB_AMBIENT.getParticleID(), (IParticleFactory)new ParticleSpell.AmbientMobFactory());
    registerParticle(EnumParticleTypes.SPELL_WITCH.getParticleID(), (IParticleFactory)new ParticleSpell.WitchFactory());
    registerParticle(EnumParticleTypes.DRIP_WATER.getParticleID(), (IParticleFactory)new ParticleDrip.WaterFactory());
    registerParticle(EnumParticleTypes.DRIP_LAVA.getParticleID(), (IParticleFactory)new ParticleDrip.LavaFactory());
    registerParticle(EnumParticleTypes.VILLAGER_ANGRY.getParticleID(), (IParticleFactory)new ParticleHeart.AngryVillagerFactory());
    registerParticle(EnumParticleTypes.VILLAGER_HAPPY.getParticleID(), (IParticleFactory)new ParticleSuspendedTown.HappyVillagerFactory());
    registerParticle(EnumParticleTypes.TOWN_AURA.getParticleID(), (IParticleFactory)new ParticleSuspendedTown.Factory());
    registerParticle(EnumParticleTypes.NOTE.getParticleID(), (IParticleFactory)new ParticleNote.Factory());
    registerParticle(EnumParticleTypes.PORTAL.getParticleID(), (IParticleFactory)new ParticlePortal.Factory());
    registerParticle(EnumParticleTypes.ENCHANTMENT_TABLE.getParticleID(), (IParticleFactory)new ParticleEnchantmentTable.EnchantmentTable());
    registerParticle(EnumParticleTypes.FLAME.getParticleID(), (IParticleFactory)new ParticleFlame.Factory());
    registerParticle(EnumParticleTypes.LAVA.getParticleID(), (IParticleFactory)new ParticleLava.Factory());
    registerParticle(EnumParticleTypes.FOOTSTEP.getParticleID(), (IParticleFactory)new ParticleFootStep.Factory());
    registerParticle(EnumParticleTypes.CLOUD.getParticleID(), (IParticleFactory)new ParticleCloud.Factory());
    registerParticle(EnumParticleTypes.REDSTONE.getParticleID(), (IParticleFactory)new ParticleRedstone.Factory());
    registerParticle(EnumParticleTypes.FALLING_DUST.getParticleID(), (IParticleFactory)new ParticleFallingDust.Factory());
    registerParticle(EnumParticleTypes.SNOWBALL.getParticleID(), (IParticleFactory)new ParticleBreaking.SnowballFactory());
    registerParticle(EnumParticleTypes.SNOW_SHOVEL.getParticleID(), (IParticleFactory)new ParticleSnowShovel.Factory());
    registerParticle(EnumParticleTypes.SLIME.getParticleID(), (IParticleFactory)new ParticleBreaking.SlimeFactory());
    registerParticle(EnumParticleTypes.HEART.getParticleID(), (IParticleFactory)new ParticleHeart.Factory());
    registerParticle(EnumParticleTypes.BARRIER.getParticleID(), (IParticleFactory)new Barrier.Factory());
    registerParticle(EnumParticleTypes.ITEM_CRACK.getParticleID(), (IParticleFactory)new ParticleBreaking.Factory());
    registerParticle(EnumParticleTypes.BLOCK_CRACK.getParticleID(), (IParticleFactory)new ParticleDigging.Factory());
    registerParticle(EnumParticleTypes.BLOCK_DUST.getParticleID(), (IParticleFactory)new ParticleBlockDust.Factory());
    registerParticle(EnumParticleTypes.EXPLOSION_HUGE.getParticleID(), (IParticleFactory)new ParticleExplosionHuge.Factory());
    registerParticle(EnumParticleTypes.EXPLOSION_LARGE.getParticleID(), (IParticleFactory)new ParticleExplosionLarge.Factory());
    registerParticle(EnumParticleTypes.FIREWORKS_SPARK.getParticleID(), (IParticleFactory)new ParticleFirework.Factory());
    registerParticle(EnumParticleTypes.MOB_APPEARANCE.getParticleID(), (IParticleFactory)new ParticleMobAppearance.Factory());
    registerParticle(EnumParticleTypes.DRAGON_BREATH.getParticleID(), (IParticleFactory)new ParticleDragonBreath.Factory());
    registerParticle(EnumParticleTypes.END_ROD.getParticleID(), (IParticleFactory)new ParticleEndRod.Factory());
    registerParticle(EnumParticleTypes.DAMAGE_INDICATOR.getParticleID(), (IParticleFactory)new ParticleCrit.DamageIndicatorFactory());
    registerParticle(EnumParticleTypes.SWEEP_ATTACK.getParticleID(), (IParticleFactory)new ParticleSweepAttack.Factory());
    registerParticle(EnumParticleTypes.TOTEM.getParticleID(), (IParticleFactory)new ParticleTotem.Factory());
  }
  
  public void registerParticle(int id, IParticleFactory particleFactory) {
    this.particleTypes.put(Integer.valueOf(id), particleFactory);
  }
  
  public void emitParticleAtEntity(Entity entityIn, EnumParticleTypes particleTypes) {
    this.particleEmitters.add(new ParticleEmitter(this.world, entityIn, particleTypes));
  }
  
  public void emitParticleAtEntity(Entity p_191271_1_, EnumParticleTypes p_191271_2_, int p_191271_3_) {
    this.particleEmitters.add(new ParticleEmitter(this.world, p_191271_1_, p_191271_2_, p_191271_3_));
  }
  
  @Nullable
  public Particle spawnEffectParticle(int particleId, double xCoord, double yCoord, double zCoord, double xSpeed, double ySpeed, double zSpeed, int... parameters) {
    IParticleFactory iparticlefactory = this.particleTypes.get(Integer.valueOf(particleId));
    if (iparticlefactory != null) {
      Particle particle = iparticlefactory.createParticle(particleId, this.world, xCoord, yCoord, zCoord, xSpeed, ySpeed, zSpeed, parameters);
      if (particle != null) {
        addEffect(particle);
        return particle;
      } 
    } 
    return null;
  }
  
  public void addEffect(Particle effect) {
    if (effect == null)
      return; 
    if (effect instanceof ParticleFirework.Spark && !Config.isFireworkParticles())
      return; 
    this.queue.add(effect);
  }
  
  public void updateEffects() {
    for (int i = 0; i < 4; i++)
      updateEffectLayer(i); 
    if (!this.particleEmitters.isEmpty()) {
      List<ParticleEmitter> list = Lists.newArrayList();
      for (ParticleEmitter particleemitter : this.particleEmitters) {
        particleemitter.onUpdate();
        if (!particleemitter.isAlive())
          list.add(particleemitter); 
      } 
      this.particleEmitters.removeAll(list);
    } 
    if (!this.queue.isEmpty())
      for (Particle particle = this.queue.poll(); particle != null; particle = this.queue.poll()) {
        int j = particle.getFXLayer();
        int k = particle.shouldDisableDepth() ? 0 : 1;
        if (this.fxLayers[j][k].size() >= 16384)
          this.fxLayers[j][k].removeFirst(); 
        if (particle instanceof Barrier)
          if (reuseBarrierParticle(particle, this.fxLayers[j][k]))
            continue;  
        this.fxLayers[j][k].add(particle);
        continue;
      }  
  }
  
  private void updateEffectLayer(int layer) {
    this.world.profiler.startSection(String.valueOf(layer));
    for (int i = 0; i < 2; i++) {
      this.world.profiler.startSection(String.valueOf(i));
      tickParticleList(this.fxLayers[layer][i]);
      this.world.profiler.endSection();
    } 
    this.world.profiler.endSection();
  }
  
  private void tickParticleList(Queue<Particle> p_187240_1_) {
    if (!p_187240_1_.isEmpty()) {
      Queue<Particle> particlesIn = p_187240_1_;
      long timeStartMs = System.currentTimeMillis();
      int countLeft = particlesIn.size();
      Iterator<Particle> iterator = p_187240_1_.iterator();
      while (iterator.hasNext()) {
        Particle particle = iterator.next();
        tickParticle(particle);
        if (!particle.isAlive())
          iterator.remove(); 
        countLeft--;
        if (System.currentTimeMillis() > timeStartMs + 20L)
          break; 
      } 
      if (countLeft > 0) {
        int countToRemove = countLeft;
        for (Iterator<Particle> it = particlesIn.iterator(); it.hasNext() && countToRemove > 0; ) {
          Particle particle = it.next();
          particle.setExpired();
          it.remove();
          countToRemove--;
        } 
      } 
    } 
  }
  
  private void tickParticle(final Particle particle) {
    try {
      particle.onUpdate();
    } catch (Throwable throwable) {
      CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Ticking Particle");
      CrashReportCategory crashreportcategory = crashreport.makeCategory("Particle being ticked");
      final int i = particle.getFXLayer();
      crashreportcategory.addDetail("Particle", new ICrashReportDetail<String>() {
            public String call() throws Exception {
              return particle.toString();
            }
          });
      crashreportcategory.addDetail("Particle Type", new ICrashReportDetail<String>() {
            public String call() throws Exception {
              if (i == 0)
                return "MISC_TEXTURE"; 
              if (i == 1)
                return "TERRAIN_TEXTURE"; 
              return (i == 3) ? "ENTITY_PARTICLE_TEXTURE" : ("Unknown - " + i);
            }
          });
      throw new ReportedException(crashreport);
    } 
  }
  
  public void renderParticles(Entity entityIn, float partialTicks) {
    float f = ActiveRenderInfo.getRotationX();
    float f1 = ActiveRenderInfo.getRotationZ();
    float f2 = ActiveRenderInfo.getRotationYZ();
    float f3 = ActiveRenderInfo.getRotationXY();
    float f4 = ActiveRenderInfo.getRotationXZ();
    Particle.interpPosX = entityIn.lastTickPosX + (entityIn.posX - entityIn.lastTickPosX) * partialTicks;
    Particle.interpPosY = entityIn.lastTickPosY + (entityIn.posY - entityIn.lastTickPosY) * partialTicks;
    Particle.interpPosZ = entityIn.lastTickPosZ + (entityIn.posZ - entityIn.lastTickPosZ) * partialTicks;
    Particle.cameraViewDir = entityIn.getLook(partialTicks);
    GlStateManager.enableBlend();
    GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
    GlStateManager.alphaFunc(516, 0.003921569F);
    for (int i_nf = 0; i_nf < 3; i_nf++) {
      final int i = i_nf;
      for (int j = 0; j < 2; j++) {
        if (!this.fxLayers[i][j].isEmpty()) {
          switch (j) {
            case 0:
              GlStateManager.depthMask(false);
              break;
            case 1:
              GlStateManager.depthMask(true);
              break;
          } 
          switch (i) {
            default:
              this.renderer.bindTexture(PARTICLE_TEXTURES);
              break;
            case 1:
              this.renderer.bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
              break;
          } 
          GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
          Tessellator tessellator = Tessellator.getInstance();
          BufferBuilder bufferbuilder = tessellator.getBuffer();
          bufferbuilder.begin(7, DefaultVertexFormats.PARTICLE_POSITION_TEX_COLOR_LMAP);
          for (Particle particle : this.fxLayers[i][j]) {
            try {
              particle.renderParticle(bufferbuilder, entityIn, partialTicks, f, f4, f1, f2, f3);
            } catch (Throwable throwable) {
              CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Rendering Particle");
              CrashReportCategory crashreportcategory = crashreport.makeCategory("Particle being rendered");
              crashreportcategory.addDetail("Particle", new ICrashReportDetail<String>() {
                    public String call() throws Exception {
                      return particle.toString();
                    }
                  });
              crashreportcategory.addDetail("Particle Type", new ICrashReportDetail<String>() {
                    public String call() throws Exception {
                      if (i == 0)
                        return "MISC_TEXTURE"; 
                      if (i == 1)
                        return "TERRAIN_TEXTURE"; 
                      return (i == 3) ? "ENTITY_PARTICLE_TEXTURE" : ("Unknown - " + i);
                    }
                  });
              throw new ReportedException(crashreport);
            } 
          } 
          tessellator.draw();
        } 
      } 
    } 
    GlStateManager.depthMask(true);
    GlStateManager.disableBlend();
    GlStateManager.alphaFunc(516, 0.1F);
  }
  
  public void renderLitParticles(Entity entityIn, float partialTick) {
    float f = 0.017453292F;
    float f1 = MathHelper.cos(entityIn.rotationYaw * 0.017453292F);
    float f2 = MathHelper.sin(entityIn.rotationYaw * 0.017453292F);
    float f3 = -f2 * MathHelper.sin(entityIn.rotationPitch * 0.017453292F);
    float f4 = f1 * MathHelper.sin(entityIn.rotationPitch * 0.017453292F);
    float f5 = MathHelper.cos(entityIn.rotationPitch * 0.017453292F);
    for (int i = 0; i < 2; i++) {
      Queue<Particle> queue = this.fxLayers[3][i];
      if (!queue.isEmpty()) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        for (Particle particle : queue)
          particle.renderParticle(bufferbuilder, entityIn, partialTick, f1, f5, f2, f3, f4); 
      } 
    } 
  }
  
  public void clearEffects(@Nullable World worldIn) {
    this.world = worldIn;
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 2; j++)
        this.fxLayers[i][j].clear(); 
    } 
    this.particleEmitters.clear();
  }
  
  public void addBlockDestroyEffects(BlockPos pos, IBlockState state) {
    boolean notAir;
    if (Reflector.ForgeBlock_addDestroyEffects.exists() && Reflector.ForgeBlock_isAir.exists()) {
      Block block = state.getBlock();
      notAir = (!Reflector.callBoolean(block, Reflector.ForgeBlock_isAir, new Object[] { state, this.world, pos }) && !Reflector.callBoolean(block, Reflector.ForgeBlock_addDestroyEffects, new Object[] { this.world, pos, this }));
    } else {
      notAir = (state.getMaterial() != Material.AIR);
    } 
    if (notAir) {
      state = state.getActualState((IBlockAccess)this.world, pos);
      int i = 4;
      for (int j = 0; j < 4; j++) {
        for (int k = 0; k < 4; k++) {
          for (int l = 0; l < 4; l++) {
            double d0 = (j + 0.5D) / 4.0D;
            double d1 = (k + 0.5D) / 4.0D;
            double d2 = (l + 0.5D) / 4.0D;
            addEffect((Particle)(new ParticleDigging(this.world, pos.getX() + d0, pos.getY() + d1, pos.getZ() + d2, d0 - 0.5D, d1 - 0.5D, d2 - 0.5D, state)).setBlockPos(pos));
          } 
        } 
      } 
    } 
  }
  
  public void addBlockHitEffects(BlockPos pos, EnumFacing side) {
    IBlockState iblockstate = this.world.getBlockState(pos);
    if (iblockstate.getRenderType() != EnumBlockRenderType.INVISIBLE) {
      int i = pos.getX();
      int j = pos.getY();
      int k = pos.getZ();
      float f = 0.1F;
      AxisAlignedBB axisalignedbb = iblockstate.getBoundingBox((IBlockAccess)this.world, pos);
      double d0 = i + this.rand.nextDouble() * (axisalignedbb.maxX - axisalignedbb.minX - 0.20000000298023224D) + 0.10000000149011612D + axisalignedbb.minX;
      double d1 = j + this.rand.nextDouble() * (axisalignedbb.maxY - axisalignedbb.minY - 0.20000000298023224D) + 0.10000000149011612D + axisalignedbb.minY;
      double d2 = k + this.rand.nextDouble() * (axisalignedbb.maxZ - axisalignedbb.minZ - 0.20000000298023224D) + 0.10000000149011612D + axisalignedbb.minZ;
      if (side == EnumFacing.DOWN)
        d1 = j + axisalignedbb.minY - 0.10000000149011612D; 
      if (side == EnumFacing.UP)
        d1 = j + axisalignedbb.maxY + 0.10000000149011612D; 
      if (side == EnumFacing.NORTH)
        d2 = k + axisalignedbb.minZ - 0.10000000149011612D; 
      if (side == EnumFacing.SOUTH)
        d2 = k + axisalignedbb.maxZ + 0.10000000149011612D; 
      if (side == EnumFacing.WEST)
        d0 = i + axisalignedbb.minX - 0.10000000149011612D; 
      if (side == EnumFacing.EAST)
        d0 = i + axisalignedbb.maxX + 0.10000000149011612D; 
      addEffect((new ParticleDigging(this.world, d0, d1, d2, 0.0D, 0.0D, 0.0D, iblockstate)).setBlockPos(pos).multiplyVelocity(0.2F).multipleParticleScaleBy(0.6F));
    } 
  }
  
  public String getStatistics() {
    int i = 0;
    for (int j = 0; j < 4; j++) {
      for (int k = 0; k < 2; k++)
        i += this.fxLayers[j][k].size(); 
    } 
    return "" + i;
  }
  
  private boolean reuseBarrierParticle(Particle entityfx, ArrayDeque<Particle> deque) {
    for (Iterator<Particle> it = deque.iterator(); it.hasNext(); ) {
      Particle efx = it.next();
      if (efx instanceof Barrier)
        if (entityfx.prevPosX == efx.prevPosX && entityfx.prevPosY == efx.prevPosY && entityfx.prevPosZ == efx.prevPosZ) {
          efx.particleAge = 0;
          return true;
        }  
    } 
    return false;
  }
  
  public void addBlockHitEffects(BlockPos pos, RayTraceResult target) {
    IBlockState state = this.world.getBlockState(pos);
    if (state == null)
      return; 
    boolean blockAddHitEffects = Reflector.callBoolean(state.getBlock(), Reflector.ForgeBlock_addHitEffects, new Object[] { state, this.world, target, this });
    if (state != null && !blockAddHitEffects)
      addBlockHitEffects(pos, target.sideHit); 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\particle\ParticleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */