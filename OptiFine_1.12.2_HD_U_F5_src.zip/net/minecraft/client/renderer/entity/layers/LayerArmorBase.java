package net.minecraft.client.renderer.entity.layers;

import Config;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.optifine.CustomItems;
import net.optifine.reflect.Reflector;
import net.optifine.reflect.ReflectorForge;
import net.optifine.shaders.Shaders;
import net.optifine.shaders.ShadersRender;

public abstract class LayerArmorBase<T extends ModelBase> implements LayerRenderer<EntityLivingBase> {
  protected static final ResourceLocation ENCHANTED_ITEM_GLINT_RES = new ResourceLocation("textures/misc/enchanted_item_glint.png");
  
  protected T modelLeggings;
  
  protected T modelArmor;
  
  private final RenderLivingBase<?> renderer;
  
  private float alpha = 1.0F;
  
  private float colorR = 1.0F;
  
  private float colorG = 1.0F;
  
  private float colorB = 1.0F;
  
  private boolean skipRenderGlint;
  
  private static final Map<String, ResourceLocation> ARMOR_TEXTURE_RES_MAP = Maps.newHashMap();
  
  public LayerArmorBase(RenderLivingBase<?> rendererIn) {
    this.renderer = rendererIn;
    initArmor();
  }
  
  public void doRenderLayer(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
    renderArmorLayer(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale, EntityEquipmentSlot.CHEST);
    renderArmorLayer(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale, EntityEquipmentSlot.LEGS);
    renderArmorLayer(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale, EntityEquipmentSlot.FEET);
    renderArmorLayer(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale, EntityEquipmentSlot.HEAD);
  }
  
  public boolean shouldCombineTextures() {
    return false;
  }
  
  private void renderArmorLayer(EntityLivingBase entityLivingBaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale, EntityEquipmentSlot slotIn) {
    ItemStack itemstack = entityLivingBaseIn.getItemStackFromSlot(slotIn);
    if (itemstack.getItem() instanceof ItemArmor) {
      ItemArmor itemarmor = (ItemArmor)itemstack.getItem();
      if (itemarmor.getEquipmentSlot() == slotIn) {
        int i;
        float f, f1, f2;
        T t = getModelFromSlot(slotIn);
        if (Reflector.ForgeHooksClient.exists())
          t = getArmorModelHook(entityLivingBaseIn, itemstack, slotIn, t); 
        t.setModelAttributes(this.renderer.getMainModel());
        t.setLivingAnimations(entityLivingBaseIn, limbSwing, limbSwingAmount, partialTicks);
        setModelSlotVisible(t, slotIn);
        boolean flag = isLegSlot(slotIn);
        if (!Config.isCustomItems() || !CustomItems.bindCustomArmorTexture(itemstack, slotIn, null))
          if (Reflector.ForgeHooksClient_getArmorTexture.exists()) {
            this.renderer.bindTexture(getArmorResource((Entity)entityLivingBaseIn, itemstack, slotIn, null));
          } else {
            this.renderer.bindTexture(getArmorResource(itemarmor, flag));
          }  
        if (Reflector.ForgeHooksClient_getArmorTexture.exists()) {
          if (ReflectorForge.armorHasOverlay(itemarmor, itemstack)) {
            int j = itemarmor.getColor(itemstack);
            float f3 = (j >> 16 & 0xFF) / 255.0F;
            float f4 = (j >> 8 & 0xFF) / 255.0F;
            float f5 = (j & 0xFF) / 255.0F;
            GlStateManager.color(this.colorR * f3, this.colorG * f4, this.colorB * f5, this.alpha);
            t.render((Entity)entityLivingBaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            if (!Config.isCustomItems() || !CustomItems.bindCustomArmorTexture(itemstack, slotIn, "overlay"))
              this.renderer.bindTexture(getArmorResource((Entity)entityLivingBaseIn, itemstack, slotIn, "overlay")); 
          } 
          GlStateManager.color(this.colorR, this.colorG, this.colorB, this.alpha);
          t.render((Entity)entityLivingBaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
          if (!this.skipRenderGlint && itemstack.hasEffect())
            if (!Config.isCustomItems() || !CustomItems.renderCustomArmorEffect(entityLivingBaseIn, itemstack, (ModelBase)t, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale)) {
              this;
              renderEnchantedGlint(this.renderer, entityLivingBaseIn, (ModelBase)t, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale);
            }  
          return;
        } 
        switch (itemarmor.getArmorMaterial()) {
          case LEATHER:
            i = itemarmor.getColor(itemstack);
            f = (i >> 16 & 0xFF) / 255.0F;
            f1 = (i >> 8 & 0xFF) / 255.0F;
            f2 = (i & 0xFF) / 255.0F;
            GlStateManager.color(this.colorR * f, this.colorG * f1, this.colorB * f2, this.alpha);
            t.render((Entity)entityLivingBaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            if (!Config.isCustomItems() || !CustomItems.bindCustomArmorTexture(itemstack, slotIn, "overlay"))
              this.renderer.bindTexture(getArmorResource(itemarmor, flag, "overlay")); 
          case CHAIN:
          case IRON:
          case GOLD:
          case DIAMOND:
            GlStateManager.color(this.colorR, this.colorG, this.colorB, this.alpha);
            t.render((Entity)entityLivingBaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            break;
        } 
        if (!this.skipRenderGlint && itemstack.isItemEnchanted())
          if (!Config.isCustomItems() || !CustomItems.renderCustomArmorEffect(entityLivingBaseIn, itemstack, (ModelBase)t, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale))
            renderEnchantedGlint(this.renderer, entityLivingBaseIn, (ModelBase)t, limbSwing, limbSwingAmount, partialTicks, ageInTicks, netHeadYaw, headPitch, scale);  
      } 
    } 
  }
  
  public T getModelFromSlot(EntityEquipmentSlot slotIn) {
    return isLegSlot(slotIn) ? this.modelLeggings : this.modelArmor;
  }
  
  private boolean isLegSlot(EntityEquipmentSlot slotIn) {
    return (slotIn == EntityEquipmentSlot.LEGS);
  }
  
  public static void renderEnchantedGlint(RenderLivingBase<?> p_188364_0_, EntityLivingBase p_188364_1_, ModelBase model, float p_188364_3_, float p_188364_4_, float p_188364_5_, float p_188364_6_, float p_188364_7_, float p_188364_8_, float p_188364_9_) {
    if (Config.isShaders())
      if (Shaders.isShadowPass)
        return;  
    float f = p_188364_1_.ticksExisted + p_188364_5_;
    p_188364_0_.bindTexture(ENCHANTED_ITEM_GLINT_RES);
    if (Config.isShaders())
      ShadersRender.renderEnchantedGlintBegin(); 
    (Minecraft.getMinecraft()).entityRenderer.setupFogColor(true);
    GlStateManager.enableBlend();
    GlStateManager.depthFunc(514);
    GlStateManager.depthMask(false);
    float f1 = 0.5F;
    GlStateManager.color(0.5F, 0.5F, 0.5F, 1.0F);
    for (int i = 0; i < 2; i++) {
      GlStateManager.disableLighting();
      GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_COLOR, GlStateManager.DestFactor.ONE);
      float f2 = 0.76F;
      GlStateManager.color(0.38F, 0.19F, 0.608F, 1.0F);
      GlStateManager.matrixMode(5890);
      GlStateManager.loadIdentity();
      float f3 = 0.33333334F;
      GlStateManager.scale(0.33333334F, 0.33333334F, 0.33333334F);
      GlStateManager.rotate(30.0F - i * 60.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.translate(0.0F, f * (0.001F + i * 0.003F) * 20.0F, 0.0F);
      GlStateManager.matrixMode(5888);
      model.render((Entity)p_188364_1_, p_188364_3_, p_188364_4_, p_188364_6_, p_188364_7_, p_188364_8_, p_188364_9_);
      GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
    } 
    GlStateManager.matrixMode(5890);
    GlStateManager.loadIdentity();
    GlStateManager.matrixMode(5888);
    GlStateManager.enableLighting();
    GlStateManager.depthMask(true);
    GlStateManager.depthFunc(515);
    GlStateManager.disableBlend();
    (Minecraft.getMinecraft()).entityRenderer.setupFogColor(false);
    if (Config.isShaders())
      ShadersRender.renderEnchantedGlintEnd(); 
  }
  
  private ResourceLocation getArmorResource(ItemArmor armor, boolean p_177181_2_) {
    return getArmorResource(armor, p_177181_2_, (String)null);
  }
  
  private ResourceLocation getArmorResource(ItemArmor armor, boolean p_177178_2_, String p_177178_3_) {
    String s = String.format("textures/models/armor/%s_layer_%d%s.png", new Object[] { armor.getArmorMaterial().getName(), Integer.valueOf(p_177178_2_ ? 2 : 1), (p_177178_3_ == null) ? "" : String.format("_%s", new Object[] { p_177178_3_ }) });
    ResourceLocation resourcelocation = ARMOR_TEXTURE_RES_MAP.get(s);
    if (resourcelocation == null) {
      resourcelocation = new ResourceLocation(s);
      ARMOR_TEXTURE_RES_MAP.put(s, resourcelocation);
    } 
    return resourcelocation;
  }
  
  protected abstract void initArmor();
  
  protected abstract void setModelSlotVisible(T paramT, EntityEquipmentSlot paramEntityEquipmentSlot);
  
  protected T getArmorModelHook(EntityLivingBase entity, ItemStack itemStack, EntityEquipmentSlot slot, T model) {
    return model;
  }
  
  public ResourceLocation getArmorResource(Entity entity, ItemStack stack, EntityEquipmentSlot slot, String type) {
    ItemArmor item = (ItemArmor)stack.getItem();
    String texture = item.getArmorMaterial().getName();
    String domain = "minecraft";
    int idx = texture.indexOf(':');
    if (idx != -1) {
      domain = texture.substring(0, idx);
      texture = texture.substring(idx + 1);
    } 
    String s1 = String.format("%s:textures/models/armor/%s_layer_%d%s.png", new Object[] { domain, texture, Integer.valueOf(isLegSlot(slot) ? 2 : 1), (type == null) ? "" : String.format("_%s", new Object[] { type }) });
    s1 = Reflector.callString(Reflector.ForgeHooksClient_getArmorTexture, new Object[] { entity, stack, s1, slot, type });
    ResourceLocation resourcelocation = ARMOR_TEXTURE_RES_MAP.get(s1);
    if (resourcelocation == null) {
      resourcelocation = new ResourceLocation(s1);
      ARMOR_TEXTURE_RES_MAP.put(s1, resourcelocation);
    } 
    return resourcelocation;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\entity\layers\LayerArmorBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */