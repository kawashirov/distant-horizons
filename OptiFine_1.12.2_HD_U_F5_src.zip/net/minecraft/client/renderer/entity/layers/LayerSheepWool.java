package net.minecraft.client.renderer.entity.layers;

import Config;
import net.minecraft.client.model.ModelSheep1;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderSheep;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.ResourceLocation;
import net.optifine.CustomColors;

public class LayerSheepWool implements LayerRenderer<EntitySheep> {
  private static final ResourceLocation TEXTURE = new ResourceLocation("textures/entity/sheep/sheep_fur.png");
  
  private final RenderSheep sheepRenderer;
  
  public ModelSheep1 sheepModel = new ModelSheep1();
  
  public LayerSheepWool(RenderSheep sheepRendererIn) {
    this.sheepRenderer = sheepRendererIn;
  }
  
  public void doRenderLayer(EntitySheep entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale) {
    if (!entitylivingbaseIn.getSheared() && !entitylivingbaseIn.isInvisible()) {
      this.sheepRenderer.bindTexture(TEXTURE);
      if (entitylivingbaseIn.hasCustomName() && "jeb_".equals(entitylivingbaseIn.getCustomNameTag())) {
        int i1 = 25;
        int i = entitylivingbaseIn.ticksExisted / 25 + entitylivingbaseIn.getEntityId();
        int j = (EnumDyeColor.values()).length;
        int k = i % j;
        int l = (i + 1) % j;
        float f = ((entitylivingbaseIn.ticksExisted % 25) + partialTicks) / 25.0F;
        float[] afloat1 = EntitySheep.getDyeRgb(EnumDyeColor.byMetadata(k));
        float[] afloat2 = EntitySheep.getDyeRgb(EnumDyeColor.byMetadata(l));
        if (Config.isCustomColors()) {
          afloat1 = CustomColors.getSheepColors(EnumDyeColor.byMetadata(k), afloat1);
          afloat2 = CustomColors.getSheepColors(EnumDyeColor.byMetadata(l), afloat2);
        } 
        GlStateManager.color(afloat1[0] * (1.0F - f) + afloat2[0] * f, afloat1[1] * (1.0F - f) + afloat2[1] * f, afloat1[2] * (1.0F - f) + afloat2[2] * f);
      } else {
        float[] afloat = EntitySheep.getDyeRgb(entitylivingbaseIn.getFleeceColor());
        if (Config.isCustomColors())
          afloat = CustomColors.getSheepColors(entitylivingbaseIn.getFleeceColor(), afloat); 
        GlStateManager.color(afloat[0], afloat[1], afloat[2]);
      } 
      this.sheepModel.setModelAttributes(this.sheepRenderer.getMainModel());
      this.sheepModel.setLivingAnimations((EntityLivingBase)entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks);
      this.sheepModel.render((Entity)entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
    } 
  }
  
  public boolean shouldCombineTextures() {
    return true;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\entity\layers\LayerSheepWool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */