package net.minecraft.client.renderer.vertex;

import java.nio.ByteBuffer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.optifine.render.VboRange;
import net.optifine.render.VboRegion;

public class VertexBuffer {
  private int glBufferId;
  
  private final VertexFormat vertexFormat;
  
  private int count;
  
  private VboRegion vboRegion;
  
  private VboRange vboRange;
  
  private int drawMode;
  
  public VertexBuffer(VertexFormat vertexFormatIn) {
    this.vertexFormat = vertexFormatIn;
    this.glBufferId = OpenGlHelper.glGenBuffers();
  }
  
  public void bindBuffer() {
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, this.glBufferId);
  }
  
  public void bufferData(ByteBuffer data) {
    if (this.vboRegion != null) {
      this.vboRegion.bufferData(data, this.vboRange);
      return;
    } 
    bindBuffer();
    OpenGlHelper.glBufferData(OpenGlHelper.GL_ARRAY_BUFFER, data, 35044);
    unbindBuffer();
    this.count = data.limit() / this.vertexFormat.getNextOffset();
  }
  
  public void drawArrays(int mode) {
    if (this.drawMode > 0)
      mode = this.drawMode; 
    if (this.vboRegion != null) {
      this.vboRegion.drawArrays(mode, this.vboRange);
    } else {
      GlStateManager.glDrawArrays(mode, 0, this.count);
    } 
  }
  
  public void unbindBuffer() {
    OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, 0);
  }
  
  public void deleteGlBuffers() {
    if (this.glBufferId >= 0) {
      OpenGlHelper.glDeleteBuffers(this.glBufferId);
      this.glBufferId = -1;
    } 
  }
  
  public void setVboRegion(VboRegion vboRegion) {
    if (vboRegion == null)
      return; 
    deleteGlBuffers();
    this.vboRegion = vboRegion;
    this.vboRange = new VboRange();
  }
  
  public VboRegion getVboRegion() {
    return this.vboRegion;
  }
  
  public VboRange getVboRange() {
    return this.vboRange;
  }
  
  public int getDrawMode() {
    return this.drawMode;
  }
  
  public void setDrawMode(int drawMode) {
    this.drawMode = drawMode;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\vertex\VertexBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */