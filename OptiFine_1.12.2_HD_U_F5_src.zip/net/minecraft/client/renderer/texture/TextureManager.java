package net.minecraft.client.renderer.texture;

import Config;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.optifine.CustomGuis;
import net.optifine.EmissiveTextures;
import net.optifine.RandomEntities;
import net.optifine.shaders.ShadersTex;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TextureManager implements ITickable, IResourceManagerReloadListener {
  private static final Logger LOGGER = LogManager.getLogger();
  
  public static final ResourceLocation RESOURCE_LOCATION_EMPTY = new ResourceLocation("");
  
  private final Map<ResourceLocation, ITextureObject> mapTextureObjects = Maps.newHashMap();
  
  private final List<ITickable> listTickables = Lists.newArrayList();
  
  private final Map<String, Integer> mapTextureCounters = Maps.newHashMap();
  
  private final IResourceManager resourceManager;
  
  public TextureManager(IResourceManager resourceManager) {
    this.resourceManager = resourceManager;
  }
  
  public void bindTexture(ResourceLocation resource) {
    if (Config.isRandomEntities())
      resource = RandomEntities.getTextureLocation(resource); 
    if (Config.isCustomGuis())
      resource = CustomGuis.getTextureLocation(resource); 
    ITextureObject itextureobject = this.mapTextureObjects.get(resource);
    if (EmissiveTextures.isActive())
      itextureobject = EmissiveTextures.getEmissiveTexture(itextureobject, this.mapTextureObjects); 
    if (itextureobject == null) {
      itextureobject = new SimpleTexture(resource);
      loadTexture(resource, itextureobject);
    } 
    if (Config.isShaders()) {
      ShadersTex.bindTexture(itextureobject);
    } else {
      TextureUtil.bindTexture(itextureobject.getGlTextureId());
    } 
  }
  
  public boolean loadTickableTexture(ResourceLocation textureLocation, ITickableTextureObject textureObj) {
    if (loadTexture(textureLocation, (ITextureObject)textureObj)) {
      this.listTickables.add(textureObj);
      return true;
    } 
    return false;
  }
  
  public boolean loadTexture(ResourceLocation textureLocation, ITextureObject textureObj) {
    boolean flag = true;
    try {
      textureObj.loadTexture(this.resourceManager);
    } catch (IOException ioexception) {
      if (textureLocation != RESOURCE_LOCATION_EMPTY)
        LOGGER.warn("Failed to load texture: {}", textureLocation, ioexception); 
      textureObj = TextureUtil.MISSING_TEXTURE;
      this.mapTextureObjects.put(textureLocation, textureObj);
      flag = false;
    } catch (Throwable throwable) {
      final ITextureObject textureObjf = textureObj;
      CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Registering texture");
      CrashReportCategory crashreportcategory = crashreport.makeCategory("Resource location being registered");
      crashreportcategory.addCrashSection("Resource location", textureLocation);
      crashreportcategory.addDetail("Texture object class", new ICrashReportDetail<String>() {
            public String call() throws Exception {
              return textureObjf.getClass().getName();
            }
          });
      throw new ReportedException(crashreport);
    } 
    this.mapTextureObjects.put(textureLocation, textureObj);
    return flag;
  }
  
  public ITextureObject getTexture(ResourceLocation textureLocation) {
    return this.mapTextureObjects.get(textureLocation);
  }
  
  public ResourceLocation getDynamicTextureLocation(String name, DynamicTexture texture) {
    if (name.equals("logo"))
      texture = Config.getMojangLogoTexture(texture); 
    Integer integer = this.mapTextureCounters.get(name);
    if (integer == null) {
      integer = Integer.valueOf(1);
    } else {
      integer = Integer.valueOf(integer.intValue() + 1);
    } 
    this.mapTextureCounters.put(name, integer);
    ResourceLocation resourcelocation = new ResourceLocation(String.format("dynamic/%s_%d", new Object[] { name, integer }));
    loadTexture(resourcelocation, texture);
    return resourcelocation;
  }
  
  public void tick() {
    for (ITickable itickable : this.listTickables)
      itickable.tick(); 
  }
  
  public void deleteTexture(ResourceLocation textureLocation) {
    ITextureObject itextureobject = getTexture(textureLocation);
    if (itextureobject != null) {
      this.mapTextureObjects.remove(textureLocation);
      TextureUtil.deleteTexture(itextureobject.getGlTextureId());
    } 
  }
  
  public void onResourceManagerReload(IResourceManager resourceManager) {
    Config.dbg("*** Reloading textures ***");
    Config.log("Resource packs: " + Config.getResourcePackNames());
    Iterator<ResourceLocation> it = this.mapTextureObjects.keySet().iterator();
    while (it.hasNext()) {
      ResourceLocation loc = it.next();
      String path = loc.getResourcePath();
      if (path.startsWith("mcpatcher/") || path.startsWith("optifine/") || EmissiveTextures.isEmissive(loc)) {
        ITextureObject tex = this.mapTextureObjects.get(loc);
        if (tex instanceof AbstractTexture) {
          AbstractTexture at = (AbstractTexture)tex;
          at.deleteGlTexture();
        } 
        it.remove();
      } 
    } 
    EmissiveTextures.update();
    Set<Map.Entry<ResourceLocation, ITextureObject>> entries = new HashSet<>(this.mapTextureObjects.entrySet());
    Iterator<Map.Entry<ResourceLocation, ITextureObject>> iterator = entries.iterator();
    while (iterator.hasNext()) {
      Map.Entry<ResourceLocation, ITextureObject> entry = iterator.next();
      ITextureObject itextureobject = entry.getValue();
      if (itextureobject == TextureUtil.MISSING_TEXTURE) {
        iterator.remove();
        continue;
      } 
      loadTexture(entry.getKey(), itextureobject);
    } 
  }
  
  public void reloadBannerTextures() {
    Set<Map.Entry<ResourceLocation, ITextureObject>> entries = new HashSet<>(this.mapTextureObjects.entrySet());
    for (Map.Entry<ResourceLocation, ITextureObject> entry : entries) {
      ResourceLocation loc = entry.getKey();
      ITextureObject tex = entry.getValue();
      if (tex instanceof LayeredColorMaskTexture)
        loadTexture(loc, tex); 
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\texture\TextureManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */