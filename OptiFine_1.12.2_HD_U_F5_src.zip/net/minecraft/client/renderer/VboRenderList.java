package net.minecraft.client.renderer;

import Config;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.util.BlockRenderLayer;
import net.optifine.render.VboRegion;
import net.optifine.shaders.ShadersRender;

public class VboRenderList extends ChunkRenderContainer {
  private double viewEntityX;
  
  private double viewEntityY;
  
  private double viewEntityZ;
  
  public void renderChunkLayer(BlockRenderLayer layer) {
    if (this.initialized) {
      if (Config.isRenderRegions()) {
        int regionX = Integer.MIN_VALUE;
        int regionZ = Integer.MIN_VALUE;
        VboRegion lastVboRegion = null;
        for (RenderChunk renderchunk : this.renderChunks) {
          VertexBuffer vertexbuffer = renderchunk.getVertexBufferByLayer(layer.ordinal());
          VboRegion vboRegion = vertexbuffer.getVboRegion();
          if (vboRegion != lastVboRegion || regionX != renderchunk.regionX || regionZ != renderchunk.regionZ) {
            if (lastVboRegion != null)
              drawRegion(regionX, regionZ, lastVboRegion); 
            regionX = renderchunk.regionX;
            regionZ = renderchunk.regionZ;
            lastVboRegion = vboRegion;
          } 
          vertexbuffer.drawArrays(7);
        } 
        if (lastVboRegion != null)
          drawRegion(regionX, regionZ, lastVboRegion); 
      } else {
        for (RenderChunk renderchunk : this.renderChunks) {
          VertexBuffer vertexbuffer = renderchunk.getVertexBufferByLayer(layer.ordinal());
          GlStateManager.pushMatrix();
          preRenderChunk(renderchunk);
          renderchunk.multModelviewMatrix();
          vertexbuffer.bindBuffer();
          setupArrayPointers();
          vertexbuffer.drawArrays(7);
          GlStateManager.popMatrix();
        } 
      } 
      OpenGlHelper.glBindBuffer(OpenGlHelper.GL_ARRAY_BUFFER, 0);
      GlStateManager.resetColor();
      this.renderChunks.clear();
    } 
  }
  
  public void setupArrayPointers() {
    if (Config.isShaders()) {
      ShadersRender.setupArrayPointersVbo();
      return;
    } 
    GlStateManager.glVertexPointer(3, 5126, 28, 0);
    GlStateManager.glColorPointer(4, 5121, 28, 12);
    GlStateManager.glTexCoordPointer(2, 5126, 28, 16);
    OpenGlHelper.setClientActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.glTexCoordPointer(2, 5122, 28, 24);
    OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  public void initialize(double viewEntityXIn, double viewEntityYIn, double viewEntityZIn) {
    this.viewEntityX = viewEntityXIn;
    this.viewEntityY = viewEntityYIn;
    this.viewEntityZ = viewEntityZIn;
    super.initialize(viewEntityXIn, viewEntityYIn, viewEntityZIn);
  }
  
  private void drawRegion(int regionX, int regionZ, VboRegion vboRegion) {
    GlStateManager.pushMatrix();
    preRenderRegion(regionX, 0, regionZ);
    vboRegion.finishDraw(this);
    GlStateManager.popMatrix();
  }
  
  public void preRenderRegion(int x, int y, int z) {
    GlStateManager.translate((float)(x - this.viewEntityX), (float)(y - this.viewEntityY), (float)(z - this.viewEntityZ));
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\VboRenderList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */