package net.minecraft.client.renderer.block.model;

import java.util.Arrays;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

public class BakedQuadRetextured extends BakedQuad {
  private final TextureAtlasSprite texture;
  
  private final TextureAtlasSprite spriteOld;
  
  public BakedQuadRetextured(BakedQuad quad, TextureAtlasSprite textureIn) {
    super(Arrays.copyOf(quad.getVertexData(), (quad.getVertexData()).length), quad.tintIndex, FaceBakery.getFacingFromVertexData(quad.getVertexData()), textureIn, quad.applyDiffuseLighting, quad.format);
    this.texture = textureIn;
    this.format = quad.format;
    this.applyDiffuseLighting = quad.applyDiffuseLighting;
    this.spriteOld = quad.getSprite();
    remapQuad();
    fixVertexData();
  }
  
  private void remapQuad() {
    for (int i = 0; i < 4; i++) {
      int j = this.format.getIntegerSize() * i;
      int uvIndex = this.format.getUvOffsetById(0) / 4;
      this.vertexData[j + uvIndex] = Float.floatToRawIntBits(this.texture.getInterpolatedU(this.spriteOld.getUnInterpolatedU(Float.intBitsToFloat(this.vertexData[j + uvIndex]))));
      this.vertexData[j + uvIndex + 1] = Float.floatToRawIntBits(this.texture.getInterpolatedV(this.spriteOld.getUnInterpolatedV(Float.intBitsToFloat(this.vertexData[j + uvIndex + 1]))));
    } 
  }
  
  public TextureAtlasSprite getSprite() {
    return this.texture;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\block\model\BakedQuadRetextured.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */