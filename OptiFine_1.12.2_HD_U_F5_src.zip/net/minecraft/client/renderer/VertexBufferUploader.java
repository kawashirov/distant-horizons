package net.minecraft.client.renderer;

import Config;
import net.minecraft.client.renderer.vertex.VertexBuffer;

public class VertexBufferUploader extends WorldVertexBufferUploader {
  private VertexBuffer vertexBuffer;
  
  public void draw(BufferBuilder vertexBufferIn) {
    if (vertexBufferIn.getDrawMode() == 7 && Config.isQuadsToTriangles()) {
      vertexBufferIn.quadsToTriangles();
      this.vertexBuffer.setDrawMode(vertexBufferIn.getDrawMode());
    } 
    this.vertexBuffer.bufferData(vertexBufferIn.getByteBuffer());
    vertexBufferIn.reset();
  }
  
  public void setVertexBuffer(VertexBuffer vertexBufferIn) {
    this.vertexBuffer = vertexBufferIn;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\renderer\VertexBufferUploader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */