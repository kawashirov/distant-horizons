package net.minecraft.client.gui;

import net.minecraft.client.resources.I18n;
import net.optifine.CustomLoadingScreen;
import net.optifine.CustomLoadingScreens;

public class GuiDownloadTerrain extends GuiScreen {
  private CustomLoadingScreen customLoadingScreen = CustomLoadingScreens.getCustomLoadingScreen();
  
  public void initGui() {
    this.buttonList.clear();
  }
  
  public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    if (this.customLoadingScreen != null) {
      this.customLoadingScreen.drawBackground(this.width, this.height);
    } else {
      drawBackground(0);
    } 
    drawCenteredString(this.fontRenderer, I18n.format("multiplayer.downloadingTerrain", new Object[0]), this.width / 2, this.height / 2 - 50, 16777215);
    super.drawScreen(mouseX, mouseY, partialTicks);
  }
  
  public boolean doesGuiPauseGame() {
    return false;
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\client\gui\GuiDownloadTerrain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */