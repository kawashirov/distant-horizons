package net.minecraft.network;

import Config;
import net.minecraft.network.play.server.SPacketJoinGame;
import net.minecraft.network.play.server.SPacketRespawn;
import net.minecraft.util.IThreadListener;

public class PacketThreadUtil {
  public static <T extends INetHandler> void checkThreadAndEnqueue(final Packet<T> packetIn, final T processor, IThreadListener scheduler) throws ThreadQuickExitException {
    if (!scheduler.isCallingFromMinecraftThread()) {
      scheduler.addScheduledTask(new Runnable() {
            public void run() {
              PacketThreadUtil.clientPreProcessPacket(packetIn);
              packetIn.processPacket(processor);
            }
          });
      throw ThreadQuickExitException.INSTANCE;
    } 
    clientPreProcessPacket(packetIn);
  }
  
  public static int lastDimensionId = Integer.MIN_VALUE;
  
  protected static void clientPreProcessPacket(Packet packetIn) {
    if (packetIn instanceof net.minecraft.network.play.server.SPacketPlayerPosLook)
      Config.getRenderGlobal().onPlayerPositionSet(); 
    if (packetIn instanceof SPacketRespawn) {
      SPacketRespawn respawn = (SPacketRespawn)packetIn;
      lastDimensionId = respawn.getDimensionID();
    } else if (packetIn instanceof SPacketJoinGame) {
      SPacketJoinGame joinGame = (SPacketJoinGame)packetIn;
      lastDimensionId = joinGame.getDimension();
    } else {
      lastDimensionId = Integer.MIN_VALUE;
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\network\PacketThreadUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */