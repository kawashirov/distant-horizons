package net.minecraft.util;

public class IntegerCache {
  private static final Integer[] CACHE = new Integer[65535];
  
  public static Integer getInteger(int value) {
    if (value >= 0 && value < CACHE.length)
      return CACHE[value]; 
    return new Integer(value);
  }
  
  static {
    int i = 0;
    for (int j = CACHE.length; i < j; i++)
      CACHE[i] = Integer.valueOf(i); 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraf\\util\IntegerCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */