package net.minecraft.server.integrated;

import Config;
import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Futures;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Iterator;
import java.util.concurrent.Future;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ThreadLanServerPing;
import net.minecraft.command.ServerCommandManager;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketThreadUtil;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.profiler.Snooper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.management.PlayerList;
import net.minecraft.server.management.PlayerProfileCache;
import net.minecraft.util.CryptManager;
import net.minecraft.util.HttpUtil;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameType;
import net.minecraft.world.IWorldEventListener;
import net.minecraft.world.ServerWorldEventHandler;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.WorldServerDemo;
import net.minecraft.world.WorldServerMulti;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldType;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.WorldInfo;
import net.optifine.ClearWater;
import net.optifine.reflect.Reflector;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class IntegratedServer extends MinecraftServer {
  private static final Logger LOGGER = LogManager.getLogger();
  
  private final Minecraft mc;
  
  private final WorldSettings worldSettings;
  
  private boolean isGamePaused;
  
  private boolean isPublic;
  
  private ThreadLanServerPing lanServerPing;
  
  private long ticksSaveLast = 0L;
  
  public World difficultyUpdateWorld = null;
  
  public BlockPos difficultyUpdatePos = null;
  
  public DifficultyInstance difficultyLast = null;
  
  public IntegratedServer(Minecraft clientIn, String folderNameIn, String worldNameIn, WorldSettings worldSettingsIn, YggdrasilAuthenticationService authServiceIn, MinecraftSessionService sessionServiceIn, GameProfileRepository profileRepoIn, PlayerProfileCache profileCacheIn) {
    super(new File(clientIn.mcDataDir, "saves"), clientIn.getProxy(), clientIn.getDataFixer(), authServiceIn, sessionServiceIn, profileRepoIn, profileCacheIn);
    setServerOwner(clientIn.getSession().getUsername());
    setFolderName(folderNameIn);
    setWorldName(worldNameIn);
    setDemo(clientIn.isDemo());
    canCreateBonusChest(worldSettingsIn.isBonusChestEnabled());
    setBuildLimit(256);
    setPlayerList((PlayerList)new IntegratedPlayerList(this));
    this.mc = clientIn;
    this.worldSettings = isDemo() ? WorldServerDemo.DEMO_WORLD_SETTINGS : worldSettingsIn;
    ISaveHandler isavehandler = getActiveAnvilConverter().getSaveLoader(folderNameIn, false);
    WorldInfo worldinfo = isavehandler.loadWorldInfo();
    if (worldinfo != null) {
      NBTTagCompound nbt = worldinfo.getPlayerNBTTagCompound();
      if (nbt != null && nbt.hasKey("Dimension")) {
        int dim = nbt.getInteger("Dimension");
        PacketThreadUtil.lastDimensionId = dim;
        this.mc.loadingScreen.setLoadingProgress(-1);
      } 
    } 
  }
  
  public ServerCommandManager createCommandManager() {
    return (ServerCommandManager)new IntegratedServerCommandManager(this);
  }
  
  public void loadAllWorlds(String saveName, String worldNameIn, long seed, WorldType type, String generatorOptions) {
    convertMapIfNeeded(saveName);
    boolean forge = Reflector.DimensionManager.exists();
    if (!forge) {
      this.worlds = new WorldServer[3];
      this.timeOfLastDimensionTick = new long[this.worlds.length][100];
    } 
    ISaveHandler isavehandler = getActiveAnvilConverter().getSaveLoader(saveName, true);
    setResourcePackFromWorld(getFolderName(), isavehandler);
    WorldInfo worldinfo = isavehandler.loadWorldInfo();
    if (worldinfo == null) {
      worldinfo = new WorldInfo(this.worldSettings, worldNameIn);
    } else {
      worldinfo.setWorldName(worldNameIn);
    } 
    if (forge) {
      WorldServer overWorld = isDemo() ? (WorldServer)(new WorldServerDemo(this, isavehandler, worldinfo, 0, this.profiler)).init() : (WorldServer)(new WorldServer(this, isavehandler, worldinfo, 0, this.profiler)).init();
      overWorld.initialize(this.worldSettings);
      Integer[] dimIds = (Integer[])Reflector.call(Reflector.DimensionManager_getStaticDimensionIDs, new Object[0]);
      Integer[] arrayOfInteger1;
      int i;
      byte b;
      for (arrayOfInteger1 = dimIds, i = arrayOfInteger1.length, b = 0; b < i; ) {
        int dim = arrayOfInteger1[b].intValue();
        WorldServer world = (dim == 0) ? overWorld : (WorldServer)(new WorldServerMulti(this, isavehandler, dim, overWorld, this.profiler)).init();
        world.addEventListener((IWorldEventListener)new ServerWorldEventHandler(this, world));
        if (!isSinglePlayer())
          world.getWorldInfo().setGameType(getGameType()); 
        if (Reflector.EventBus.exists())
          Reflector.postForgeBusEvent(Reflector.WorldEvent_Load_Constructor, new Object[] { world }); 
        b++;
      } 
      getPlayerList().setPlayerManager(new WorldServer[] { overWorld });
      if (overWorld.getWorldInfo().getDifficulty() == null)
        setDifficultyForAllWorlds(this.mc.gameSettings.difficulty); 
    } else {
      for (int i = 0; i < this.worlds.length; i++) {
        int j = 0;
        if (i == 1)
          j = -1; 
        if (i == 2)
          j = 1; 
        if (i == 0) {
          if (isDemo()) {
            this.worlds[i] = (WorldServer)(new WorldServerDemo(this, isavehandler, worldinfo, j, this.profiler)).init();
          } else {
            this.worlds[i] = (WorldServer)(new WorldServer(this, isavehandler, worldinfo, j, this.profiler)).init();
          } 
          this.worlds[i].initialize(this.worldSettings);
        } else {
          this.worlds[i] = (WorldServer)(new WorldServerMulti(this, isavehandler, j, this.worlds[0], this.profiler)).init();
        } 
        this.worlds[i].addEventListener((IWorldEventListener)new ServerWorldEventHandler(this, this.worlds[i]));
      } 
      getPlayerList().setPlayerManager(this.worlds);
      if (this.worlds[0].getWorldInfo().getDifficulty() == null)
        setDifficultyForAllWorlds(this.mc.gameSettings.difficulty); 
    } 
    initialWorldChunkLoad();
  }
  
  public boolean init() throws IOException {
    LOGGER.info("Starting integrated minecraft server version 1.12.2");
    setOnlineMode(true);
    setCanSpawnAnimals(true);
    setCanSpawnNPCs(true);
    setAllowPvp(true);
    setAllowFlight(true);
    LOGGER.info("Generating keypair");
    setKeyPair(CryptManager.generateKeyPair());
    if (Reflector.FMLCommonHandler_handleServerAboutToStart.exists()) {
      Object inst = Reflector.call(Reflector.FMLCommonHandler_instance, new Object[0]);
      if (!Reflector.callBoolean(inst, Reflector.FMLCommonHandler_handleServerAboutToStart, new Object[] { this }))
        return false; 
    } 
    loadAllWorlds(getFolderName(), getWorldName(), this.worldSettings.getSeed(), this.worldSettings.getTerrainType(), this.worldSettings.getGeneratorOptions());
    setMOTD(getServerOwner() + " - " + this.worlds[0].getWorldInfo().getWorldName());
    if (Reflector.FMLCommonHandler_handleServerStarting.exists()) {
      Object inst = Reflector.call(Reflector.FMLCommonHandler_instance, new Object[0]);
      if (Reflector.FMLCommonHandler_handleServerStarting.getReturnType() == boolean.class)
        return Reflector.callBoolean(inst, Reflector.FMLCommonHandler_handleServerStarting, new Object[] { this }); 
      Reflector.callVoid(inst, Reflector.FMLCommonHandler_handleServerStarting, new Object[] { this });
    } 
    return true;
  }
  
  public void tick() {
    onTick();
    boolean flag = this.isGamePaused;
    this.isGamePaused = (Minecraft.getMinecraft().getConnection() != null && Minecraft.getMinecraft().isGamePaused());
    if (!flag && this.isGamePaused) {
      LOGGER.info("Saving and pausing game...");
      getPlayerList().saveAllPlayerData();
      saveAllWorlds(false);
    } 
    if (this.isGamePaused) {
      synchronized (this.futureTaskQueue) {
        while (!this.futureTaskQueue.isEmpty())
          Util.runTask(this.futureTaskQueue.poll(), LOGGER); 
      } 
    } else {
      super.tick();
      if (this.mc.gameSettings.renderDistanceChunks != getPlayerList().getViewDistance()) {
        LOGGER.info("Changing view distance to {}, from {}", Integer.valueOf(this.mc.gameSettings.renderDistanceChunks), Integer.valueOf(getPlayerList().getViewDistance()));
        getPlayerList().setViewDistance(this.mc.gameSettings.renderDistanceChunks);
      } 
      if (this.mc.world != null) {
        WorldInfo worldinfo1 = this.worlds[0].getWorldInfo();
        WorldInfo worldinfo = this.mc.world.getWorldInfo();
        if (!worldinfo1.isDifficultyLocked() && worldinfo.getDifficulty() != worldinfo1.getDifficulty()) {
          LOGGER.info("Changing difficulty to {}, from {}", worldinfo.getDifficulty(), worldinfo1.getDifficulty());
          setDifficultyForAllWorlds(worldinfo.getDifficulty());
        } else if (worldinfo.isDifficultyLocked() && !worldinfo1.isDifficultyLocked()) {
          LOGGER.info("Locking difficulty to {}", worldinfo.getDifficulty());
          for (WorldServer worldserver : this.worlds) {
            if (worldserver != null)
              worldserver.getWorldInfo().setDifficultyLocked(true); 
          } 
        } 
      } 
    } 
  }
  
  public boolean canStructuresSpawn() {
    return false;
  }
  
  public GameType getGameType() {
    return this.worldSettings.getGameType();
  }
  
  public EnumDifficulty getDifficulty() {
    if (this.mc.world == null)
      return this.mc.gameSettings.difficulty; 
    return this.mc.world.getWorldInfo().getDifficulty();
  }
  
  public boolean isHardcore() {
    return this.worldSettings.getHardcoreEnabled();
  }
  
  public boolean shouldBroadcastRconToOps() {
    return true;
  }
  
  public boolean shouldBroadcastConsoleToOps() {
    return true;
  }
  
  public void saveAllWorlds(boolean isSilent) {
    if (isSilent) {
      int ticks = getTickCounter();
      int ticksSaveInterval = this.mc.gameSettings.ofAutoSaveTicks;
      if (ticks < this.ticksSaveLast + ticksSaveInterval)
        return; 
      this.ticksSaveLast = ticks;
    } 
    super.saveAllWorlds(isSilent);
  }
  
  public File getDataDirectory() {
    return this.mc.mcDataDir;
  }
  
  public boolean isDedicatedServer() {
    return false;
  }
  
  public boolean shouldUseNativeTransport() {
    return false;
  }
  
  public void finalTick(CrashReport report) {
    this.mc.crashed(report);
  }
  
  public CrashReport addServerInfoToCrashReport(CrashReport report) {
    report = super.addServerInfoToCrashReport(report);
    report.getCategory().addDetail("Type", new ICrashReportDetail<String>() {
          public String call() throws Exception {
            return "Integrated Server (map_client.txt)";
          }
        });
    report.getCategory().addDetail("Is Modded", new ICrashReportDetail<String>() {
          public String call() throws Exception {
            String s = ClientBrandRetriever.getClientModName();
            if (!s.equals("vanilla"))
              return "Definitely; Client brand changed to '" + s + "'"; 
            s = IntegratedServer.this.getServerModName();
            if (!"vanilla".equals(s))
              return "Definitely; Server brand changed to '" + s + "'"; 
            return (Minecraft.class.getSigners() == null) ? "Very likely; Jar signature invalidated" : "Probably not. Jar signature remains and both client + server brands are untouched.";
          }
        });
    return report;
  }
  
  public void setDifficultyForAllWorlds(EnumDifficulty difficulty) {
    super.setDifficultyForAllWorlds(difficulty);
    if (this.mc.world != null)
      this.mc.world.getWorldInfo().setDifficulty(difficulty); 
  }
  
  public void addServerStatsToSnooper(Snooper playerSnooper) {
    super.addServerStatsToSnooper(playerSnooper);
    playerSnooper.addClientStat("snooper_partner", this.mc.getPlayerUsageSnooper().getUniqueID());
  }
  
  public boolean isSnooperEnabled() {
    return Minecraft.getMinecraft().isSnooperEnabled();
  }
  
  public String shareToLAN(GameType type, boolean allowCheats) {
    try {
      int i = -1;
      try {
        i = HttpUtil.getSuitableLanPort();
      } catch (IOException iOException) {}
      if (i <= 0)
        i = 25564; 
      getNetworkSystem().addLanEndpoint((InetAddress)null, i);
      LOGGER.info("Started on {}", Integer.valueOf(i));
      this.isPublic = true;
      this.lanServerPing = new ThreadLanServerPing(getMOTD(), i + "");
      this.lanServerPing.start();
      getPlayerList().setGameType(type);
      getPlayerList().setCommandsAllowedForAll(allowCheats);
      this.mc.player.setPermissionLevel(allowCheats ? 4 : 0);
      return i + "";
    } catch (IOException var6) {
      return null;
    } 
  }
  
  public void stopServer() {
    super.stopServer();
    if (this.lanServerPing != null) {
      this.lanServerPing.interrupt();
      this.lanServerPing = null;
    } 
  }
  
  public void initiateShutdown() {
    if (!Reflector.MinecraftForge.exists() || isServerRunning())
      Futures.getUnchecked((Future)addScheduledTask(new Runnable() {
              public void run() {
                for (EntityPlayerMP entityplayermp : Lists.newArrayList(IntegratedServer.this.getPlayerList().getPlayers())) {
                  if (!entityplayermp.getUniqueID().equals(IntegratedServer.this.mc.player.getUniqueID()))
                    IntegratedServer.this.getPlayerList().playerLoggedOut(entityplayermp); 
                } 
              }
            })); 
    super.initiateShutdown();
    if (this.lanServerPing != null) {
      this.lanServerPing.interrupt();
      this.lanServerPing = null;
    } 
  }
  
  public boolean getPublic() {
    return this.isPublic;
  }
  
  public void setGameType(GameType gameMode) {
    super.setGameType(gameMode);
    getPlayerList().setGameType(gameMode);
  }
  
  public boolean isCommandBlockEnabled() {
    return true;
  }
  
  public int getOpPermissionLevel() {
    return 4;
  }
  
  private void onTick() {
    Iterable<WorldServer> iws = Arrays.asList(this.worlds);
    for (Iterator<WorldServer> it = iws.iterator(); it.hasNext(); ) {
      WorldServer ws = it.next();
      onTick(ws);
    } 
  }
  
  public DifficultyInstance getDifficultyAsync(World world, BlockPos blockPos) {
    this.difficultyUpdateWorld = world;
    this.difficultyUpdatePos = blockPos;
    return this.difficultyLast;
  }
  
  private void onTick(WorldServer ws) {
    if (!Config.isTimeDefault())
      fixWorldTime(ws); 
    if (!Config.isWeatherEnabled())
      fixWorldWeather(ws); 
    if (Config.waterOpacityChanged) {
      Config.waterOpacityChanged = false;
      ClearWater.updateWaterOpacity(Config.getGameSettings(), (World)ws);
    } 
    if (this.difficultyUpdateWorld == ws && this.difficultyUpdatePos != null) {
      this.difficultyLast = ws.getDifficultyForLocation(this.difficultyUpdatePos);
      this.difficultyUpdateWorld = null;
      this.difficultyUpdatePos = null;
    } 
  }
  
  private void fixWorldWeather(WorldServer ws) {
    WorldInfo worldInfo = ws.getWorldInfo();
    if (worldInfo.isRaining() || worldInfo.isThundering()) {
      worldInfo.setRainTime(0);
      worldInfo.setRaining(false);
      ws.setRainStrength(0.0F);
      worldInfo.setThunderTime(0);
      worldInfo.setThundering(false);
      ws.setThunderStrength(0.0F);
      getPlayerList().sendPacketToAllPlayers((Packet)new SPacketChangeGameState(2, 0.0F));
      getPlayerList().sendPacketToAllPlayers((Packet)new SPacketChangeGameState(7, 0.0F));
      getPlayerList().sendPacketToAllPlayers((Packet)new SPacketChangeGameState(8, 0.0F));
    } 
  }
  
  private void fixWorldTime(WorldServer ws) {
    WorldInfo worldInfo = ws.getWorldInfo();
    if (worldInfo.getGameType().getID() != 1)
      return; 
    long time = ws.getWorldTime();
    long timeOfDay = time % 24000L;
    if (Config.isTimeDayOnly()) {
      if (timeOfDay <= 1000L)
        ws.setWorldTime(time - timeOfDay + 1001L); 
      if (timeOfDay >= 11000L)
        ws.setWorldTime(time - timeOfDay + 24001L); 
    } 
    if (Config.isTimeNightOnly()) {
      if (timeOfDay <= 14000L)
        ws.setWorldTime(time - timeOfDay + 14001L); 
      if (timeOfDay >= 22000L)
        ws.setWorldTime(time - timeOfDay + 24000L + 14001L); 
    } 
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraft\server\integrated\IntegratedServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */