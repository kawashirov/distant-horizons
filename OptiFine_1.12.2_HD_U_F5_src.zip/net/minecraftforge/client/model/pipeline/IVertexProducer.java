package net.minecraftforge.client.model.pipeline;

public interface IVertexProducer {
  void pipe(IVertexConsumer paramIVertexConsumer);
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraftforge\client\model\pipeline\IVertexProducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */