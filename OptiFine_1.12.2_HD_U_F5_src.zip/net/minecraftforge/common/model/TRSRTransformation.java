package net.minecraftforge.common.model;

import javax.vecmath.Matrix4f;
import net.minecraft.client.renderer.block.model.ModelRotation;
import org.apache.commons.lang3.NotImplementedException;

public class TRSRTransformation {
  public TRSRTransformation(Matrix4f matrix) {
    throw new NotImplementedException("Forge dummy class");
  }
  
  public Matrix4f getMatrix() {
    throw new NotImplementedException("Forge dummy class");
  }
  
  public static boolean isInteger(Matrix4f matrix) {
    throw new NotImplementedException("Forge dummy class");
  }
  
  public static TRSRTransformation from(ModelRotation rotation) {
    throw new NotImplementedException("Forge dummy class");
  }
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\net\minecraftforge\common\model\TRSRTransformation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */