package javax.vecmath;

import java.io.Serializable;

public class Matrix4f implements Serializable, Cloneable {
  public Matrix4f(org.lwjgl.util.vector.Matrix4f matrix4f) {}
}


/* Location:              C:\Users\James Seibel\Documents\Eclipse\workspaces\personal-projects\minecraft-lod-mod\optifine_deobf\OptiFine_1.12.2_HD_U_F5_dev.jar!\javax\vecmath\Matrix4f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */